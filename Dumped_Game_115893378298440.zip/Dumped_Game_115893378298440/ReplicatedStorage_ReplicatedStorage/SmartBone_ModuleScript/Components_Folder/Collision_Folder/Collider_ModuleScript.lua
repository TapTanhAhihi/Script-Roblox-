-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = game:GetService("HttpService")
local v2 = script.Parent.Parent.Parent:WaitForChild("Dependencies")
local v3 = script.Parent:WaitForChild("Colliders")
local v_u_4 = require(v3:WaitForChild("Box"))
local v_u_5 = require(v3:WaitForChild("Capsule"))
local v_u_6 = require(v3:WaitForChild("Cylinder"))
local v_u_7 = require(v3:WaitForChild("Sphere"))
local v8 = require(script.Parent.Parent.Parent:WaitForChild("Dependencies"):WaitForChild("Config"))
local v_u_9 = require(script.Parent.Parent.Parent:WaitForChild("Dependencies"):WaitForChild("Utilities")).SB_VERBOSE_LOG
local v_u_10 = require(v2:WaitForChild("Gizmo"))
if game:GetService("RunService"):IsStudio() or v8.ALLOW_LIVE_GAME_DEBUG or v8.ALLOW_LIVE_GAME_DEBUG then
	v_u_10.Init()
end
local v_u_11 = {}
v_u_11.__index = v_u_11
function v_u_11.new()
	-- upvalues: (copy) v_u_1, (copy) v_u_11
	local v12 = {
		["Type"] = "Box",
		["Scale"] = Vector3.new(0, 0, 0),
		["Offset"] = Vector3.new(0, 0, 0),
		["Rotation"] = Vector3.new(0, 0, 0),
		["Radius"] = 0,
		["PreviousScale"] = Vector3.new(0, 0, 0),
		["PreviousOffset"] = Vector3.new(0, 0, 0),
		["PreviousRotation"] = Vector3.new(0, 0, 0),
		["PreviousObjectPosition"] = Vector3.new(0, 0, 0),
		["PreviousObjectRotation"] = Vector3.new(0, 0, 0),
		["m_Object"] = nil,
		["InNarrowphase"] = false,
		["Transform"] = CFrame.identity,
		["Size"] = Vector3.new(0, 0, 0),
		["GUID"] = v_u_1:GenerateGUID(false)
	}
	local v13 = v_u_11
	return setmetatable(v12, v13)
end
function v_u_11.SetObject(p14, p15)
	p14.m_Object = p15
	p14:UpdateTransform()
end
function v_u_11.UpdateTransform(p16)
	debug.profilebegin("Update Transform")
	local v17 = p16.m_Object
	local v18 = v17.CFrame
	local v19 = v17.Size
	local v20 = p16.Scale
	local v21 = p16.Offset
	local v22 = p16.Rotation
	local v23 = v19 * v21
	local v24 = v19 * v20
	local v25 = CFrame.Angles(v22.X * 0.017453, v22.Y * 0.017453, v22.Z * 0.017453)
	p16.Transform = v18 * CFrame.new(v23) * v25
	p16.Size = v24
	local v26 = v24.X
	local v27 = v24.Y
	local v28 = v24.Z
	local v29 = (math.max(v26, v27, v28) * 0.5) ^ 2 * 2
	p16.Radius = math.sqrt(v29)
	debug.profileend()
end
function v_u_11.GetClosestPoint(p30, p31, p32)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_7, (copy) v_u_6
	if p30.m_Object ~= nil then
		p30.InNarrowphase = false
		if (p31 - p30.Transform.Position).Magnitude - p32 <= p30.Radius then
			debug.profilebegin("Narrowphase")
			p30.InNarrowphase = true
			local v33 = p30.Type
			local v34, v35, v36
			if v33 == "Box" then
				v34, v35, v36 = v_u_4(p30.Transform, p30.Size, p31, p32)
			else
				v34 = nil
				v35 = nil
				v36 = nil
			end
			if v33 == "Capsule" then
				v34, v35, v36 = v_u_5(p30.Transform, p30.Size, p31, p32)
			end
			if v33 == "Sphere" then
				v34, v35, v36 = v_u_7(p30.Transform, p30.Size, p31, p32)
			end
			if v33 == "Cylinder" then
				v34, v35, v36 = v_u_6(p30.Transform, p30.Size, p31, p32)
			end
			debug.profileend()
			return v34, v35, v36
		end
	end
end
function v_u_11.Step(p37)
	debug.profilebegin("Collider::Step")
	p37:UpdateTransform()
	debug.profileend()
end
function v_u_11.DrawDebug(p38, p39, p40, p41, p42, p43)
	-- upvalues: (copy) v_u_10
	local v44 = Color3.new(0.509803, 0.933333, 0.42745)
	local v45 = Color3.new(0.90196, 0.784313, 0.513725)
	local v46 = Color3.new(1, 0, 1)
	local v47 = Color3.new(0, 1, 1)
	local v48 = Color3.new(1, 0.3, 0.3)
	local v49 = p38.Type
	local v50 = p38.Transform
	local v51 = p38.Size
	if p39.m_Awake then
		v46 = v44
	elseif not p42 then
		v46 = v44
	end
	if p38.InNarrowphase == false then
		if not p43 then
			v47 = v45
		end
	else
		v47 = v45
	end
	if p41 then
		v_u_10.SetStyle(v48, 0, false)
		v_u_10.Sphere:Draw(v50, p38.Radius, 25, 360)
	end
	if v49 == "Box" then
		v_u_10.SetStyle(v46, 0, false)
		v_u_10.Box:Draw(v50, v51)
		if p40 then
			v_u_10.SetStyle(v47, 0.75, false)
			v_u_10.VolumeBox:Draw(v50, v51)
			v_u_10.PushProperty("Transparency", 0)
		end
		return
	elseif v49 == "Capsule" then
		local v52 = v51.Y
		local v53 = v51.Z
		local v54 = math.min(v52, v53) * 0.5
		local v55 = v51.X
		local v56 = v50 * CFrame.Angles(1.5707963267948966, -1.5707963267948966, 0)
		v_u_10.SetStyle(v46, 0, false)
		v_u_10.Capsule:Draw(v56, v54, v55, 15)
		if p40 then
			local v57 = v56.Position + v56.UpVector * (v55 * 0.5)
			local v58 = v56.Position - v56.UpVector * (v55 * 0.5)
			v_u_10.SetStyle(v47, 0.75, false)
			v_u_10.VolumeCylinder:Draw(v50, v54, v55)
			v_u_10.VolumeSphere:Draw(CFrame.new(v57), v54)
			v_u_10.VolumeSphere:Draw(CFrame.new(v58), v54)
			v_u_10.PushProperty("Transparency", 0)
		end
		return
	elseif v49 == "Sphere" then
		local v59 = v51.X
		local v60 = v51.Y
		local v61 = v51.Z
		local v62 = math.min(v59, v60, v61) * 0.5
		v_u_10.SetStyle(v46, 0, false)
		v_u_10.Sphere:Draw(v50, v62, 15, 360)
		if p40 then
			v_u_10.SetStyle(v47, 0.75, false)
			v_u_10.VolumeSphere:Draw(v50, v62)
			v_u_10.PushProperty("Transparency", 0)
		end
		return
	elseif v49 == "Cylinder" then
		local v63 = v51.Y
		local v64 = v51.Z
		local v65 = math.min(v63, v64) * 0.5
		v_u_10.SetStyle(v46, 0, false)
		v_u_10.Cylinder:Draw(v50 * CFrame.Angles(0, 0, 1.5707963267948966), v65, v51.X, 15)
		if p40 then
			v_u_10.SetStyle(v47, 0.75, false)
			v_u_10.VolumeCylinder:Draw(v50 * CFrame.Angles(0, -1.5707963267948966, 0), v65, v51.X, 0, 360)
			v_u_10.PushProperty("Transparency", 0)
		end
	end
end
function v_u_11.Destroy(p66)
	-- upvalues: (copy) v_u_9
	v_u_9((("Collider destroying, object: %*"):format(p66.m_Object)))
	setmetatable(p66, nil)
end
return v_u_11