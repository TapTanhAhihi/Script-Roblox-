-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = false
local v_u_3 = nil
function v1.Start(p_u_4)
	-- upvalues: (ref) v_u_3, (ref) v_u_2
	local v_u_5 = game:GetService("Players")
	local v_u_6 = v_u_5.LocalPlayer
	v_u_3 = p_u_4.Shared.Network
	local v_u_7 = p_u_4.Shared
	if v_u_7 then
		v_u_7 = p_u_4.Shared.NumberFormatter
	end
	local function v_u_12(p8)
		-- upvalues: (copy) v_u_7
		local v9 = tonumber(p8) or 0
		if v_u_7 then
			local v10 = v_u_7.Format
			if type(v10) == "function" then
				return v_u_7.Format(v9)
			end
		end
		if v9 >= 1000000000 then
			return string.format("%.1fB", v9 / 1000000000)
		end
		if v9 >= 1000000 then
			return string.format("%.1fM", v9 / 1000000)
		end
		if v9 >= 1000 then
			return string.format("%.1fK", v9 / 1000)
		end
		local v11 = math.floor(v9)
		return tostring(v11)
	end
	repeat
		task.wait()
	until v_u_6:FindFirstChild("PlayerGui")
	local v_u_13 = v_u_6.PlayerGui:WaitForChild("Guild")
	local v14 = v_u_13.CreateFrame
	local v_u_15 = v14:FindFirstChild("ClanLogoTextBox") or v14:WaitForChild("ClanLogoTextBox", 5)
	local v_u_16 = v14:FindFirstChild("ClanNameTextBox") or v14:WaitForChild("ClanNameTextBox", 5)
	local v17 = v14:FindFirstChild("CreateButton") or (v14:FindFirstChild("Create") or v14:WaitForChild("CreateButton", 5))
	if v_u_15 and (v_u_16 and v17) then
		if v_u_15.PlaceholderText == nil or v_u_15.PlaceholderText == "" then
			v_u_15.PlaceholderText = "rbxassetid://123456789"
		end
		if v_u_15:IsA("TextBox") and v_u_15.FocusLost then
			v_u_15.FocusLost:Connect(function()
				-- upvalues: (copy) v_u_15
				local v18 = v_u_15.Text or ""
				local v19 = tostring(v18):gsub("^%s+", ""):gsub("%s+$", "")
				if v19 ~= "" and (v19:match("^%d+$") and not v19:find("rbxassetid://")) then
					v_u_15.Text = "rbxassetid://" .. v19
				end
			end)
		end
		local function v_u_24(p20)
			local v21 = tostring(p20 or ""):gsub("^%s+", ""):gsub("%s+$", "")
			if v21 == "" then
				return false, "Nh\225\186\173p rbxassetid://ID (VD: rbxassetid://123456789)"
			else
				local v22 = v21:match("^rbxassetid://(%d+)$") or v21:match("^(%d+)$")
				if v22 and #v22 >= 1 then
					return true, "rbxassetid://" .. v22
				else
					local v23 = v21:find("create%.roblox%.com") and (v21:match("asset/(%d+)") or (v21:match("library/(%d+)") or v21:match("id=(%d+)")))
					if v23 then
						return true, "rbxassetid://" .. v23
					else
						return false, "Icon ph\225\186\163i \196\145\195\186ng d\225\186\161ng rbxassetid://123456789 (Image asset tr\195\170n Roblox)"
					end
				end
			end
		end
		v17.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_2, (copy) v_u_6, (ref) v_u_3, (copy) v_u_24, (copy) v_u_15, (copy) v_u_16, (copy) v_u_13, (copy) p_u_4
			if v_u_2 then
				return
			else
				v_u_2 = true
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_2
					v_u_2 = false
				end)
				if (v_u_6:FindFirstChild("Level") and v_u_6.Level.Value or 0) < 30 then
					if v_u_3 then
						local v_u_25 = "You need Level 30+ to create a guild."
						local v_u_26 = "Error"
						pcall(function()
							-- upvalues: (ref) v_u_3, (copy) v_u_25, (copy) v_u_26
							v_u_3:FireServer("RequestSendNotification", {
								["Text"] = v_u_25,
								["Type"] = v_u_26 or "Error"
							})
						end)
					end
				else
					local v27 = v_u_6:FindFirstChild("leaderstats")
					if v27 then
						v27 = v27:FindFirstChild("Money")
					end
					if (v27 and v27.Value or 0) < 1000000 then
						if v_u_3 then
							local v_u_28 = "You need at least 1,000,000 money to create a guild."
							local v_u_29 = "Error"
							pcall(function()
								-- upvalues: (ref) v_u_3, (copy) v_u_28, (copy) v_u_29
								v_u_3:FireServer("RequestSendNotification", {
									["Text"] = v_u_28,
									["Type"] = v_u_29 or "Error"
								})
							end)
						end
					else
						local v30, v_u_31 = v_u_24(v_u_15.Text)
						if v30 then
							local v32 = v_u_16.Text or ""
							local v_u_33 = tostring(v32):gsub("^%s+", ""):gsub("%s+$", "")
							local v34
							if v_u_33 == "" then
								v34 = false
								v_u_33 = "Guild name is required"
							elseif #v_u_33 < 3 then
								v34 = false
								v_u_33 = "Guild name must be at least 3 characters"
							elseif #v_u_33 > 16 then
								v34 = false
								v_u_33 = "Guild name must be at most 16 characters"
							else
								v34 = true
							end
							if v34 then
								if v_u_3 then
									local v35, v36, v37 = pcall(function()
										-- upvalues: (ref) v_u_3, (copy) v_u_33, (copy) v_u_31
										return v_u_3:InvokeServer("CreateGuild", v_u_33, v_u_31)
									end)
									if v35 then
										if v36 then
											if v_u_3 then
												local v_u_38 = "Guild created successfully!"
												local v_u_39 = "Success"
												pcall(function()
													-- upvalues: (ref) v_u_3, (copy) v_u_38, (copy) v_u_39
													v_u_3:FireServer("RequestSendNotification", {
														["Text"] = v_u_38,
														["Type"] = v_u_39 or "Error"
													})
												end)
											end
											if v_u_13 then
												local v_u_40 = p_u_4.Shared
												if v_u_40 then
													v_u_40 = p_u_4.Shared.sprLib
												end
												local v_u_41 = v_u_13:FindFirstChild("CreateFrame")
												local v_u_42 = v_u_13:FindFirstChild("GuildFrame")
												if v_u_41 and (v_u_42 and v_u_40) then
													v_u_40.target(v_u_41, 1, 4, {
														["Size"] = UDim2.new(0, 0, 1, 0)
													})
													task.delay(1.05, function()
														-- upvalues: (copy) v_u_41, (copy) v_u_42, (copy) v_u_40
														if v_u_41 and v_u_41.Parent then
															v_u_41.Visible = false
															v_u_42.Size = UDim2.new(0, 0, 1, 0)
															v_u_42.Visible = true
															v_u_40.target(v_u_42, 1, 4, {
																["Size"] = UDim2.new(0.407, 0, 0.689, 0)
															})
														end
													end)
												else
													if v_u_41 then
														v_u_41.Visible = false
													end
													if v_u_42 then
														v_u_42.Visible = true
													end
												end
												v_u_13.Enabled = true
											end
											return
										else
											local v_u_43 = type(v37) == "string" and v37 and v37 or "Failed to create guild"
											if v_u_3 then
												local v_u_44 = "Error"
												pcall(function()
													-- upvalues: (ref) v_u_3, (copy) v_u_43, (copy) v_u_44
													v_u_3:FireServer("RequestSendNotification", {
														["Text"] = v_u_43,
														["Type"] = v_u_44 or "Error"
													})
												end)
											end
										end
									else
										local v_u_45 = type(v36) == "string" and v36 and v36 or "Failed to create guild"
										if v_u_3 then
											local v_u_46 = "Error"
											pcall(function()
												-- upvalues: (ref) v_u_3, (copy) v_u_45, (copy) v_u_46
												v_u_3:FireServer("RequestSendNotification", {
													["Text"] = v_u_45,
													["Type"] = v_u_46 or "Error"
												})
											end)
										end
									end
								elseif v_u_3 then
									local v_u_47 = "Unable to create guild. Try again later."
									local v_u_48 = "Error"
									pcall(function()
										-- upvalues: (ref) v_u_3, (copy) v_u_47, (copy) v_u_48
										v_u_3:FireServer("RequestSendNotification", {
											["Text"] = v_u_47,
											["Type"] = v_u_48 or "Error"
										})
									end)
								end
							elseif v_u_3 then
								local v_u_49 = "Error"
								pcall(function()
									-- upvalues: (ref) v_u_3, (copy) v_u_33, (copy) v_u_49
									v_u_3:FireServer("RequestSendNotification", {
										["Text"] = v_u_33,
										["Type"] = v_u_49 or "Error"
									})
								end)
							end
						elseif v_u_3 then
							local v_u_50 = "Error"
							pcall(function()
								-- upvalues: (ref) v_u_3, (copy) v_u_31, (copy) v_u_50
								v_u_3:FireServer("RequestSendNotification", {
									["Text"] = v_u_31,
									["Type"] = v_u_50 or "Error"
								})
							end)
						end
					end
				end
			end
		end)
		local v51 = v_u_13.GuildFrame
		local v52 = v51.Abandon
		local v53 = v51.Invite
		local _ = v51.Shop
		local v54 = v51.Deposit
		local v_u_55 = v51.Inside
		local v_u_56 = v_u_55.Stats
		local v_u_57 = v_u_56:FindFirstChild("Gem") or v_u_56:FindFirstChild("Gems")
		local v_u_58 = v_u_56:FindFirstChild("MemberCount")
		local v_u_59 = v_u_56:FindFirstChild("Money")
		local function v_u_76(p60)
			-- upvalues: (copy) v_u_59, (copy) v_u_12, (copy) v_u_57, (copy) v_u_58, (copy) v_u_55, (copy) v_u_56
			if p60 then
				local v61 = p60.Money
				local v62 = tonumber(v61) or 0
				local v63 = p60.Gems
				local v64 = tonumber(v63) or 0
				local v65 = p60.MemberCount
				local v66 = tonumber(v65) or #(p60.Members or {})
				if v_u_59 and (v_u_59:IsA("TextLabel") or v_u_59:IsA("TextBox")) then
					v_u_59.Text = v_u_12(v62)
				end
				if v_u_57 and (v_u_57:IsA("TextLabel") or v_u_57:IsA("TextBox")) then
					v_u_57.Text = v_u_12(v64)
				end
				if v_u_58 and (v_u_58:IsA("TextLabel") or v_u_58:IsA("TextBox")) then
					v_u_58.Text = tostring(v66)
				end
				local v67 = v_u_55:FindFirstChild("MemberList") or (v_u_55:FindFirstChild("Members") or v_u_56:FindFirstChild("MemberList"))
				if v67 and (p60.Members and #p60.Members > 0) then
					local v68 = v67:FindFirstChild("MemberTemplate")
					for _, v69 in ipairs(v67:GetChildren()) do
						if v69 ~= v68 and (v69:IsA("Frame") or v69:IsA("TextButton")) then
							v69:Destroy()
						end
					end
					for v70, v71 in ipairs(p60.Members) do
						local v72
						if type(v71) == "table" then
							v72 = v71.Name or (v71.UserName or "Member")
						else
							v72 = tostring(v71)
						end
						if v68 and v68:IsA("Frame") then
							local v73 = v68:Clone()
							v73.Name = "Member_" .. v70
							v73.Visible = true
							local v74 = v73:FindFirstChildOfClass("TextLabel") or v73:FindFirstChild("Name")
							if v74 then
								v74.Text = v72
							end
							v73.Parent = v67
						else
							local v75 = Instance.new("TextLabel")
							v75.Name = "Member_" .. v70
							v75.Text = v72
							v75.Size = UDim2.new(1, 0, 0, 24)
							v75.Position = UDim2.new(0, 0, 0, (v70 - 1) * 26)
							v75.BackgroundTransparency = 1
							v75.Parent = v67
						end
					end
				end
			end
		end
		v54.Activated:Connect(function()
			-- upvalues: (copy) v_u_13
			local v77 = v_u_13:FindFirstChild("DepositFrame")
			if v77 then
				v77.Visible = true
			end
		end)
		local v_u_78 = v_u_13:FindFirstChild("InviteFrame")
		if v_u_78 then
			local v79 = v_u_78:FindFirstChild("Invite")
			local v80 = v_u_78:FindFirstChild("Cancel")
			local v_u_81 = v_u_78:FindFirstChild("Username")
			if v_u_81 and v_u_81:IsA("Frame") then
				v_u_81 = v_u_81:FindFirstChildOfClass("TextBox") or v_u_81:FindFirstChild("TextLabel")
			end
			v53.Activated:Connect(function()
				-- upvalues: (copy) v_u_78, (ref) v_u_81
				v_u_78.Visible = true
				if v_u_81 and v_u_81:IsA("TextBox") then
					v_u_81.Text = ""
				end
			end)
			if v80 then
				v80.Activated:Connect(function()
					-- upvalues: (copy) v_u_78
					v_u_78.Visible = false
				end)
			end
			if v79 and (v_u_81 and v_u_3) then
				v79.Activated:Connect(function()
					-- upvalues: (ref) v_u_2, (ref) v_u_81, (ref) v_u_3, (copy) v_u_5, (copy) v_u_78, (copy) v_u_76
					if v_u_2 then
						return
					else
						local v_u_82 = (v_u_81:IsA("TextBox") and v_u_81.Text or (v_u_81:IsA("TextLabel") and v_u_81.Text or "")):gsub("^%s+", ""):gsub("%s+$", "")
						if v_u_82 == "" then
							if v_u_3 then
								local v_u_83 = "Enter username."
								local v_u_84 = "Error"
								pcall(function()
									-- upvalues: (ref) v_u_3, (copy) v_u_83, (copy) v_u_84
									v_u_3:FireServer("RequestSendNotification", {
										["Text"] = v_u_83,
										["Type"] = v_u_84 or "Error"
									})
								end)
							end
						else
							v_u_2 = true
							task.delay(0.5, function()
								-- upvalues: (ref) v_u_2
								v_u_2 = false
							end)
							local v85, v_u_86 = pcall(function()
								-- upvalues: (ref) v_u_5, (copy) v_u_82
								return v_u_5:GetUserIdFromNameAsync(v_u_82)
							end)
							if v85 and (v_u_86 and v_u_86 ~= 0) then
								local v87, v88 = pcall(function()
									-- upvalues: (ref) v_u_3, (copy) v_u_86
									return v_u_3:InvokeServer("InviteToGuild", v_u_86)
								end)
								if v87 and v88 then
									if v_u_3 then
										local v_u_89 = "Invite sent."
										local v_u_90 = "Success"
										pcall(function()
											-- upvalues: (ref) v_u_3, (copy) v_u_89, (copy) v_u_90
											v_u_3:FireServer("RequestSendNotification", {
												["Text"] = v_u_89,
												["Type"] = v_u_90 or "Error"
											})
										end)
									end
									v_u_78.Visible = false
									if not v_u_3 then
										return
									end
									local v91, v92 = pcall(function()
										-- upvalues: (ref) v_u_3
										return v_u_3:InvokeServer("GetGuildInfo")
									end)
									if v91 and (v92 and v92.Id) then
										v_u_76(v92)
										return
									end
								else
									local v_u_93 = type(v88) == "string" and v88 and v88 or "Invite failed."
									if not v_u_3 then
										return
									end
									local v_u_94 = "Error"
									pcall(function()
										-- upvalues: (ref) v_u_3, (copy) v_u_93, (copy) v_u_94
										v_u_3:FireServer("RequestSendNotification", {
											["Text"] = v_u_93,
											["Type"] = v_u_94 or "Error"
										})
									end)
								end
								return
							else
								local v_u_95 = "User not found: " .. v_u_82
								if v_u_3 then
									local v_u_96 = "Error"
									pcall(function()
										-- upvalues: (ref) v_u_3, (copy) v_u_95, (copy) v_u_96
										v_u_3:FireServer("RequestSendNotification", {
											["Text"] = v_u_95,
											["Type"] = v_u_96 or "Error"
										})
									end)
								end
							end
						end
					end
				end)
			end
		end
		local v_u_97 = v_u_13:FindFirstChild("AbandonFrame")
		if v_u_97 then
			local v98 = v_u_97:FindFirstChild("Accept")
			local v99 = v_u_97:FindFirstChild("Cancel")
			v52.Activated:Connect(function()
				-- upvalues: (copy) v_u_97
				v_u_97.Visible = true
			end)
			if v99 then
				v99.Activated:Connect(function()
					-- upvalues: (copy) v_u_97
					v_u_97.Visible = false
				end)
			end
			if v98 and v_u_3 then
				v98.Activated:Connect(function()
					-- upvalues: (ref) v_u_2, (ref) v_u_3, (copy) v_u_97, (copy) v_u_13
					if v_u_2 then
						return
					else
						v_u_2 = true
						task.delay(0.5, function()
							-- upvalues: (ref) v_u_2
							v_u_2 = false
						end)
						local v100, v101 = pcall(function()
							-- upvalues: (ref) v_u_3
							return v_u_3:InvokeServer("AbandonGuild")
						end)
						if v100 and v101 then
							if v_u_3 then
								local v_u_102 = "Guild abandoned."
								local v_u_103 = "Success"
								pcall(function()
									-- upvalues: (ref) v_u_3, (copy) v_u_102, (copy) v_u_103
									v_u_3:FireServer("RequestSendNotification", {
										["Text"] = v_u_102,
										["Type"] = v_u_103 or "Error"
									})
								end)
							end
							v_u_97.Visible = false
							v_u_13.Enabled = false
							v_u_13.CreateFrame.Visible = true
							v_u_13.GuildFrame.Visible = false
							return
						else
							local v_u_104 = type(v101) == "string" and v101 and v101 or "Abandon failed."
							if v_u_3 then
								local v_u_105 = "Error"
								pcall(function()
									-- upvalues: (ref) v_u_3, (copy) v_u_104, (copy) v_u_105
									v_u_3:FireServer("RequestSendNotification", {
										["Text"] = v_u_104,
										["Type"] = v_u_105 or "Error"
									})
								end)
							end
						end
					end
				end)
			end
		end
		task.spawn(function()
			-- upvalues: (copy) v_u_13, (ref) v_u_2, (ref) v_u_3, (copy) v_u_6, (copy) v_u_76
			local v_u_106 = v_u_13:FindFirstChild("DepositFrame")
			if v_u_106 then
				local v107 = v_u_106:FindFirstChild("Cancel")
				local v108 = v_u_106:FindFirstChild("Add")
				local v_u_109 = v_u_106:FindFirstChild("Gem") or v_u_106:FindFirstChild("Gems")
				local v_u_110 = v_u_106:FindFirstChild("Money")
				if v108 then
					local function v111()
						-- upvalues: (copy) v_u_106, (copy) v_u_109, (copy) v_u_110
						v_u_106.Visible = false
						if v_u_109 and v_u_109:IsA("TextBox") then
							v_u_109.Text = ""
						end
						if v_u_110 and v_u_110:IsA("TextBox") then
							v_u_110.Text = ""
						end
					end
					if v107 then
						v107.Activated:Connect(v111)
					end
					v108.Activated:Connect(function()
						-- upvalues: (ref) v_u_2, (copy) v_u_109, (copy) v_u_110, (ref) v_u_3, (ref) v_u_6, (copy) v_u_106, (ref) v_u_76
						if v_u_2 then
							return
						else
							local v112 = 0
							local v113
							if v_u_109 and v_u_109:IsA("TextBox") then
								local v114 = v_u_109.Text
								local v115 = tonumber(v114) or 0
								v113 = math.floor(v115)
							else
								v113 = 0
							end
							if v_u_110 and v_u_110:IsA("TextBox") then
								local v116 = v_u_110.Text
								local v117 = tonumber(v116) or 0
								v112 = math.floor(v117)
							end
							local v_u_118 = v113 < 0 and 0 or v113
							local v_u_119 = v112 < 0 and 0 or v112
							if v_u_118 == 0 and v_u_119 == 0 then
								if v_u_3 then
									local v_u_120 = "Enter amount to deposit (must be 0 or more)."
									local v_u_121 = "Error"
									pcall(function()
										-- upvalues: (ref) v_u_3, (copy) v_u_120, (copy) v_u_121
										v_u_3:FireServer("RequestSendNotification", {
											["Text"] = v_u_120,
											["Type"] = v_u_121 or "Error"
										})
									end)
								end
							else
								if v_u_119 > 0 then
									local v122 = v_u_6:FindFirstChild("leaderstats")
									if v122 then
										v122 = v122:FindFirstChild("Money")
									end
									if (v122 and v122.Value or 0) < v_u_119 then
										if v_u_3 then
											local v_u_123 = "Not enough money."
											local v_u_124 = "Error"
											pcall(function()
												-- upvalues: (ref) v_u_3, (copy) v_u_123, (copy) v_u_124
												v_u_3:FireServer("RequestSendNotification", {
													["Text"] = v_u_123,
													["Type"] = v_u_124 or "Error"
												})
											end)
										end
										return
									end
								end
								if v_u_118 > 0 then
									local v125 = v_u_6:FindFirstChild("leaderstats")
									if v125 then
										v125 = v125:FindFirstChild("Gems")
									end
									if (v125 and v125.Value or 0) < v_u_118 then
										if v_u_3 then
											local v_u_126 = "Not enough gems."
											local v_u_127 = "Error"
											pcall(function()
												-- upvalues: (ref) v_u_3, (copy) v_u_126, (copy) v_u_127
												v_u_3:FireServer("RequestSendNotification", {
													["Text"] = v_u_126,
													["Type"] = v_u_127 or "Error"
												})
											end)
										end
										return
									end
								end
								v_u_2 = true
								task.delay(0.5, function()
									-- upvalues: (ref) v_u_2
									v_u_2 = false
								end)
								local v128 = true
								local v129
								if v_u_119 > 0 and v_u_3 then
									local v130, v131 = pcall(function()
										-- upvalues: (ref) v_u_3, (ref) v_u_119
										return v_u_3:InvokeServer("GuildDeposit", "Money", v_u_119)
									end)
									v129 = v130 and v131
									if not v129 and v_u_3 then
										local v_u_132 = "Money deposit failed."
										local v_u_133 = "Error"
										pcall(function()
											-- upvalues: (ref) v_u_3, (copy) v_u_132, (copy) v_u_133
											v_u_3:FireServer("RequestSendNotification", {
												["Text"] = v_u_132,
												["Type"] = v_u_133 or "Error"
											})
										end)
									end
								else
									v129 = true
								end
								if v_u_118 > 0 and v_u_3 then
									local v134, v135 = pcall(function()
										-- upvalues: (ref) v_u_3, (ref) v_u_118
										return v_u_3:InvokeServer("GuildDeposit", "Gems", v_u_118)
									end)
									v128 = v134 and v135
									if not v128 and v_u_3 then
										local v_u_136 = "Gems deposit failed."
										local v_u_137 = "Error"
										pcall(function()
											-- upvalues: (ref) v_u_3, (copy) v_u_136, (copy) v_u_137
											v_u_3:FireServer("RequestSendNotification", {
												["Text"] = v_u_136,
												["Type"] = v_u_137 or "Error"
											})
										end)
									end
								end
								if (v_u_119 == 0 or v129) and (v_u_118 == 0 or v128) then
									if v_u_3 then
										local v_u_138 = "Deposit successful."
										local v_u_139 = "Success"
										pcall(function()
											-- upvalues: (ref) v_u_3, (copy) v_u_138, (copy) v_u_139
											v_u_3:FireServer("RequestSendNotification", {
												["Text"] = v_u_138,
												["Type"] = v_u_139 or "Error"
											})
										end)
									end
									v_u_106.Visible = false
									if v_u_109 and v_u_109:IsA("TextBox") then
										v_u_109.Text = ""
									end
									if v_u_110 and v_u_110:IsA("TextBox") then
										v_u_110.Text = ""
									end
									if v_u_3 then
										local v140, v141 = pcall(function()
											-- upvalues: (ref) v_u_3
											return v_u_3:InvokeServer("GetGuildInfo")
										end)
										if v140 and (v141 and v141.Id) then
											v_u_76(v141)
										end
									end
								end
							end
						end
					end)
				end
			else
				return
			end
		end)
	end
end
function v1.Active(p_u_142)
	-- upvalues: (ref) v_u_2
	if v_u_2 then
		return
	else
		local v143 = game:GetService("Players").LocalPlayer
		repeat
			task.wait()
		until v143:FindFirstChild("PlayerGui")
		local v_u_144 = v143.PlayerGui:WaitForChild("Guild")
		local v145 = p_u_142.Shared.sprLib
		local v_u_146 = p_u_142.Shared
		if v_u_146 then
			v_u_146 = p_u_142.Shared.Network
		end
		v_u_2 = true
		task.delay(0.5, function()
			-- upvalues: (ref) v_u_2
			v_u_2 = false
		end)
		v_u_144.Enabled = not v_u_144.Enabled
		v_u_144.CreateFrame.Size = UDim2.new(0, 0, 1, 0)
		v_u_144.GuildFrame.Size = UDim2.new(0, 0, 1, 0)
		if v_u_144.Enabled then
			p_u_142.Controllers.HUD:CloseAllUI(v_u_144)
			p_u_142.Controllers.HUD:Effect(true)
			local v147 = false
			if v_u_146 then
				local v148, v149 = pcall(function()
					-- upvalues: (copy) v_u_146
					return v_u_146:InvokeServer("GetGuildInfo")
				end)
				v147 = v148 and (v149 and v149.Id) and true or v147
			end
			if v147 then
				v_u_144.CreateFrame.Visible = false
				v_u_144.GuildFrame.Visible = true
				v145.target(v_u_144.GuildFrame, 1, 4, {
					["Size"] = UDim2.new(0.407, 0, 0.689, 0)
				})
				task.defer(function()
					-- upvalues: (copy) v_u_146, (copy) p_u_142, (copy) v_u_144
					local v150, v151 = pcall(function()
						-- upvalues: (ref) v_u_146
						return v_u_146:InvokeServer("GetGuildInfo")
					end)
					if v150 and (v151 and v151.Id) then
						local function v157(p152)
							-- upvalues: (ref) p_u_142
							local v153 = tonumber(p152) or 0
							local v154 = p_u_142.Shared
							if v154 then
								v154 = p_u_142.Shared.NumberFormatter
							end
							if v154 then
								local v155 = v154.Format
								if type(v155) == "function" then
									return v154.Format(v153)
								end
							end
							if v153 >= 1000000000 then
								return string.format("%.1fB", v153 / 1000000000)
							end
							if v153 >= 1000000 then
								return string.format("%.1fM", v153 / 1000000)
							end
							if v153 >= 1000 then
								return string.format("%.1fK", v153 / 1000)
							end
							local v156 = math.floor(v153)
							return tostring(v156)
						end
						local v158 = v_u_144.GuildFrame.Inside
						local v159
						if v158 then
							v159 = v158.Stats
						else
							v159 = v158
						end
						if v159 then
							local v160 = v151.Money
							local v161 = tonumber(v160) or 0
							local v162 = v151.Gems
							local v163 = tonumber(v162) or 0
							local v164 = v151.MemberCount
							local v165 = tonumber(v164) or #(v151.Members or {})
							local v166 = v159:FindFirstChild("Money")
							local v167 = v159:FindFirstChild("Gem") or v159:FindFirstChild("Gems")
							local v168 = v159:FindFirstChild("MemberCount")
							if v166 and (v166:IsA("TextLabel") or v166:IsA("TextBox")) then
								v166.Text = v157(v161)
							end
							if v167 and (v167:IsA("TextLabel") or v167:IsA("TextBox")) then
								v167.Text = v157(v163)
							end
							if v168 and (v168:IsA("TextLabel") or v168:IsA("TextBox")) then
								v168.Text = tostring(v165)
							end
						end
						if v158 then
							v158 = v158:FindFirstChild("MemberList") or v158:FindFirstChild("Members")
						end
						if v158 and (v151.Members and #v151.Members > 0) then
							local v169 = v158:FindFirstChild("MemberTemplate")
							for _, v170 in ipairs(v158:GetChildren()) do
								if v170 ~= v169 and (v170:IsA("Frame") or v170:IsA("TextButton")) then
									v170:Destroy()
								end
							end
							for v171, v172 in ipairs(v151.Members) do
								local v173
								if type(v172) == "table" then
									v173 = v172.Name or (v172.UserName or "Member")
								else
									v173 = tostring(v172)
								end
								if v169 and v169:IsA("Frame") then
									local v174 = v169:Clone()
									v174.Name = "Member_" .. v171
									v174.Visible = true
									local v175 = v174:FindFirstChildOfClass("TextLabel") or v174:FindFirstChild("Name")
									if v175 then
										v175.Text = v173
									end
									v174.Parent = v158
								else
									local v176 = Instance.new("TextLabel")
									v176.Name = "Member_" .. v171
									v176.Text = v173
									v176.Size = UDim2.new(1, 0, 0, 24)
									v176.Position = UDim2.new(0, 0, 0, (v171 - 1) * 26)
									v176.BackgroundTransparency = 1
									v176.Parent = v158
								end
							end
						end
					end
				end)
			else
				v_u_144.CreateFrame.Visible = true
				v_u_144.GuildFrame.Visible = false
				v145.target(v_u_144.CreateFrame, 1, 4, {
					["Size"] = UDim2.new(0.407, 0, 0.689, 0)
				})
			end
		else
			p_u_142.Controllers.HUD:Effect(false)
			if v_u_144.CreateFrame.Visible then
				v145.target(v_u_144.CreateFrame, 1, 4, {
					["Size"] = UDim2.new(0, 0, 1, 0)
				})
			end
			if v_u_144.GuildFrame.Visible then
				v145.target(v_u_144.GuildFrame, 1, 4, {
					["Size"] = UDim2.new(0, 0, 1, 0)
				})
			end
			return
		end
	end
end
return v1