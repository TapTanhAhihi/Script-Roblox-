-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
game:GetService("TweenService")
local v1 = game:GetService("Players")
game:GetService("CollectionService")
local v_u_2 = require(game.ReplicatedStorage.Assets.Templates.Dialogue.RichText)
local v_u_3 = require(script.Conversations)
local v_u_4 = {}
local v_u_5 = nil
local v_u_6 = v1.LocalPlayer
local _ = v_u_6.Character
local v_u_7 = game.ReplicatedStorage.Remotes.Dialogue
local v_u_8 = nil
v_u_6.PlayerGui:FindFirstChild("HUD")
local v_u_9 = v_u_6.PlayerGui:FindFirstChild("Dialogue")
local v_u_10 = {}
local v_u_11 = false
function FrameMovement(p12, p13, p14)
	-- upvalues: (ref) v_u_9, (copy) v_u_6, (ref) v_u_11, (copy) v_u_7
	v_u_9 = v_u_6.PlayerGui:FindFirstChild("Dialogue")
	if p13 then
		v_u_9.Enabled = true
		v_u_9.Frame:TweenPosition(UDim2.new(v_u_9.Frame.Position.X.Scale, 0, v_u_9.Frame.OpenedPosition.Value, 0), "Out", "Quad", 0.5)
		v_u_9.Frame.Title.Text.Text = p12.Name
		wait(0.5)
		return
	else
		v_u_9.Frame:TweenPosition(UDim2.new(v_u_9.Frame.Position.X.Scale, 0, 1.3, 0), "In", "Quad", 0.5)
		wait(0.5)
		for _, v15 in pairs(v_u_9.Frame.Text:GetChildren()) do
			if v15:IsA("Frame") then
				v15:Destroy()
			end
		end
		if not p14 then
			v_u_9.Enabled = false
			v_u_11 = false
			v_u_7:FireServer("DialogueClosed")
		end
	end
end
function LoadOptions(p16, p17)
	local v18 = p16.Options
	local v19 = {}
	if typeof(p17) == "table" then
		for v20 = 1, 5 do
			for v21, v22 in pairs(p17) do
				if v22.Order == v20 then
					local v23 = p16.OptionTemplate:Clone()
					v23.Click.Text = v21
					v23.Name = v21
					v23.Visible = true
					v23.Parent = v18
					v23:TweenSize(UDim2.new(1, 0, v23.Size.Y.Scale, 0), "Out", "Quad", 0.3)
					v19[v20] = v23
				end
			end
		end
		return v19
	end
	local v24 = p17 == true and { "Accept", "Decline" } or (p17 == false and { "Buy", "..." } or { "..." })
	for v25 = 1, #v24 do
		local v26 = p16.OptionTemplate:Clone()
		v26.Click.Text = v24[v25]
		v26.Name = v24[v25]
		v26.Visible = true
		v26.Parent = v18
		v26:TweenSize(UDim2.new(1, 0, v26.Size.Y.Scale, 0), "Out", "Quad", 0.3)
		v24[v25] = v26
	end
	return v24
end
function RemoveOptions(p27)
	local v_u_28 = p27.Options
	coroutine.wrap(function()
		-- upvalues: (copy) v_u_28
		for _, v_u_29 in pairs(v_u_28:GetChildren()) do
			if v_u_29:IsA("Frame") then
				v_u_29:TweenSize(UDim2.new(0, 0, v_u_29.Size.Y.Scale, 0), "In", "Quad", 0.45)
				coroutine.wrap(function()
					-- upvalues: (copy) v_u_29
					wait(0.45)
					v_u_29:Destroy()
				end)()
				wait()
			end
		end
	end)()
end
function Speaking(p30, p31)
	-- upvalues: (copy) v_u_2
	local v32 = v_u_2:New(p30.Text, p31, {
		["SingleLabel"] = true,
		["TypewriterDelay"] = 0.03,
		["TextXAlignment"] = "Left",
		["TextYAlignment"] = "Top"
	})
	v32:Animate(true)
	return v32
end
function v_u_4.StartDialogue(p33)
	-- upvalues: (ref) v_u_11, (copy) v_u_3, (copy) v_u_6, (ref) v_u_9, (copy) v_u_10, (ref) v_u_5, (ref) v_u_8
	if v_u_11 then
		return
	else
		v_u_11 = true
		local v34 = p33.Name
		local v_u_35 = v_u_3.GetConvo(v34)
		if v_u_35 then
			local v36 = v_u_6.PlayerGui:FindFirstChild("Dialogue")
			if v36 and v36:FindFirstChild("Frame") then
				local v37 = v36.Frame:FindFirstChild("Options")
				if v37 then
					for _, v38 in ipairs(v37:GetChildren()) do
						if v38:IsA("Frame") then
							v38:Destroy()
						end
					end
				end
			end
			FrameMovement(v_u_35, true)
			local v_u_39 = v_u_9.Frame
			local v40 = ""
			if v_u_35.Type ~= "Quest" then
				if v_u_35.Type == "Shop" then
					v40 = "Select a Weapon"
				elseif v_u_35.Type == "BoatDealer" then
					v40 = "Do you want to take a look at my boats?"
				elseif v_u_35.Type == "NoobTGaming" then
					v_u_10.Okay = LoadOptions(v_u_39, {
						["Okay"] = {
							["Order"] = 1
						}
					})[1].Click.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
						for _, v41 in pairs(v_u_10) do
							v41:Disconnect()
						end
						RemoveOptions(v_u_39)
						wait(0.45)
						FrameMovement(v_u_35, false)
					end)
					v40 = "The fish here pulled my rod away! Please get it back for me, and I\226\128\153ll give it to you!"
				else
					if v_u_35.Type == "SpawnSet" then
						local v_u_42 = p33:GetAttribute("Island") or "Island 1"
						local v43 = string.format("Do you want to set your spawn at <Font=GothamBold>%s<Font=/>? You will respawn here when you die or rejoin.", v_u_42)
						local v44 = LoadOptions(v_u_39, {
							["Yes, set my spawn here"] = {
								["Order"] = 1
							},
							["No, thanks"] = {
								["Order"] = 2
							}
						})
						v_u_10["Yes, set my spawn here"] = v44[1].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_42, (copy) v_u_35
							for _, v45 in pairs(v_u_10) do
								v45:Disconnect()
							end
							RemoveOptions(v_u_39)
							local v47, v48 = pcall(function()
								-- upvalues: (ref) v_u_5, (ref) v_u_42
								local v46 = v_u_5 and v_u_5.InvokeServer
								if v46 then
									v46 = v_u_5:InvokeServer("SetSpawn", v_u_42)
								end
								return v46
							end)
							Speaking(v_u_39, v47 and (v48 and "Done! Your spawn has been set at " .. v_u_42 .. ".") or "You need to unlock this island first!")
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v_u_10["No, thanks"] = v44[2].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
							for _, v49 in pairs(v_u_10) do
								v49:Disconnect()
							end
							RemoveOptions(v_u_39)
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						Speaking(v_u_39, v43)
						wait(0.25)
						return
					end
					if v_u_35.Type == "Bi Huynh" then
						local v50 = v_u_6:FindFirstChild("Level") and v_u_6.Level.Value or 0
						local v51 = {}
						local v52 = nil
						local v53 = nil
						local v54
						if v_u_5 and v_u_5.InvokeServer then
							local v55, v56 = pcall(function()
								-- upvalues: (ref) v_u_5
								return v_u_5:InvokeServer("GetBiHuynhQuestState")
							end)
							v51 = v55 and v56 and v56 or v51
							local v57, v58 = pcall(function()
								-- upvalues: (ref) v_u_5
								return v_u_5:InvokeServer("GetIsland4QuestState")
							end)
							if v57 then
								v52 = v58 or v52
							end
							local v59
							v59, v54 = pcall(function()
								-- upvalues: (ref) v_u_5
								return v_u_5:InvokeServer("GetIsland5QuestState")
							end)
							if v59 then
								if not v54 then
									v54 = v53
								end
							else
								v54 = v53
							end
						else
							v54 = v53
						end
						local v60 = v52 and v52.Accepted
						if v60 then
							v60 = not v52.RewardReceived
						end
						local v61 = v54 and v54.Accepted
						if v61 then
							v61 = not v54.RewardReceived
						end
						local v62
						if v60 or v61 then
							v62 = v60 and v61 and "You must complete Island 4/5 quest first" or (v60 and "You must complete Island 4 quest first" or "You must complete Island 5 quest first")
						elseif v51.RewardReceived then
							v62 = "\226\128\166\226\128\166"
						elseif v50 < 30 then
							v62 = string.format("You look new to fishing around here. Sigh\226\128\166 Forget it. You probably can\226\128\153t help me anyway")
						elseif v51.YuneCompleted and not v51.RewardReceived then
							v62 = "Thanks for bringing my sister home. I don\'t have much to repay you with, but please take this !!"
							if v_u_5 and v_u_5.InvokeServer then
								pcall(function()
									-- upvalues: (ref) v_u_5
									v_u_5:InvokeServer("ClaimBiHuynhReward")
								end)
							end
						elseif v51.Talked and not v51.YuneCompleted then
							v62 = "Oh, you\'re here. I\'ve been so busy fixing up the house these past few days that I haven\'t paid any attention to my <TextColor3=0,255,127>little sister<Color=/>. I don\'t even know where she ran off to\226\128\148she\'s been gone for days now. Could you help me find her and bring her back? Sigh\226\128\166 that girl is such a little troublemaker"
						else
							v62 = "Oh, you\'re here. I\'ve been so busy fixing up the house these past few days that I haven\'t paid any attention to my <TextColor3=0,255,127>little sister<Color=/>. I don\'t even know where she ran off to\226\128\148she\'s been gone for days now. Could you help me find her and bring her back? Sigh\226\128\166 that girl is such a little troublemaker"
							if v_u_5 and v_u_5.InvokeServer then
								pcall(function()
									-- upvalues: (ref) v_u_5
									v_u_5:InvokeServer("BiHuynhTalked")
								end)
							end
						end
						local v63 = {
							["..."] = {
								["Order"] = 1
							}
						}
						local v64 = v51.Talked or v51.YuneStarted or v51.YuneCompleted
						if v64 then
							v64 = not v51.RewardReceived
						end
						local v65 = v64 and {
							["Cancel quest"] = {
								["Order"] = 1
							},
							["..."] = {
								["Order"] = 2
							}
						} or v63
						local v66 = LoadOptions(v_u_39, v65)
						if v65["Cancel quest"] then
							v_u_10["Cancel quest"] = v66[1].Click.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
								for _, v67 in pairs(v_u_10) do
									v67:Disconnect()
								end
								RemoveOptions(v_u_39)
								local v69, v70 = pcall(function()
									-- upvalues: (ref) v_u_5
									local v68 = v_u_5 and v_u_5.InvokeServer
									if v68 then
										v68 = v_u_5:InvokeServer("CancelBiHuynhQuest")
									end
									return v68
								end)
								Speaking(v_u_39, v69 and v70 and "Quest cancelled. Come back when you\'re ready to help." or "Failed to cancel.")
								wait(0.45)
								FrameMovement(v_u_35, false)
							end)
							v_u_10["..."] = v66[2].Click.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
								for _, v71 in pairs(v_u_10) do
									v71:Disconnect()
								end
								RemoveOptions(v_u_39)
								wait(0.45)
								FrameMovement(v_u_35, false)
							end)
						else
							v_u_10["..."] = v66[1].Click.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
								for _, v72 in pairs(v_u_10) do
									v72:Disconnect()
								end
								RemoveOptions(v_u_39)
								wait(0.45)
								FrameMovement(v_u_35, false)
							end)
						end
						Speaking(v_u_39, v62)
						wait(0.25)
						return
					end
				end
			end
			if v_u_35.Type == "Khangg" then
				v_u_10["..."] = LoadOptions(v_u_39, {
					["..."] = {
						["Order"] = 1
					}
				})[1].Click.MouseButton1Click:Connect(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
					for _, v73 in pairs(v_u_10) do
						v73:Disconnect()
					end
					RemoveOptions(v_u_39)
					wait(0.45)
					FrameMovement(v_u_35, false)
				end)
				Speaking(v_u_39, "Hey buddy, focus on your fishing and stop checking out my girlfriend.")
				wait(0.25)
				return
			elseif v_u_35.Type == "Old Man" then
				local v74 = 20000
				local v75 = ""
				if v_u_5 and v_u_5.InvokeServer then
					local v76, v77 = pcall(function()
						-- upvalues: (ref) v_u_5
						return v_u_5:InvokeServer("GetGachaInfo")
					end)
					if v76 and v77 then
						v74 = v77.Price or 20000
						if v77.ResetInSeconds and v77.ResetInSeconds > 0 then
							local v78 = v77.ResetInSeconds
							local v79 = math.floor(v78)
							local v80 = v79 / 3600
							local v81 = math.floor(v80)
							local v82 = v79 % 3600 / 60
							local v83 = math.floor(v82)
							local v84 = v79 % 60
							v75 = string.format("\n\nPrice resets to 20k in: %02d:%02d:%02d", v81, v83, v84)
						end
					end
				end
				local v85 = "Want to try your luck? Spin for a random skill book. Each spin costs more than the last, and the price resets after 24 hours.\n\nCurrent spin price: " .. tostring(v74) .. " $" .. v75
				local v86 = LoadOptions(v_u_39, {
					["Spin"] = {
						["Order"] = 1
					},
					["..."] = {
						["Order"] = 2
					}
				})
				v_u_10.Spin = v86[1].Click.MouseButton1Click:Connect(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35, (ref) v_u_5
					for _, v87 in pairs(v_u_10) do
						v87:Disconnect()
					end
					RemoveOptions(v_u_39)
					FrameMovement(v_u_35, false)
					if v_u_5 and v_u_5.FireServer then
						pcall(function()
							-- upvalues: (ref) v_u_5
							v_u_5:FireServer("RequestSpin")
						end)
					end
				end)
				v_u_10["..."] = v86[2].Click.MouseButton1Click:Connect(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
					for _, v88 in pairs(v_u_10) do
						v88:Disconnect()
					end
					RemoveOptions(v_u_39)
					wait(0.45)
					FrameMovement(v_u_35, false)
				end)
				Speaking(v_u_39, v85)
				wait(0.25)
				return
			elseif v_u_35.Type == "Yune" then
				local v89 = {}
				if v_u_5 and v_u_5.InvokeServer then
					local v90, v91 = pcall(function()
						-- upvalues: (ref) v_u_5
						return v_u_5:InvokeServer("GetBiHuynhQuestState")
					end)
					if v90 then
						v89 = v91 or v89
					end
				end
				local v92
				if v89.YuneCompleted then
					v92 = "Alright\226\128\166 you did it. Go tell my brother. I\'ll head home right away"
				elseif v89.YuneStarted then
					local v93 = LoadOptions(v_u_39, {
						["Give Water Buffalo Grass Fish (367kg+)"] = {
							["Order"] = 1
						},
						["..."] = {
							["Order"] = 2
						}
					})
					v_u_10["Give Water Buffalo Grass Fish (367kg+)"] = v93[1].Click.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
						for _, v94 in pairs(v_u_10) do
							v94:Disconnect()
						end
						RemoveOptions(v_u_39)
						local v96, v97 = pcall(function()
							-- upvalues: (ref) v_u_5
							local v95 = v_u_5 and v_u_5.InvokeServer
							if v95 then
								v95 = v_u_5:InvokeServer("GiveFishToYune")
							end
							return v95
						end)
						Speaking(v_u_39, v96 and v97 and "Alright\226\128\166 you did it. Go tell my brother. I\'ll head home right away" or "You need Water Buffalo Grass Fish weighing over 367kg in your backpack!")
						wait(0.45)
						FrameMovement(v_u_35, false)
					end)
					v_u_10["..."] = v93[2].Click.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
						for _, v98 in pairs(v_u_10) do
							v98:Disconnect()
						end
						RemoveOptions(v_u_39)
						wait(0.45)
						FrameMovement(v_u_35, false)
					end)
					v92 = "Yeah right\226\128\166 just another loudmouth like all the others who came before you. Fine. Go on, catch it and bring it here \226\128\148 then we\'ll talk."
				elseif v89.Talked then
					local v99 = LoadOptions(v_u_39, {
						["Alright, I\'ll help you land that fish."] = {
							["Order"] = 1
						},
						["..."] = {
							["Order"] = 2
						}
					})
					v_u_10["Alright, I\'ll help you land that fish."] = v99[1].Click.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
						for _, v100 in pairs(v_u_10) do
							v100:Disconnect()
						end
						RemoveOptions(v_u_39)
						if v_u_5 and v_u_5.InvokeServer then
							pcall(function()
								-- upvalues: (ref) v_u_5
								v_u_5:InvokeServer("BiHuynhYuneStarted")
							end)
						end
						Speaking(v_u_39, "Yeah right\226\128\166 just another loudmouth like all the others who came before you. Fine. Go on, catch it and bring it here \226\128\148 then we\'ll talk.")
						wait(0.45)
						FrameMovement(v_u_35, false)
					end)
					v_u_10["..."] = v99[2].Click.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
						for _, v101 in pairs(v_u_10) do
							v101:Disconnect()
						end
						RemoveOptions(v_u_39)
						wait(0.45)
						FrameMovement(v_u_35, false)
					end)
					v92 = "What is it this time\226\128\166? Did my brother send you to drag me back home? Forget it \226\128\148 I\'m busy. I\'m not going anywhere until I catch the biggest fish in this area. When I do, I\'ll go home on my own"
				else
					v92 = "I can tell just by looking at you \226\128\148 you\'re nowhere near as good at fishing as my boyfriend, hehe."
				end
				if not v89.YuneStarted or v89.YuneCompleted then
					v_u_10["..."] = LoadOptions(v_u_39, {
						["..."] = {
							["Order"] = 1
						}
					})[1].Click.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
						for _, v102 in pairs(v_u_10) do
							v102:Disconnect()
						end
						RemoveOptions(v_u_39)
						wait(0.45)
						FrameMovement(v_u_35, false)
					end)
				end
				Speaking(v_u_39, v92)
				wait(0.25)
				return
			else
				if v_u_35.Type == "Homeless" then
					local v103 = LoadOptions(v_u_39, {
						["Yes"] = {
							["Order"] = 1
						},
						["..."] = {
							["Order"] = 2
						}
					})
					v_u_10.Yes = v103[1].Click.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
						for _, v104 in pairs(v_u_10) do
							v104:Disconnect()
						end
						_G.Controllers.SkillShop:Activate()
						RemoveOptions(v_u_39)
						wait(0.45)
						FrameMovement(v_u_35, false)
					end)
					v_u_10["..."] = v103[2].Click.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
						for _, v105 in pairs(v_u_10) do
							v105:Disconnect()
						end
						RemoveOptions(v_u_39)
						wait(0.45)
						FrameMovement(v_u_35, false)
					end)
					v40 = "Wanna buy something?"
				end
				if v_u_35.Type == "Island4Quest" then
					local v106 = {}
					local v107 = nil
					local v108 = nil
					local v109
					if v_u_5 and v_u_5.InvokeServer then
						local v110, v111 = pcall(function()
							-- upvalues: (ref) v_u_5
							return v_u_5:InvokeServer("GetIsland4QuestState")
						end)
						if v110 then
							v106 = v111 or v106
						end
						local v112, v113 = pcall(function()
							-- upvalues: (ref) v_u_5
							return v_u_5:InvokeServer("GetBiHuynhQuestState")
						end)
						v107 = v112 and v113 and v113 or v107
						local v114
						v114, v109 = pcall(function()
							-- upvalues: (ref) v_u_5
							return v_u_5:InvokeServer("GetIsland5QuestState")
						end)
						if v114 then
							if not v109 then
								v109 = v108
							end
						else
							v109 = v108
						end
					else
						v109 = v108
					end
					local v115 = v106.PlayerLevel or 0
					local v116 = v107 and (v107.Talked or v107.YuneStarted or v107.YuneCompleted)
					if v116 then
						v116 = not v107.RewardReceived
					end
					local v117 = v109 and v109.Accepted
					if v117 then
						v117 = not v109.RewardReceived
					end
					local v118 = v116 or v117
					local v119 = v106.CaughtCount or 0
					local v120 = v106.RequiredCount or 4
					local v121
					if v106.RewardReceived then
						v121 = "You\'ve proven yourself. Island 4 is open to you. Good luck, fisherman."
					elseif v106.Completed then
						local v122 = LoadOptions(v_u_39, {
							["Claim Island 4 Access"] = {
								["Order"] = 1
							},
							["Cancel quest"] = {
								["Order"] = 2
							},
							["..."] = {
								["Order"] = 3
							}
						})
						v_u_10["Claim Island 4 Access"] = v122[1].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
							for _, v123 in pairs(v_u_10) do
								v123:Disconnect()
							end
							RemoveOptions(v_u_39)
							local v125, v126 = pcall(function()
								-- upvalues: (ref) v_u_5
								local v124 = v_u_5 and v_u_5.InvokeServer
								if v124 then
									v124 = v_u_5:InvokeServer("ClaimIsland4Reward")
								end
								return v124
							end)
							Speaking(v_u_39, v125 and v126 and "Island 4 is now unlocked. Go catch the rarest fish!" or "Something went wrong. Try again.")
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v_u_10["Cancel quest"] = v122[2].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
							for _, v127 in pairs(v_u_10) do
								v127:Disconnect()
							end
							RemoveOptions(v_u_39)
							local v129, v130 = pcall(function()
								-- upvalues: (ref) v_u_5
								local v128 = v_u_5 and v_u_5.InvokeServer
								if v128 then
									v128 = v_u_5:InvokeServer("CancelIsland4Quest")
								end
								return v128
							end)
							Speaking(v_u_39, v129 and v130 and "Quest cancelled. You can accept again when ready." or "Failed to cancel.")
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v_u_10["..."] = v122[3].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
							for _, v131 in pairs(v_u_10) do
								v131:Disconnect()
							end
							RemoveOptions(v_u_39)
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v121 = "Incredible! You\'ve caught enough legendary fish over 480kg from Island 3. You\'ve earned the right to fish at Island 4."
					elseif v106.Accepted then
						v121 = string.format("Island 4 Quest: Catch legendary fish over 480kg from Island 3.\n\nProgress: %d/%d", v119, v120)
						local v132 = LoadOptions(v_u_39, {
							["Cancel quest"] = {
								["Order"] = 1
							},
							["..."] = {
								["Order"] = 2
							}
						})
						v_u_10["Cancel quest"] = v132[1].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
							for _, v133 in pairs(v_u_10) do
								v133:Disconnect()
							end
							RemoveOptions(v_u_39)
							local v135, v136 = pcall(function()
								-- upvalues: (ref) v_u_5
								local v134 = v_u_5 and v_u_5.InvokeServer
								if v134 then
									v134 = v_u_5:InvokeServer("CancelIsland4Quest")
								end
								return v134
							end)
							Speaking(v_u_39, v135 and v136 and "Quest cancelled. You can accept again when ready." or "Failed to cancel.")
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v_u_10["..."] = v132[2].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
							for _, v137 in pairs(v_u_10) do
								v137:Disconnect()
							end
							RemoveOptions(v_u_39)
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
					elseif v118 then
						v_u_10["..."] = LoadOptions(v_u_39, {
							["..."] = {
								["Order"] = 1
							}
						})[1].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
							for _, v138 in pairs(v_u_10) do
								v138:Disconnect()
							end
							RemoveOptions(v_u_39)
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v121 = v116 and "You must complete Bi Huynh quest first" or "You must complete Island 5 quest first"
					elseif v115 < 40 then
						v_u_10["..."] = LoadOptions(v_u_39, {
							["..."] = {
								["Order"] = 1
							}
						})[1].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
							for _, v139 in pairs(v_u_10) do
								v139:Disconnect()
							end
							RemoveOptions(v_u_39)
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v121 = "To unlock Island 4, you must prove your skill by catching legendary fish over 480kg from Island 3. You need Level 40 to accept this quest."
					else
						v121 = "To unlock Island 4, you must catch legendary fish over 480kg from Island 3. Catch " .. tostring(v120) .. " legendary fish to complete this quest. Do you accept this challenge?"
						local v140 = LoadOptions(v_u_39, {
							["Accept"] = {
								["Order"] = 1
							},
							["Decline"] = {
								["Order"] = 2
							}
						})
						v_u_10.Accept = v140[1].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
							for _, v141 in pairs(v_u_10) do
								v141:Disconnect()
							end
							RemoveOptions(v_u_39)
							local v143, v144 = pcall(function()
								-- upvalues: (ref) v_u_5
								local v142 = v_u_5 and v_u_5.InvokeServer
								if v142 then
									v142 = v_u_5:InvokeServer("AcceptIsland4Quest")
								end
								return v142
							end)
							Speaking(v_u_39, v143 and v144 and "Good luck! Catch legendary fish (480kg+) from Island 3 and return here for your reward." or "Failed to accept quest.")
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v_u_10.Decline = v140[2].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
							for _, v145 in pairs(v_u_10) do
								v145:Disconnect()
							end
							RemoveOptions(v_u_39)
							Speaking(v_u_39, "Come back when you\'re ready.")
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
					end
					Speaking(v_u_39, v121 or "...")
					wait(0.25)
					return
				elseif v_u_35.Type == "Island5Quest" then
					local v146 = {}
					local v147 = nil
					local v148 = nil
					local v149
					if v_u_5 and v_u_5.InvokeServer then
						local v150, v151 = pcall(function()
							-- upvalues: (ref) v_u_5
							return v_u_5:InvokeServer("GetIsland5QuestState")
						end)
						if v150 then
							v146 = v151 or v146
						end
						local v152, v153 = pcall(function()
							-- upvalues: (ref) v_u_5
							return v_u_5:InvokeServer("GetBiHuynhQuestState")
						end)
						v147 = v152 and v153 and v153 or v147
						local v154
						v154, v149 = pcall(function()
							-- upvalues: (ref) v_u_5
							return v_u_5:InvokeServer("GetIsland4QuestState")
						end)
						if v154 then
							if not v149 then
								v149 = v148
							end
						else
							v149 = v148
						end
					else
						v149 = v148
					end
					local v155 = v146.PlayerLevel or 0
					local v156 = v147 and (v147.Talked or v147.YuneStarted or v147.YuneCompleted)
					if v156 then
						v156 = not v147.RewardReceived
					end
					local v157 = v149 and v149.Accepted
					if v157 then
						v157 = not v149.RewardReceived
					end
					local v158 = v156 or v157
					local v159
					if v146.RewardReceived then
						FrameMovement(v_u_35, false)
						v159 = "Well done! Now go explore this island.\n\nOh wait, I almost forgot. I\226\128\153ll give you my family\226\128\153s heirloom fishing rod. With that rod of yours, the fish here would probably snap it in half! \240\159\152\134\240\159\142\163"
					elseif v146.Completed then
						local v160 = LoadOptions(v_u_39, {
							["Claim Titanium Steel Rod"] = {
								["Order"] = 1
							},
							["Cancel quest"] = {
								["Order"] = 2
							},
							["..."] = {
								["Order"] = 3
							}
						})
						v_u_10["Claim Titanium Steel Rod"] = v160[1].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
							for _, v161 in pairs(v_u_10) do
								v161:Disconnect()
							end
							RemoveOptions(v_u_39)
							local v163, v164 = pcall(function()
								-- upvalues: (ref) v_u_5
								local v162 = v_u_5 and v_u_5.InvokeServer
								if v162 then
									v162 = v_u_5:InvokeServer("ClaimIsland5Reward")
								end
								return v162
							end)
							Speaking(v_u_39, v163 and v164 and "Well done! Now go explore this island.\n\nOh wait, I almost forgot. I\226\128\153ll give you my family\226\128\153s heirloom fishing rod. With that rod of yours, the fish here would probably snap it in half! \240\159\152\134\240\159\142\163" or "Something went wrong. Try again.")
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v_u_10["Cancel quest"] = v160[2].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
							for _, v165 in pairs(v_u_10) do
								v165:Disconnect()
							end
							RemoveOptions(v_u_39)
							local v167, v168 = pcall(function()
								-- upvalues: (ref) v_u_5
								local v166 = v_u_5 and v_u_5.InvokeServer
								if v166 then
									v166 = v_u_5:InvokeServer("CancelIsland5Quest")
								end
								return v166
							end)
							Speaking(v_u_39, v167 and v168 and "Quest cancelled. You can accept again when ready." or "Failed to cancel.")
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v_u_10["..."] = v160[3].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
							for _, v169 in pairs(v_u_10) do
								v169:Disconnect()
							end
							RemoveOptions(v_u_39)
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v159 = "Well done! Now go explore this island.\n\nOh wait, I almost forgot. I\226\128\153ll give you my family\226\128\153s heirloom fishing rod. With that rod of yours, the fish here would probably snap it in half! \240\159\152\134\240\159\142\163"
					elseif v146.Accepted then
						local v170 = v146.CaughtCount or 0
						local v171 = v146.TotalRequired or 3
						local v172 = v146.CaughtList or {}
						local v173 = v146.RemainingList or {}
						local v174 = #v172 > 0 and "\196\144\195\163 c\195\162u: " .. table.concat(v172, ", ") or "\196\144\195\163 c\195\162u: (ch\198\176a c\195\179)"
						local v175 = #v173 > 0 and "C\225\186\167n c\195\162u: " .. table.concat(v173, ", ") or ""
						local v176 = v146.QuestType == "old" and "C\195\162u Legendary \196\145\225\186\163o 1,2,3,4 (>=580kg)" or "C\195\162u 3 c\195\161 Legendary \196\145\225\186\163o 5 (>=585kg)"
						v159 = string.format("Island 5 Quest: %s.\n\nProgress: %d/%d\n\n%s\n%s", v176, v170, v171, v174, v175)
						local v177 = LoadOptions(v_u_39, {
							["Cancel quest"] = {
								["Order"] = 1
							},
							["..."] = {
								["Order"] = 2
							}
						})
						v_u_10["Cancel quest"] = v177[1].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
							for _, v178 in pairs(v_u_10) do
								v178:Disconnect()
							end
							RemoveOptions(v_u_39)
							local v180, v181 = pcall(function()
								-- upvalues: (ref) v_u_5
								local v179 = v_u_5 and v_u_5.InvokeServer
								if v179 then
									v179 = v_u_5:InvokeServer("CancelIsland5Quest")
								end
								return v179
							end)
							Speaking(v_u_39, v180 and v181 and "Quest cancelled. You can accept again when ready." or "Failed to cancel.")
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v_u_10["..."] = v177[2].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
							for _, v182 in pairs(v_u_10) do
								v182:Disconnect()
							end
							RemoveOptions(v_u_39)
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
					elseif v158 then
						v159 = v156 and "You must complete Bi Huynh quest first" or "You must complete Island 4 quest first"
					elseif v146.HasIsland5Ticket then
						if v155 < 60 then
							v_u_10["..."] = LoadOptions(v_u_39, {
								["..."] = {
									["Order"] = 1
								}
							})[1].Click.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
								for _, v183 in pairs(v_u_10) do
									v183:Disconnect()
								end
								RemoveOptions(v_u_39)
								wait(0.45)
								FrameMovement(v_u_35, false)
							end)
							v159 = "You don\226\128\153t even have the skill, and you dare come here to fish?! Go back now, or I\226\128\153ll call the fish out to devour you ! \240\159\153\130"
						else
							local v184 = LoadOptions(v_u_39, {
								["Accept"] = {
									["Order"] = 1
								},
								["Decline"] = {
									["Order"] = 2
								}
							})
							v_u_10.Accept = v184[1].Click.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_5, (copy) v_u_35
								for _, v185 in pairs(v_u_10) do
									v185:Disconnect()
								end
								RemoveOptions(v_u_39)
								local v187, v188 = pcall(function()
									-- upvalues: (ref) v_u_5
									local v186 = v_u_5 and v_u_5.InvokeServer
									if v186 then
										v186 = v_u_5:InvokeServer("AcceptIsland5Quest")
									end
									return v186
								end)
								Speaking(v_u_39, v187 and v188 and "Hurry up, my friend! Catch all 3 Legendary fish from Island 5 (585kg+)!" or "Something went wrong. Try again.")
								wait(0.45)
								FrameMovement(v_u_35, false)
							end)
							v_u_10.Decline = v184[2].Click.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
								for _, v189 in pairs(v_u_10) do
									v189:Disconnect()
								end
								RemoveOptions(v_u_39)
								Speaking(v_u_39, "Come back when you\'re ready for the final challenge.")
								wait(0.45)
								FrameMovement(v_u_35, false)
							end)
							v159 = "Catch all 3 Legendary fish from Island 5 weighing 585kg or more and bring them here. I will give you my family\226\128\153s heirloom fishing rod \226\128\148 the Titanium Steel Rod! \240\159\152\132"
						end
					else
						v_u_10["..."] = LoadOptions(v_u_39, {
							["..."] = {
								["Order"] = 1
							}
						})[1].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
							for _, v190 in pairs(v_u_10) do
								v190:Disconnect()
							end
							RemoveOptions(v_u_39)
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
						v159 = "You need Island 5 ticket to accept this quest. Go buy it first!"
					end
					if not v146.Accepted and (v155 < 60 or v158) then
						v_u_10["..."] = LoadOptions(v_u_39, {
							["..."] = {
								["Order"] = 1
							}
						})[1].Click.MouseButton1Click:Connect(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_39, (copy) v_u_35
							for _, v191 in pairs(v_u_10) do
								v191:Disconnect()
							end
							RemoveOptions(v_u_39)
							wait(0.45)
							FrameMovement(v_u_35, false)
						end)
					end
					Speaking(v_u_39, v159)
					wait(0.25)
				else
					Speaking(v_u_39, v40)
					wait(0.2)
					if v_u_35.Type == "Quest" then
						local v192 = v_u_35.Details
						local v_u_193 = LoadOptions(v_u_39, v192)
						local function v_u_196()
							-- upvalues: (ref) v_u_193, (copy) v_u_39, (ref) v_u_10, (copy) v_u_35
							v_u_193 = LoadOptions(v_u_39, true)
							for _, v_u_194 in pairs(v_u_193) do
								v_u_10[v_u_194.Name] = v_u_194.Click.MouseButton1Click:Connect(function()
									-- upvalues: (ref) v_u_10, (ref) v_u_39, (copy) v_u_194, (ref) v_u_35
									for _, v195 in pairs(v_u_10) do
										v195:Disconnect()
									end
									RemoveOptions(v_u_39)
									if v_u_194.Name == "Accept" then
										Speaking(v_u_39, "Good luck.")
									else
										Speaking(v_u_39, "Come back next time.")
									end
									wait(0.45)
									FrameMovement(v_u_35, false)
								end)
							end
						end
						for _, v_u_197 in pairs(v_u_193) do
							local v_u_198 = v192[v_u_197.Name]
							v_u_10[v_u_197.Name] = v_u_197.Click.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_10, (copy) v_u_39, (ref) v_u_8, (copy) v_u_197, (copy) v_u_198, (copy) v_u_196
								for _, v199 in pairs(v_u_10) do
									v199:Disconnect()
								end
								RemoveOptions(v_u_39, false)
								v_u_8 = v_u_197.Name
								Speaking(v_u_39, v_u_198.Description:format(v_u_198.Maximum, v_u_198.Requirement, v_u_198.Rewards.Beli, v_u_198.Rewards.Experience))
								wait(0.2)
								v_u_196()
							end)
						end
						v_u_196()
					end
				end
			end
		else
			v_u_11 = false
			return
		end
	end
end
function v_u_4.Init(p200)
	-- upvalues: (ref) v_u_5
	v_u_5 = p200.Shared.Network
end
v_u_7.OnClientEvent:connect(function(p201, ...)
	-- upvalues: (copy) v_u_4
	if v_u_4[p201] then
		v_u_4[p201](...)
	end
end)
return v_u_4