-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return {
	["Init"] = function(p1)
		local v2 = p1.Shared.Network
		local v_u_3 = game.ReplicatedStorage.Assets.Output
		v2:BindEvents({
			["callOutput"] = function(p4, p5, ...)
				-- upvalues: (copy) v_u_3
				if v_u_3:FindFirstChild(p4) then
					require(v_u_3:FindFirstChild(p4))[p5](...)
				end
			end
		})
	end
}