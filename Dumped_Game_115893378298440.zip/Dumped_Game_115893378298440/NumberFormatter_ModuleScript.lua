-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = {
	"k",
	"M",
	"B",
	"T",
	"qd",
	"Qn",
	"sx",
	"Sp",
	"O",
	"N",
	"de"
}
function v1.Format(p3)
	-- upvalues: (copy) v_u_2
	if not p3 then
		return "0"
	end
	local v4 = math.floor(p3)
	if v4 < 1000 then
		return tostring(v4)
	end
	local v5 = math.log(v4, 1000)
	local v6 = math.floor(v5)
	local v7 = v6 * 3
	local v8 = v4 / math.pow(10, v7)
	return string.format("%.1f", v8):gsub("%.0$", "") .. (v_u_2[v6] or "??")
end
return v1