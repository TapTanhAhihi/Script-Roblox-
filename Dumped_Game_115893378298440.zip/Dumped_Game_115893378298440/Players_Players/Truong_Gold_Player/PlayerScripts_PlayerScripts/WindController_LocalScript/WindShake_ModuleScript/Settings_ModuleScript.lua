-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return {
	["new"] = function(p_u_1)
		local v_u_2 = {}
		local v_u_3 = p_u_1:GetAttribute("WindPower")
		local v_u_4 = p_u_1:GetAttribute("WindSpeed")
		local v_u_5 = p_u_1:GetAttribute("WindDirection")
		local v6
		if type(v_u_3) == "number" then
			v6 = v_u_3
		else
			v6 = nil
		end
		v_u_2.WindPower = v6
		local v7
		if type(v_u_4) == "number" then
			v7 = v_u_4
		else
			v7 = nil
		end
		v_u_2.WindSpeed = v7
		local v8
		if typeof(v_u_5) == "Vector3" then
			local v9 = v_u_5
			v8 = v9.Magnitude > 0 and v9.Unit or Vector3.new(0, 0, 0)
		else
			v8 = nil
		end
		v_u_2.WindDirection = v8
		local v10
		if p_u_1:IsA("BasePart") then
			v10 = p_u_1.PivotOffset
		else
			v10 = nil
		end
		v_u_2.PivotOffset = v10
		local v11
		if v_u_2.PivotOffset then
			v11 = v_u_2.PivotOffset:Inverse()
		else
			v11 = nil
		end
		v_u_2.PivotOffsetInverse = v11
		local v_u_22 = {
			["PowerConnection"] = p_u_1:GetAttributeChangedSignal("WindPower"):Connect(function()
				-- upvalues: (ref) v_u_3, (copy) p_u_1, (copy) v_u_2
				v_u_3 = p_u_1:GetAttribute("WindPower")
				local v12 = v_u_2
				local v13 = v_u_3
				local v14
				if type(v13) == "number" then
					v14 = v_u_3
				else
					v14 = nil
				end
				v12.WindPower = v14
			end),
			["SpeedConnection"] = p_u_1:GetAttributeChangedSignal("WindSpeed"):Connect(function()
				-- upvalues: (ref) v_u_4, (copy) p_u_1, (copy) v_u_2
				v_u_4 = p_u_1:GetAttribute("WindSpeed")
				local v15 = v_u_2
				local v16 = v_u_4
				local v17
				if type(v16) == "number" then
					v17 = v_u_4
				else
					v17 = nil
				end
				v15.WindSpeed = v17
			end),
			["DirectionConnection"] = p_u_1:GetAttributeChangedSignal("WindDirection"):Connect(function()
				-- upvalues: (ref) v_u_5, (copy) p_u_1, (copy) v_u_2
				v_u_5 = p_u_1:GetAttribute("WindDirection")
				local v18 = v_u_2
				local v19 = v_u_5
				local v20
				if typeof(v19) == "Vector3" then
					local v21 = v_u_5
					v20 = v21.Magnitude > 0 and v21.Unit or Vector3.new(0, 0, 0)
				else
					v20 = nil
				end
				v18.WindDirection = v20
			end)
		}
		if p_u_1:IsA("BasePart") then
			v_u_22.PivotConnection = p_u_1:GetPropertyChangedSignal("PivotOffset"):Connect(function()
				-- upvalues: (copy) p_u_1, (copy) v_u_2
				local v23 = p_u_1.PivotOffset
				v_u_2.PivotOffset = v23
				v_u_2.PivotOffsetInverse = v23:Inverse()
			end)
		end
		function v_u_2.Destroy(_)
			-- upvalues: (copy) v_u_22
			for _, v24 in pairs(v_u_22) do
				v24:Disconnect()
			end
		end
		return v_u_2
	end
}