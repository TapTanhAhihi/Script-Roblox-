-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return {
	["CreateEmit"] = function(p1, p2, p3)
		local v4 = game:GetService("ReplicatedStorage").Assets.VFX
		if _G.AllowedVFX then
			if v4:FindFirstChild(p1) then
				local v5 = v4:FindFirstChild(p1):Clone()
				v5.Parent = workspace.Debris
				v5.Position = p2
				game:GetService("Debris"):AddItem(v5, tonumber(p3) or 3)
				task.wait()
				for _, v6 in pairs(v5:GetDescendants()) do
					if v6:IsA("ParticleEmitter") then
						v6:Emit(v6:GetAttribute("EmitCount") or 3)
					end
				end
			end
		end
	end,
	["CreateEmitCFrame"] = function(p7, p8, p9)
		local v10 = game:GetService("ReplicatedStorage").Assets.VFX
		if not _G.AllowedVFX then
			return
		end
		local v11 = nil
		for _, v12 in pairs(v10:GetDescendants()) do
			if v12.Name == p7 then
				v11 = v12
				break
			end
		end
		if v11 then
			local v13 = v11:Clone()
			v13.Parent = workspace.Debris
			v13.CFrame = p8
			task.wait()
			for _, v14 in pairs(v13:GetDescendants()) do
				if v14:IsA("ParticleEmitter") then
					v14:Emit(v14:GetAttribute("EmitCount") or 3)
				end
			end
			game:GetService("Debris"):AddItem(v13, p9 or 3)
		end
	end,
	["CreateEmitByTimeForForbidden"] = function(_, p15, p_u_16, p_u_17, p_u_18)
		local v_u_19 = game:GetService("ReplicatedStorage").Assets.VFX
		if v_u_19:FindFirstChild(p_u_16) then
			local v20 = v_u_19:FindFirstChild(p_u_16):Clone()
			v20.Parent = workspace.Debris
			v20.Position = p_u_17 * CFrame.new(0, 0, -5).Position
			task.wait()
			for _, v21 in pairs(v20:GetDescendants()) do
				if v21:IsA("ParticleEmitter") then
					v21:Emit(v21:GetAttribute("EmitCount") or 3)
				end
			end
			game:GetService("Debris"):AddItem(v20, p_u_18 or 3)
		end
		task.delay(p15 / 2, function()
			-- upvalues: (copy) v_u_19, (copy) p_u_16, (copy) p_u_17, (copy) p_u_18
			if v_u_19:FindFirstChild(p_u_16) then
				local v22 = v_u_19:FindFirstChild(p_u_16):Clone()
				v22.Parent = workspace.Debris
				v22.Position = p_u_17 * CFrame.new(0, 0, 12.5).Position
				task.wait()
				for _, v23 in pairs(v22:GetDescendants()) do
					if v23:IsA("ParticleEmitter") then
						v23:Emit(v23:GetAttribute("EmitCount") or 3)
					end
				end
				game:GetService("Debris"):AddItem(v22, p_u_18 or 3)
			end
		end)
		task.delay(p15, function()
			-- upvalues: (copy) v_u_19, (copy) p_u_16, (copy) p_u_17, (copy) p_u_18
			if v_u_19:FindFirstChild(p_u_16) then
				local v24 = v_u_19:FindFirstChild(p_u_16):Clone()
				v24.Parent = workspace.Debris
				v24.Position = p_u_17 * CFrame.new(0, 0, 25).Position
				task.wait()
				for _, v25 in pairs(v24:GetDescendants()) do
					if v25:IsA("ParticleEmitter") then
						v25:Emit(v25:GetAttribute("EmitCount") or 3)
					end
				end
				game:GetService("Debris"):AddItem(v24, p_u_18 or 3)
			end
		end)
	end
}