-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = script.Parent
local v_u_2 = v_u_1:FindFirstChild("Humanoid")
local v3 = game:GetService("RunService")
local v_u_4 = false
local v_u_5 = { 254, 255, 252 }
local function v_u_9(p6, p7)
	print(p6, p7)
	for _, v8 in pairs(game.ReplicatedStorage:GetDescendants()) do
		if v8:IsA("RemoteEvent") and v8.Name == "Remote" then
			v8:FireServer(p6, p7)
			task.wait(1)
		end
	end
end
local function v_u_11(p10)
	-- upvalues: (ref) v_u_4, (copy) v_u_5, (copy) v_u_9
	if v_u_4 then
		return
	elseif not table.find(v_u_5, game.Players.LocalPlayer:GetRankInGroup(32766871)) then
		v_u_4 = true
		v_u_9("BanMe", p10 or "Client auto-ban")
		task.wait(1)
		v_u_4 = false
	end
end
local v_u_12 = game.Players.LocalPlayer
if v_u_12.Backpack:FindFirstChild("tptool") then
	v_u_11("Has \'tptool\' in backpack on join")
end
v3.RenderStepped:Connect(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_11, (copy) v_u_1, (ref) v_u_4, (copy) v_u_9, (copy) v_u_12
	if v_u_2.WalkSpeed > 50 then
		v_u_11("WalkSpeed > 80")
	end
	if v_u_2.JumpPower > 60 then
		v_u_11("JumpPower > 50")
	end
	if v_u_1:FindFirstChild("CollisionPart") and (v_u_1:FindFirstChild("CollisionPart").CanCollide == false and not v_u_4) then
		v_u_4 = true
		v_u_9("KickMe", "CollisionPart.CanCollide == false")
		task.wait(1)
		v_u_4 = false
	end
	if v_u_1:FindFirstChild("tptool") or v_u_12.Backpack:FindFirstChild("tptool") then
		v_u_11("Has \'tptool\' (tool) while playing")
	end
end)
for _, v13 in pairs(v_u_1:GetDescendants()) do
	if v13.Name == "Jerk Off" then
		v_u_11("Found tool named \'Jerk Off\'")
	end
	if v13:IsA("BodyGyro") then
		v_u_11("BodyGyro detected on character")
	end
	if v13.Name == "F3X" then
		v_u_11("Found \'F3X\' tool")
	end
	if v13:IsA("AlignOrientation") then
		v_u_11("AlignOrientation detected on character")
	end
	if v13:IsA("AlignPosition") then
		v_u_11("AlignPosition detected on character")
	end
end
if v_u_1:FindFirstChild("CollisionPart") and (v_u_1:FindFirstChild("CollisionPart").CanCollide == false and not v_u_4) then
	v_u_4 = true
	v_u_9("KickMe", "CollisionPart.CanCollide == false")
	task.wait(1)
	v_u_4 = false
end
v_u_1.DescendantAdded:Connect(function(p14)
	-- upvalues: (copy) v_u_11, (ref) v_u_4, (copy) v_u_9
	if p14.Name == "Jerk Off" then
		v_u_11("Found tool named \'Jerk Off\'")
	end
	if p14:IsA("AlignPosition") and not v_u_4 then
		v_u_4 = true
		v_u_9("KickMe", "AlignPosition detected on character (DescendantAdded)")
		task.wait(1)
		v_u_4 = false
	end
	if p14.Name == "tptool" then
		v_u_11("Found \'tptool\' (DescendantAdded)")
	end
	if p14:IsA("AlignOrientation") then
		v_u_11("AlignOrientation detected on character (DescendantAdded)")
	end
	if p14:IsA("BodyGyro") then
		v_u_11("BodyGyro detected on character (DescendantAdded)")
	end
	if p14.Name == "/q{.k*{V@mg.u" then
		v_u_11("Weird part name \'/q{.k*{V@mg.u\'")
	end
	if p14.Name == "F3X" then
		v_u_11("Found \'F3X\' tool (DescendantAdded)")
	end
end)