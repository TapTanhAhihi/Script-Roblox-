-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = script.Parent.Toggle
local _ = v_u_1.On
local _ = v_u_1.Off
local v_u_2 = true
local v3 = v_u_1.ActiveButton
local v_u_4 = game.Lighting
local function v_u_8(p5)
	-- upvalues: (copy) v_u_4
	if p5 then
		v_u_4.GlobalShadows = false
		v_u_4.Brightness = 2
		v_u_4.EnvironmentDiffuseScale = 0
		v_u_4.EnvironmentSpecularScale = 0
		for _, v6 in ipairs(workspace:GetDescendants()) do
			if v6:IsA("Texture") or v6:IsA("SurfaceAppearance") then
				v6:Destroy()
			end
			if v6:IsA("BasePart") then
				v6.CastShadow = false
				v6.Material = Enum.Material.Plastic
			end
			if v6:IsA("ParticleEmitter") or (v6:IsA("Trail") or v6:IsA("Beam")) then
				v6.Enabled = false
			end
		end
	else
		v_u_4.GlobalShadows = true
		v_u_4.EnvironmentDiffuseScale = 1
		v_u_4.EnvironmentSpecularScale = 1
		for _, v7 in ipairs(workspace:GetDescendants()) do
			if v7:IsA("ParticleEmitter") or (v7:IsA("Trail") or v7:IsA("Beam")) then
				v7.Enabled = true
			end
		end
	end
end
v3.Activated:Connect(function()
	-- upvalues: (ref) v_u_2, (copy) v_u_8, (copy) v_u_1
	v_u_2 = not v_u_2
	v_u_8(v_u_2)
	if v_u_2 then
		v_u_1.On.Visible = true
		v_u_1.Off.Visible = false
	else
		v_u_1.On.Visible = false
		v_u_1.Off.Visible = true
	end
end)