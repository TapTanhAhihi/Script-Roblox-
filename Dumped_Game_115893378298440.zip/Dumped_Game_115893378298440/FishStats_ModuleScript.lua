-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return {
	["Init"] = function(p1)
		game:GetService("ReplicatedStorage")
		local v_u_2 = game:GetService("TweenService")
		local v3 = p1.Shared.Network
		local v_u_4 = game.Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("FishStats")
		local v_u_5 = v_u_4.HealthFrame
		local v_u_6 = v_u_4.DistanceFrame
		local v_u_7 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		local v_u_8 = nil
		local v_u_9 = nil
		v3:BindEvents({
			["SendInformation"] = function(p10, p11, p12)
				-- upvalues: (copy) v_u_5, (copy) v_u_6
				v_u_5.FishName.Text = p10 .. " [" .. (p11 or 100) .. "]"
				v_u_5.Visible = true
				v_u_6.Visible = true
				v_u_5.Fill.Size = UDim2.new(1, 0, 1, 0)
				v_u_6.Fill.Size = UDim2.new(0, 0, 1, 0)
				v_u_5.HealthText.Text = p12 .. "/" .. p12
				v_u_6.HealthText.Text = "0m/50m"
			end,
			["UpdateHealth"] = function(p13, p14)
				-- upvalues: (ref) v_u_8, (copy) v_u_2, (copy) v_u_5, (copy) v_u_7
				if v_u_8 then
					v_u_8:Cancel()
				end
				local v15 = v_u_2
				local v16 = v_u_5.Fill
				local v17 = v_u_7
				local v18 = {}
				local v19 = UDim2.new
				local v20 = p13 / p14
				v18.Size = v19(math.clamp(v20, 0, 1), 0, 1, 0)
				v_u_8 = v15:Create(v16, v17, v18)
				v_u_8:Play()
				v_u_5.HealthText.Text = math.floor(p13) .. "/" .. p14
			end,
			["UpdateDistance"] = function(p21)
				-- upvalues: (ref) v_u_9, (copy) v_u_2, (copy) v_u_6, (copy) v_u_7
				if v_u_9 then
					v_u_9:Cancel()
				end
				local v22 = v_u_2
				local v23 = v_u_6.Fill
				local v24 = v_u_7
				local v25 = {}
				local v26 = UDim2.new
				local v27 = p21 / 50
				v25.Size = v26(math.clamp(v27, 0, 1), 0, 1, 0)
				v_u_9 = v22:Create(v23, v24, v25)
				v_u_9:Play()
				v_u_6.HealthText.Text = p21 .. "m/50m"
			end,
			["DoDamage"] = function(p28)
				-- upvalues: (copy) v_u_4, (copy) v_u_2
				local v29 = v_u_4.Health
				local v_u_30 = v29.UIListLayout.TextLabel:Clone()
				v_u_30.Parent = v29
				v_u_30.Text = "-" .. p28
				v_u_30.Size = UDim2.new(0, 0, 0, 0)
				v_u_2:Create(v_u_30, TweenInfo.new(0.15, Enum.EasingStyle.Back), {
					["Size"] = UDim2.new(1, 0, 0.35, 0)
				}):Play()
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_2, (copy) v_u_30
					v_u_2:Create(v_u_30, TweenInfo.new(0.1, Enum.EasingStyle.Back), {
						["Size"] = UDim2.new(0, 0, 0, 0)
					}):Play()
					game:GetService("Debris"):AddItem(v_u_30, 0.1)
				end)
			end,
			["DoDamage2"] = function(p31)
				-- upvalues: (copy) v_u_4
				local v32 = game:GetService("Players")
				local v33 = game:GetService("UserInputService")
				local v_u_34 = game:GetService("TweenService")
				local v_u_35 = game:GetService("Debris")
				local v36 = v32.LocalPlayer:GetMouse()
				local v37 = workspace.CurrentCamera
				local v38 = v_u_4.Health
				local v_u_39 = v38.UIListLayout.TextLabel:Clone()
				v_u_39.Parent = v38.Parent
				v_u_39.Text = "-" .. p31
				v_u_39.Size = UDim2.new(0, 0, 0, 0)
				v_u_39.AnchorPoint = Vector2.new(0.5, 0.5)
				local v40, v41
				if v33.TouchEnabled and not v33.MouseEnabled then
					local v42 = v37.ViewportSize
					v40 = math.random(v42.X * 0.2, v42.X * 0.8)
					v41 = math.random(v42.Y * 0.2, v42.Y * 0.8)
				else
					v40 = v36.X
					v41 = v36.Y
				end
				v_u_39.Position = UDim2.fromOffset(v40, v41)
				v_u_34:Create(v_u_39, TweenInfo.new(0.15, Enum.EasingStyle.Back), {
					["Size"] = UDim2.new(0.095, 0, 0.051, 0),
					["Rotation"] = math.random(-25, 25),
					["Position"] = UDim2.fromOffset(v40, v41 + 40)
				}):Play()
				task.delay(0.5, function()
					-- upvalues: (copy) v_u_34, (copy) v_u_39, (copy) v_u_35
					v_u_34:Create(v_u_39, TweenInfo.new(0.1, Enum.EasingStyle.Back), {
						["Size"] = UDim2.new(0, 0, 0, 0)
					}):Play()
					v_u_35:AddItem(v_u_39, 0.1)
				end)
			end,
			["StopFish"] = function()
				-- upvalues: (ref) v_u_8, (ref) v_u_9, (copy) v_u_5, (copy) v_u_6
				if v_u_8 then
					v_u_8:Cancel()
				end
				if v_u_9 then
					v_u_9:Cancel()
				end
				v_u_5.Visible = false
				v_u_6.Visible = false
			end
		})
	end
}