-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v2 = game:GetService("Players")
game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = v2.LocalPlayer
local v_u_8 = v_u_7.Character or v_u_7.CharacterAdded:Wait()
local v_u_9 = v_u_7:WaitForChild("PlayerGui"):WaitForChild("RodGUI"):WaitForChild("Skills")
v_u_7.CharacterAdded:Connect(function(p10)
	-- upvalues: (ref) v_u_8
	v_u_8 = p10
end)
v_u_7.CharacterAdded:Connect(function(p11)
	-- upvalues: (ref) v_u_8
	v_u_8 = p11
end)
local v_u_12 = false
local v_u_13 = {}
local v_u_14 = {
	"Z",
	"X",
	"C",
	"V"
}
local v_u_15 = {}
local v_u_16 = nil
local v_u_17 = 1
local v_u_18 = {}
local v_u_19 = {}
function v1.GetSkillsArray(_)
	-- upvalues: (ref) v_u_15
	return v_u_15
end
function v1.IsCastingSkill(_)
	-- upvalues: (ref) v_u_12
	return v_u_12
end
function v1.UpdateSkillsUI(p20, p_u_21, p22)
	-- upvalues: (ref) v_u_16, (ref) v_u_17, (ref) v_u_15, (ref) v_u_4, (ref) v_u_6, (copy) v_u_9, (copy) v_u_3, (ref) v_u_8, (copy) v_u_13, (copy) v_u_14
	v_u_16 = p_u_21
	v_u_17 = p22 or 1
	v_u_15 = {}
	local v23 = {}
	local v24 = {}
	local v25
	if v_u_4 then
		local v26, v27 = pcall(function()
			-- upvalues: (ref) v_u_4
			return v_u_4:InvokeServer("GetEquippedRodSkills")
		end)
		if v26 and (v27 and v27[p_u_21]) then
			for v28, v29 in pairs(v27[p_u_21]) do
				v23[tonumber(v28)] = v29
			end
		end
		local v30
		v30, v25 = pcall(function()
			-- upvalues: (ref) v_u_4, (copy) p_u_21
			return v_u_4:InvokeServer("GetRodSlotConfig", p_u_21)
		end)
		if v30 then
			if type(v25) ~= "table" then
				v25 = v24
			end
		else
			v25 = v24
		end
	else
		v25 = v24
	end
	local v31 = v_u_6
	if v31 then
		v31 = v_u_6.Rods
	end
	if v31 then
		v31 = v31[p_u_21]
	end
	local v32 = v_u_6
	if v32 then
		v32 = v_u_6.SlotSkills
	end
	local v33 = v_u_6
	if v33 then
		v33 = v_u_6.Skills
	end
	for v34 = 1, 4 do
		local v35 = v32 and v32[v34] and v32[v34][1] or "\195\148 " .. v34
		local v36 = 999
		local v37 = v25[v34] or v25[tostring(v34)]
		if not v37 or type(v37) ~= "table" then
			::l29::
			v39 = v31 and (v31.Slots and v31.Slots[v34]) and (v31.Slots[v34].UnlockLevel or 999) or v36
			goto l32
		end
		local v38 = v37.UnlockLevel
		if type(v38) ~= "number" then
			goto l29
		end
		local v39 = v37.UnlockLevel
		::l32::
		local v40 = v23[v34] or v23[tostring(v34)]
		local v41
		if v40 then
			local v42
			if v33 and v33[v40] then
				local v43 = v33[v40]
				if type(v43) == "table" then
					v42 = v33[v40]
				else
					v42 = nil
				end
			else
				v42 = nil
			end
			v41 = v42 or nil
		else
			v41 = nil
		end
		if v40 and not v41 then
			v40 = nil
		end
		v_u_15[v34] = {
			["SlotIndex"] = v34,
			["UnlockLevel"] = v39,
			["SkillName"] = v40,
			["Data"] = v41,
			["Name"] = v40 or v35
		}
	end
	if v31 then
		local v44 = v_u_3.TouchEnabled
		if v44 then
			v44 = not v_u_3.KeyboardEnabled
		end
		for v45 = 1, 4 do
			local v46 = v_u_9:FindFirstChild("Skill" .. v45)
			if v46 then
				local v47 = v_u_15[v45]
				v46.Visible = true
				local v48 = v47.UnlockLevel
				local v49 = v48 <= v_u_17
				if v49 and v46:FindFirstChild("Lock2") then
					v46.Lock2.Visible = false
					if v46.Lock2:FindFirstChild("ImageLabel") then
						v46.Lock2.ImageLabel.Visible = false
					end
				end
				local v50 = v46:FindFirstChild("Inside")
				local v51 = p_u_21 .. "_" .. v45
				v46.Display.Image = ""
				v46.Interactable = true
				if v47.SkillName and v47.Data then
					v46.TextLabel.Text = v47.SkillName
					local v52 = v47.Data
					local v53 = v52.RarityType
					v46.Display.Image = v52.Book
					if v52 and v53 then
						if v53 == "Common" then
							v46.BackgroundColor3 = Color3.fromRGB(131, 131, 131)
							v46.UIStroke.Color = Color3.fromRGB(131, 131, 131)
						elseif v53 == "Uncommon" then
							v46.BackgroundColor3 = Color3.fromRGB(85, 170, 255)
							v46.UIStroke.Color = Color3.fromRGB(78, 116, 255)
						elseif v53 == "Rare" then
							v46.BackgroundColor3 = Color3.fromRGB(170, 85, 255)
							v46.UIStroke.Color = Color3.fromRGB(85, 0, 127)
						elseif v53 == "Legendary" then
							v46.BackgroundColor3 = Color3.fromRGB(255, 195, 43)
							v46.UIStroke.Color = Color3.fromRGB(255, 130, 47)
						elseif v53 == "Mythical" then
							v46.BackgroundColor3 = Color3.fromRGB(255, 83, 86)
							v46.UIStroke.Color = Color3.fromRGB(170, 0, 0)
						end
					end
				else
					local v54 = v46.TextLabel
					local v55 = ""
					v54.Text = v55
				end
				if v50 and v50:IsA("TextLabel") then
					local v56 = v_u_8
					if v56 then
						v56 = v_u_8:GetAttribute("InCombat") == true
					end
					if v47.SkillName and (v_u_13[v51] and os.clock() < v_u_13[v51]) then
						local v57 = v_u_13[v51] - os.clock()
						local v58 = math.ceil(v57)
						v50.Text = v58 > 0 and v58 .. "s" or ""
						v46.Lock.Visible = v56
						if v49 and v46:FindFirstChild("Lock2") then
							v46.Lock2.Visible = false
							if v46.Lock2:FindFirstChild("ImageLabel") then
								v46.Lock2.ImageLabel.Visible = false
							end
						end
					else
						if v_u_13[v51] and os.clock() >= v_u_13[v51] then
							v_u_13[v51] = nil
						end
						if v49 then
							if v47.SkillName then
								v46.Lock.Visible = false
								if v46:FindFirstChild("Lock2") then
									v46.Lock2.Visible = false
									if v46.Lock2:FindFirstChild("ImageLabel") then
										v46.Lock2.ImageLabel.Visible = false
									end
								end
								v46.Interactable = true
								v50.Text = v44 and "Touch" or (v_u_14[v45] or "")
							else
								v50.Text = "+"
								v46.Lock.Visible = false
								v46.BackgroundColor3 = Color3.fromRGB(118, 118, 118)
								v46.UIStroke.Color = Color3.fromRGB(104, 104, 104)
								v46.Lock2.Visible = false
								v46.Lock2.ImageLabel.Visible = false
								v46.Interactable = false
							end
						else
							v50.Text = "Unlock at level " .. v48
							v46.Lock.Visible = v56
							v46.BackgroundColor3 = Color3.fromRGB(52, 52, 52)
							v46.UIStroke.Color = Color3.fromRGB(40, 40, 40)
							v46.Lock2.Visible = true
							v46.Lock2.ImageLabel.Visible = true
							v46.Interactable = false
						end
					end
				end
			end
		end
		p20:SetupSkillInputs()
		task.wait(0.1)
		p20:UpdateCooldownUI()
	else
		local v59 = v_u_9:FindFirstChild("Skill" .. 1)
		if v59 then
			v59.Visible = false
		end
		local v60 = v_u_9:FindFirstChild("Skill" .. 2)
		if v60 then
			v60.Visible = false
		end
		local v61 = v_u_9:FindFirstChild("Skill" .. 3)
		if v61 then
			v61.Visible = false
		end
		local v62 = v_u_9:FindFirstChild("Skill" .. 4)
		if v62 then
			v62.Visible = false
		end
		p20:SetupSkillInputs()
	end
end
local v_u_63 = 0
function v1.CastSkill(_, p64)
	-- upvalues: (ref) v_u_8, (ref) v_u_63, (ref) v_u_16, (ref) v_u_15, (ref) v_u_4, (ref) v_u_17, (copy) v_u_13, (ref) v_u_12, (copy) v_u_9
	v_u_8 = game.Players.LocalPlayer.Character
	if v_u_8 and v_u_8.Parent then
		local v65 = os.clock()
		if v65 - v_u_63 < 0.15 then
			return
		else
			v_u_63 = v65
			if v_u_8:GetAttribute("InCombat") then
				if v_u_8:GetAttribute("CastingSkill") then
					return
				elseif v_u_16 then
					if p64 < 1 or p64 > 4 then
						return
					else
						local v66 = v_u_15[p64]
						if v66 and v66.SkillName then
							if v_u_17 and v_u_17 < (v66.UnlockLevel or 999) then
								return
							else
								local v67 = v_u_16 .. "_" .. p64
								if not v_u_13[v67] or os.clock() >= v_u_13[v67] then
									v_u_12 = true
									local v68 = v_u_9:FindFirstChild("Skill" .. p64)
									if v68 and v68:FindFirstChild("Lock") then
										v68.Lock.Visible = true
									end
									v_u_4:FireServer("CastSkill", v_u_16, p64)
								end
							end
						else
							if v_u_4 then
								pcall(function()
									-- upvalues: (ref) v_u_4
									v_u_4:FireServer("RequestSendNotification", {
										["Text"] = "Go to Inventory to equip a skill",
										["Type"] = "Error"
									})
								end)
							end
							return
						end
					end
				else
					return
				end
			else
				return
			end
		end
	else
		return
	end
end
function v1.UpdateCooldownUI(_)
	-- upvalues: (ref) v_u_16, (ref) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_9, (ref) v_u_15, (ref) v_u_17, (copy) v_u_13, (copy) v_u_14
	if v_u_16 then
		v_u_8 = v_u_7.Character
		local v69 = v_u_8
		if v69 then
			v69 = v_u_8:GetAttribute("InCombat") == true
		end
		local v70 = v_u_3.TouchEnabled
		if v70 then
			v70 = not v_u_3.KeyboardEnabled
		end
		for v71 = 1, 4 do
			local v72 = v_u_9:FindFirstChild("Skill" .. v71)
			if v72 and v72.Visible then
				local v73 = v_u_15[v71]
				if v73 then
					local v74 = v_u_17 >= (v73.UnlockLevel or 999)
					if v74 and v72:FindFirstChild("Lock2") then
						v72.Lock2.Visible = false
						if v72.Lock2:FindFirstChild("ImageLabel") then
							v72.Lock2.ImageLabel.Visible = false
						end
					end
					local v75 = v_u_16 .. "_" .. v71
					local v76 = v72:FindFirstChild("Inside")
					if v76 and v76:IsA("TextLabel") then
						if v73.SkillName and (v_u_13[v75] and os.clock() < v_u_13[v75]) then
							local v77 = v_u_13[v75] - os.clock()
							local v78 = math.ceil(v77)
							v76.Text = v78 > 0 and v78 .. "s" or ""
							if v72:FindFirstChild("Lock") then
								v72.Lock.Visible = v69
							end
							if v74 and v72:FindFirstChild("Lock2") then
								v72.Lock2.Visible = false
								if v72.Lock2:FindFirstChild("ImageLabel") then
									v72.Lock2.ImageLabel.Visible = false
								end
							end
						else
							if v_u_13[v75] and os.clock() >= v_u_13[v75] then
								v_u_13[v75] = nil
							end
							if v74 then
								if v73.SkillName then
									if v72:FindFirstChild("Lock") then
										v72.Lock.Visible = false
									end
									if v72:FindFirstChild("Lock2") then
										v72.Lock2.Visible = false
										if v72.Lock2:FindFirstChild("ImageLabel") then
											v72.Lock2.ImageLabel.Visible = false
										end
									end
									v76.Text = v70 and "Touch" or (v_u_14[v71] or "")
								else
									v76.Text = "+"
									if v72:FindFirstChild("Lock") then
										v72.Lock.Visible = false
									end
								end
							else
								v76.Text = "Unlock at level " .. v73.UnlockLevel
								if v72:FindFirstChild("Lock") then
									v72.Lock.Visible = v69
								end
							end
						end
					end
				end
			end
		end
	end
end
function v1.SetupSkillInputs(p_u_79)
	-- upvalues: (copy) v_u_18, (copy) v_u_19, (ref) v_u_16, (copy) v_u_9, (ref) v_u_15, (ref) v_u_17, (copy) v_u_3, (copy) v_u_14, (ref) v_u_8, (copy) v_u_7
	for v80 = 1, 4 do
		if v_u_18[v80] then
			v_u_18[v80]:Disconnect()
			v_u_18[v80] = nil
		end
		if v_u_19[v80] then
			v_u_19[v80]:Disconnect()
			v_u_19[v80] = nil
		end
	end
	if v_u_16 then
		for v_u_81 = 1, 4 do
			local v82 = v_u_9:FindFirstChild("Skill" .. v_u_81)
			if v82 then
				local v83 = v_u_15[v_u_81]
				if v83 then
					local _ = v_u_17 >= (v83.UnlockLevel or 999)
					local v_u_84 = v83.SkillName and true or false
					v_u_19[v_u_81] = v82.Activated:Connect(function()
						-- upvalues: (copy) p_u_79, (copy) v_u_81
						p_u_79:CastSkill(v_u_81)
					end)
					if v_u_3.KeyboardEnabled then
						local v_u_85 = Enum.KeyCode[v_u_14[v_u_81]]
						if v_u_85 then
							v_u_18[v_u_81] = v_u_3.InputBegan:Connect(function(p86, p87)
								-- upvalues: (copy) v_u_85, (ref) v_u_8, (ref) v_u_7, (copy) v_u_84, (copy) p_u_79, (copy) v_u_81
								if p87 then
									return
								elseif p86.KeyCode == v_u_85 then
									v_u_8 = v_u_7.Character
									if v_u_8 and v_u_8.Parent then
										if v_u_8:GetAttribute("InCombat") then
											if v_u_84 then
												p_u_79:CastSkill(v_u_81)
											end
										end
									else
										return
									end
								else
									return
								end
							end)
						end
					end
				end
			end
		end
	end
end
function v1.ResetSkills(_)
	-- upvalues: (ref) v_u_12, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (copy) v_u_9, (copy) v_u_18, (copy) v_u_19
	v_u_12 = false
	v_u_15 = {}
	v_u_16 = nil
	v_u_17 = 1
	for v88 = 1, 4 do
		local v89 = v_u_9:FindFirstChild("Skill" .. v88)
		if v89 then
			local v90 = v89:FindFirstChild("Inside")
			if v90 and v90:IsA("TextLabel") then
				v90.Text = ""
			end
			v89.Visible = false
			local v91 = v89:FindFirstChild("Lock")
			if v91 then
				v91.Visible = false
			end
			local v92 = v89:FindFirstChild("Lock2")
			if v92 then
				v92.Visible = false
			end
		end
		if v_u_18[v88] then
			v_u_18[v88]:Disconnect()
			v_u_18[v88] = nil
		end
		if v_u_19[v88] then
			v_u_19[v88]:Disconnect()
			v_u_19[v88] = nil
		end
	end
end
function v1.OnCombatEnd(_)
	-- upvalues: (ref) v_u_12, (ref) v_u_63, (copy) v_u_9
	v_u_12 = false
	v_u_63 = 0
	_G.Holding = false
	local v93 = v_u_9:FindFirstChild("Skill" .. 1)
	if v93 then
		v93.Lock.Visible = false
	end
	local v94 = v_u_9:FindFirstChild("Skill" .. 2)
	if v94 then
		v94.Lock.Visible = false
	end
	local v95 = v_u_9:FindFirstChild("Skill" .. 3)
	if v95 then
		v95.Lock.Visible = false
	end
	local v96 = v_u_9:FindFirstChild("Skill" .. 4)
	if v96 then
		v96.Lock.Visible = false
	end
end
function v1.Start(p_u_97)
	-- upvalues: (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_17, (ref) v_u_16, (ref) v_u_12, (ref) v_u_8, (copy) v_u_7, (copy) v_u_9, (copy) v_u_13, (ref) v_u_15, (copy) v_u_3, (copy) v_u_14
	v_u_4 = p_u_97.Shared.Network
	v_u_5 = p_u_97.Data.RodConfig
	v_u_6 = p_u_97.Data.SkillConfig
	v_u_4:BindEvents({
		["SkillLearned"] = function(p98, _, _)
			-- upvalues: (copy) p_u_97, (ref) v_u_17
			local v99 = p_u_97.Controllers
			if v99 then
				v99 = p_u_97.Controllers.RodController
			end
			local v100
			if v99 then
				v100 = v99:GetCurrentRodName()
			else
				v100 = v99
			end
			local v101 = v99 and v99:GetCurrentRodLevel() or (v_u_17 or 1)
			if not v100 or v100 == p98 then
				p_u_97:UpdateSkillsUI(p98, v101)
			end
		end,
		["UpdateSkill"] = function(p102)
			-- upvalues: (copy) p_u_97, (ref) v_u_17
			local v103 = p_u_97.Controllers
			if v103 then
				v103 = p_u_97.Controllers.RodController
			end
			local v104
			if v103 then
				v104 = v103:GetCurrentRodName()
			else
				v104 = v103
			end
			local v105 = v103 and v103:GetCurrentRodLevel() or (v_u_17 or 1)
			if not v104 or v104 == p102 then
				p_u_97:UpdateSkillsUI(p102, v105)
			end
		end,
		["SkillUnlearned"] = function(p106, _)
			-- upvalues: (copy) p_u_97, (ref) v_u_17
			local v107 = p_u_97.Controllers
			if v107 then
				v107 = p_u_97.Controllers.RodController
			end
			local v108
			if v107 then
				v108 = v107:GetCurrentRodName()
			else
				v108 = v107
			end
			local v109 = v107 and v107:GetCurrentRodLevel() or (v_u_17 or 1)
			if not v108 or v108 == p106 then
				p_u_97:UpdateSkillsUI(p106, v109)
			end
		end,
		["SkillCasting"] = function(p110, p111, p112)
			-- upvalues: (ref) v_u_16, (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (ref) v_u_13, (ref) v_u_15, (ref) v_u_17, (ref) v_u_3, (ref) v_u_14
			if p110 == v_u_16 then
				v_u_12 = p112
				v_u_8 = v_u_7.Character
				local v113 = v_u_8
				if v113 then
					v113 = v_u_8:GetAttribute("InCombat") == true
				end
				local v114 = v_u_9:FindFirstChild("Skill" .. p111)
				if v114 then
					if p112 then
						v114.Lock.Visible = true
					else
						local v115 = p110 .. "_" .. p111
						local v116 = v_u_13[v115]
						if v116 then
							v116 = os.clock() < v_u_13[v115]
						end
						local v117 = v_u_15[p111]
						if v117 then
							v117 = (v_u_17 or 1) >= (v117.UnlockLevel or 999)
						end
						if v114:FindFirstChild("Lock") then
							local v118 = v114.Lock
							if not v116 then
								local v119 = not v117
								if not v119 then
									v113 = v119
								end
							end
							v118.Visible = v113
						end
						if v117 and v114:FindFirstChild("Lock2") then
							v114.Lock2.Visible = false
							if v114.Lock2:FindFirstChild("ImageLabel") then
								v114.Lock2.ImageLabel.Visible = false
							end
						end
					end
					if not p112 then
						task.wait(0.15)
						local v120 = p110 .. "_" .. p111
						if not v_u_13[v120] or os.clock() >= v_u_13[v120] then
							local v121 = v114:FindFirstChild("Inside")
							local v122 = v_u_15[p111]
							if v121 and (v121:IsA("TextLabel") and v122) then
								if v122.SkillName then
									v121.Text = v_u_3.TouchEnabled and not v_u_3.KeyboardEnabled and "Touch" or (v_u_14[p111] or "")
									return
								end
								v121.Text = v_u_17 >= (v122.UnlockLevel or 999) and "+" or "Lv." .. (v122.UnlockLevel or 999)
							end
						end
					end
				end
			end
		end,
		["SkillCooldown"] = function(p123, p124, p125)
			-- upvalues: (ref) v_u_16, (ref) v_u_13, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9
			if p123 == v_u_16 then
				v_u_13[p123 .. "_" .. p124] = os.clock() + p125
				v_u_8 = v_u_7.Character
				local v126 = v_u_8
				if v126 then
					v126 = v_u_8:GetAttribute("InCombat") == true
				end
				local v127 = v_u_9:FindFirstChild("Skill" .. p124)
				if v127 then
					v127.Lock.Visible = v126
					local v128 = v127:FindFirstChild("Inside")
					if v128 and v128:IsA("TextLabel") then
						v128.Text = math.ceil(p125) .. "s"
					end
				end
			end
		end,
		["EndSkillEffect"] = function()
			-- upvalues: (ref) v_u_12
			v_u_12 = false
		end,
		["SkillCastFailed"] = function(p129, p130, _)
			-- upvalues: (ref) v_u_12, (ref) v_u_16, (ref) v_u_9
			v_u_12 = false
			if p129 == v_u_16 then
				local v131 = v_u_9:FindFirstChild("Skill" .. p130)
				if v131 then
					v131.Lock.Visible = false
				end
			end
		end
	})
	task.spawn(function()
		-- upvalues: (copy) p_u_97
		while true do
			task.wait(0.1)
			local v132 = p_u_97.Controllers
			if v132 then
				v132 = p_u_97.Controllers.RodController
			end
			if v132 and v132:GetCurrentRodName() then
				p_u_97:UpdateCooldownUI()
			end
		end
	end)
end
return v1