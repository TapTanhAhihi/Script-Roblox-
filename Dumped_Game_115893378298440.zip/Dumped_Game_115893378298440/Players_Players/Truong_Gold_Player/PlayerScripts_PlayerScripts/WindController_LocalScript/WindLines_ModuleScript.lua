-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = game:GetService("RunService")
local v_u_2 = workspace:FindFirstChildOfClass("Terrain")
local v_u_3 = {}
local v_u_35 = {
	["UpdateConnection"] = nil,
	["UpdateQueue"] = table.create(10),
	["Init"] = function(_, p4)
		-- upvalues: (copy) v_u_35, (copy) v_u_1
		v_u_35.Lifetime = p4.Lifetime or 3
		v_u_35.Direction = p4.Direction or Vector3.new(1, 0, 0)
		v_u_35.Speed = p4.Speed or 6
		if v_u_35.UpdateConnection then
			v_u_35.UpdateConnection:Disconnect()
			v_u_35.UpdateConnection = nil
		end
		for _, v5 in v_u_35.UpdateQueue do
			v5.Attachment0:Destroy()
			v5.Attachment1:Destroy()
			v5.Trail:Destroy()
		end
		table.clear(v_u_35.UpdateQueue)
		v_u_35.LastSpawned = os.clock()
		local v_u_6 = 1 / (p4.SpawnRate or 25)
		v_u_35.UpdateConnection = v_u_1.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_35, (copy) v_u_6
			local v7 = os.clock()
			if v_u_6 < v7 - v_u_35.LastSpawned then
				v_u_35:Create()
				v_u_35.LastSpawned = v7
			end
			debug.profilebegin("Wind Lines")
			for v8, v9 in v_u_35.UpdateQueue do
				local v10 = v7 - v9.StartClock
				if v9.Lifetime <= v10 then
					v9.Attachment0:Destroy()
					v9.Attachment1:Destroy()
					v9.Trail:Destroy()
					local v11 = #v_u_35.UpdateQueue
					v_u_35.UpdateQueue[v8] = v_u_35.UpdateQueue[v11]
					v_u_35.UpdateQueue[v11] = nil
				else
					v9.Trail.MaxLength = 20 - 20 * (v10 / v9.Lifetime)
					local v12 = (v7 + v9.Seed) * (v9.Speed * 0.2)
					local v13 = v9.Position
					local v14 = v9.Attachment0
					local v15 = (CFrame.new(v13, v13 + v9.Direction) * CFrame.new(0, 0, v9.Speed * -v10)).Position
					local v16 = math.sin(v12) * 0.5
					local v17 = math.sin(v12) * 0.8
					local v18 = math.sin(v12) * 0.5
					v14.WorldPosition = v15 + Vector3.new(v16, v17, v18)
					v9.Attachment1.WorldPosition = v9.Attachment0.WorldPosition + Vector3.new(0, 0.1, 0)
				end
			end
			debug.profileend()
		end)
	end,
	["Cleanup"] = function(_)
		-- upvalues: (copy) v_u_35
		if v_u_35.UpdateConnection then
			v_u_35.UpdateConnection:Disconnect()
			v_u_35.UpdateConnection = nil
		end
		for _, v19 in v_u_35.UpdateQueue do
			v19.Attachment0:Destroy()
			v19.Attachment1:Destroy()
			v19.Trail:Destroy()
		end
		table.clear(v_u_35.UpdateQueue)
	end,
	["Create"] = function(_, p20)
		-- upvalues: (copy) v_u_3, (copy) v_u_35, (copy) v_u_2
		debug.profilebegin("Add Wind Line")
		local v21 = p20 or v_u_3
		local v22 = v21.Lifetime or v_u_35.Lifetime
		local v23 = v21.Position
		if not v23 then
			local v24 = workspace.CurrentCamera.CFrame
			local v25 = CFrame.Angles
			local v26 = math.random(-30, 70)
			local v27 = math.rad(v26)
			local v28 = math.random(-80, 80)
			v23 = v24 * v25(v27, math.rad(v28), 0) * CFrame.new(0, 0, math.random(200, 600) * -0.1).Position
		end
		local v29 = v21.Direction or v_u_35.Direction
		local v30 = v21.Speed or v_u_35.Speed
		if v30 > 0 then
			local v31 = Instance.new("Attachment")
			local v32 = Instance.new("Attachment")
			local v33 = Instance.new("Trail")
			v33.Attachment0 = v31
			v33.Attachment1 = v32
			v33.WidthScale = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 0.3),
				NumberSequenceKeypoint.new(0.2, 1),
				NumberSequenceKeypoint.new(0.8, 1),
				NumberSequenceKeypoint.new(1, 0.3)
			})
			v33.Transparency = NumberSequence.new(0.7)
			v33.FaceCamera = true
			v33.Parent = v31
			v31.WorldPosition = v23
			v32.WorldPosition = v23 + Vector3.new(0, 0.1, 0)
			local v34 = {
				["Attachment0"] = v31,
				["Attachment1"] = v32,
				["Trail"] = v33,
				["Lifetime"] = v22 + math.random(-10, 10) * 0.1,
				["Position"] = v23,
				["Direction"] = v29,
				["Speed"] = v30 + math.random(-10, 10) * 0.1,
				["StartClock"] = os.clock(),
				["Seed"] = math.random(1, 1000) * 0.1
			}
			v_u_35.UpdateQueue[#v_u_35.UpdateQueue + 1] = v34
			v31.Parent = v_u_2
			v32.Parent = v_u_2
			debug.profileend()
		end
	end
}
return v_u_35