-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = script.Parent:WaitForChild("TextLabel")
game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("ServerTimer").OnClientEvent:Connect(function(p2)
	-- upvalues: (copy) v_u_1
	local v3 = p2 / 3600
	local v4 = math.floor(v3)
	local v5 = p2 % 3600 / 60
	local v6 = math.floor(v5)
	local v7 = p2 % 60
	v_u_1.Text = string.format("Server Time: %02d:%02d:%02d", v4, v6, v7)
end)