-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return function(p1, p2, p3)
	debug.profilebegin("Rotation Constraint")
	local v4 = p1.ParentIndex
	local v5 = p3.Bones[v4]
	if not v5 then
		debug.profileend()
		return p2
	end
	local v6 = p3.Bones[v5.ParentIndex]
	if not v6 then
		debug.profileend()
		return p2
	end
	local v7 = v5.RotationLimit
	local v8 = v5.Position
	local v9 = v5.Position - v6.Position
	local v10 = v9.Magnitude == 0 and Vector3.new(0, 0, 0) or v9.Unit
	local v11 = (p2 - v8).Magnitude
	local v12 = p2 - v8
	local v13 = v12.Magnitude == 0 and Vector3.new(0, 0, 0) or v12.Unit
	if v7 >= 180 then
		debug.profileend()
		return p2
	end
	if v7 <= 0 then
		debug.profileend()
		return v8 + v10 * v11
	end
	local v14 = p1.RotationLimit
	local v15 = math.rad(v14)
	local v16 = v10:Dot(v13)
	if v15 <= math.acos(v16) then
		local v17 = v10:Cross(v13)
		local v18 = v17.Magnitude == 0 and Vector3.new(0, 0, 0) or v17.Unit
		v13 = CFrame.fromAxisAngle(v18, v15) * v10
	end
	local v19 = v8 + v13 * v11
	debug.profileend()
	return v19
end