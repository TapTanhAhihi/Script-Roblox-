-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
require(game.ReplicatedStorage.SmartBone).Start()