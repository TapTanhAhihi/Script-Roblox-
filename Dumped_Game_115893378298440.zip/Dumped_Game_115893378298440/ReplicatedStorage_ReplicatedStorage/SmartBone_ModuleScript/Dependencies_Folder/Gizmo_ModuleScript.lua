-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("TweenService")
local v3 = workspace:WaitForChild("Terrain")
assert(v3, "No terrain object found under workspace...")
local v_u_4 = v3:FindFirstChild("AOTGizmoAdornment")
local v_u_5 = v3:FindFirstChild("GizmoAdornment")
if not v_u_4 then
	v_u_4 = Instance.new("WireframeHandleAdornment")
	v_u_4.Adornee = v3
	v_u_4.ZIndex = 1
	v_u_4.AlwaysOnTop = true
	v_u_4.Name = "AOTGizmoAdornment"
	v_u_4.Parent = v3
end
if not v_u_5 then
	v_u_5 = Instance.new("WireframeHandleAdornment")
	v_u_5.Adornee = v3
	v_u_5.ZIndex = 1
	v_u_5.AlwaysOnTop = false
	v_u_5.Name = "GizmoAdornment"
	v_u_5.Parent = v3
end
local v6 = script:WaitForChild("Gizmos")
local v_u_7 = {}
local v_u_8 = {}
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = {
	["AlwaysOnTop"] = true
}
local v_u_12 = {}
local v_u_13 = false
local function v16(p14)
	-- upvalues: (ref) v_u_7
	local v15 = v_u_7
	table.insert(v15, p14)
end
local function v_u_22(p17)
	-- upvalues: (copy) v_u_22
	local v18 = {}
	for v19, v21 in pairs(p17) do
		if type(v21) == "table" then
			local v21 = v_u_22(v21)
		end
		v18[v19] = v21
	end
	return v18
end
local v_u_67 = {
	["Enabled"] = true,
	["ActiveRays"] = 0,
	["ActiveInstances"] = 0,
	["Styles"] = {
		["Color"] = "Color3",
		["Transparency"] = "Transparency",
		["AlwaysOnTop"] = "AlwaysOnTop"
	},
	["AOTWireframeHandle"] = v_u_4,
	["WireframeHandle"] = v_u_5,
	["GetPoolSize"] = function()
		-- upvalues: (copy) v_u_12
		local v23 = 0
		for _, v24 in v_u_12 do
			v23 = v23 + #v24
		end
		return v23
	end,
	["PushProperty"] = function(p_u_25, p_u_26)
		-- upvalues: (copy) v_u_11, (ref) v_u_4, (ref) v_u_5
		v_u_11[p_u_25] = p_u_26
		if p_u_25 ~= "AlwaysOnTop" then
			pcall(function()
				-- upvalues: (ref) v_u_4, (copy) p_u_25, (copy) p_u_26, (ref) v_u_5
				v_u_4[p_u_25] = p_u_26
				v_u_5[p_u_25] = p_u_26
			end)
		end
	end,
	["PopProperty"] = function(p27)
		-- upvalues: (copy) v_u_11, (ref) v_u_4
		if v_u_11[p27] then
			return v_u_11[p27]
		else
			return v_u_4[p27]
		end
	end,
	["SetStyle"] = function(p28, p29, p30)
		-- upvalues: (copy) v_u_67
		if p28 and typeof(p28) == "Color3" then
			v_u_67.PushProperty("Color3", p28)
		end
		if p29 and typeof(p29) == "number" then
			v_u_67.PushProperty("Transparency", p29)
		end
		if p30 and typeof(p30) == "boolean" then
			v_u_67.PushProperty("AlwaysOnTop", p30)
		end
	end,
	["DoCleaning"] = function()
		-- upvalues: (ref) v_u_4, (ref) v_u_5, (ref) v_u_7, (copy) v_u_12, (copy) v_u_67
		v_u_4:Clear()
		v_u_5:Clear()
		for _, v31 in v_u_7 do
			local v32 = v31.ClassName
			if not v_u_12[v32] then
				v_u_12[v32] = {}
			end
			v31:Remove()
			local v33 = v_u_12[v32]
			table.insert(v33, v31)
		end
		v_u_7 = {}
		v_u_67.ActiveRays = 0
		v_u_67.ActiveInstances = 0
	end,
	["ScheduleCleaning"] = function()
		-- upvalues: (ref) v_u_13, (copy) v_u_67
		if not v_u_13 then
			v_u_13 = true
			task.delay(0, function()
				-- upvalues: (ref) v_u_67, (ref) v_u_13
				v_u_67.DoCleaning()
				v_u_13 = false
			end)
		end
	end,
	["AddDebrisInSeconds"] = function(p34, p35)
		-- upvalues: (copy) v_u_9
		local v36 = v_u_9
		local v37 = {
			"Seconds",
			p34,
			os.clock(),
			p35
		}
		table.insert(v36, v37)
	end,
	["AddDebrisInFrames"] = function(p38, p39)
		-- upvalues: (copy) v_u_9
		local v40 = v_u_9
		table.insert(v40, {
			"Frames",
			p38,
			0,
			p39
		})
	end,
	["TweenProperties"] = function(p41, p42, p43)
		-- upvalues: (copy) v_u_22, (copy) v_u_10
		local v44 = v_u_10
		local v45 = {
			["p_Properties"] = p41,
			["Properties"] = v_u_22(p41),
			["Goal"] = p42,
			["TweenInfo"] = p43,
			["Time"] = 0
		}
		table.insert(v44, v45)
		local v_u_46 = #v_u_10
		return function()
			-- upvalues: (ref) v_u_10, (copy) v_u_46
			table.remove(v_u_10, v_u_46)
		end
	end,
	["Init"] = function()
		-- upvalues: (copy) v_u_1, (copy) v_u_10, (copy) v_u_2, (copy) v_u_9, (copy) v_u_8
		v_u_1.RenderStepped:Connect(function(p47)
			-- upvalues: (ref) v_u_10, (ref) v_u_2, (ref) v_u_9, (ref) v_u_8
			for v48, v49 in v_u_10 do
				v49.Time = v49.Time + p47
				local v50 = v49.Time / v49.TweenInfo.Time
				local v51 = v50 > 1 and 1 or v50
				for v52, v53 in v49.Properties do
					if v49.Goal[v52] then
						local v54 = v_u_2:GetValue(v51, v49.TweenInfo.EasingStyle, v49.TweenInfo.EasingDirection)
						local v55 = v49.Goal[v52]
						local v56
						if type(v53) == "number" then
							v56 = v53 + (v55 - v53) * v54
						else
							v56 = v53:Lerp(v55, v54)
						end
						v49.p_Properties[v52] = v56
					end
				end
				if v51 == 1 then
					table.remove(v_u_10, v48)
				end
			end
			for v57, v58 in v_u_9 do
				local v59 = v58[1]
				local v60 = v58[2]
				local v61 = v58[3]
				local v62 = v58[4]
				if v59 == "Seconds" then
					if v60 < os.clock() - v61 then
						table.remove(v_u_9, v57)
					else
						v62()
					end
				elseif v60 < v61 then
					table.remove(v_u_9, v57)
				else
					v58[2] = v58[2] + 1
					v62()
				end
			end
			for v63, v64 in v_u_8 do
				local v65 = v64[2]
				if v65.Enabled then
					if v65.Destroy then
						table.remove(v_u_8, v63)
					end
					v64[1]:Update(v65)
				end
			end
		end)
	end,
	["SetEnabled"] = function(p66)
		-- upvalues: (copy) v_u_67
		v_u_67.Enabled = p66
		if p66 == false then
			v_u_67.DoCleaning()
		end
	end
}
local function v70(p68)
	-- upvalues: (copy) v_u_12
	if not v_u_12[p68] then
		return Instance.new(p68)
	end
	if not v_u_12[p68][1] then
		return Instance.new(p68)
	end
	local v69 = v_u_12[p68][1]
	table.remove(v_u_12[p68], 1)
	return v69
end
local function v74(p71)
	-- upvalues: (copy) v_u_12
	local v72 = p71.ClassName
	if not v_u_12[v72] then
		v_u_12[v72] = {}
	end
	p71:Remove()
	local v73 = v_u_12[v72]
	table.insert(v73, p71)
end
local function v78(p75, p76)
	-- upvalues: (copy) v_u_8
	local v77 = v_u_8
	table.insert(v77, { p75, p76 })
end
for _, v79 in v6:GetChildren() do
	v_u_67[v79.Name] = require(v79).Init(v_u_67, v_u_11, v70, v74, v78, v16)
end
return v_u_67