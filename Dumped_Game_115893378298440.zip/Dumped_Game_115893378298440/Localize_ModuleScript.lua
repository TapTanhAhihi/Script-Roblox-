-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = {}
local v_u_2 = "en"
local v_u_3 = {
	["en"] = {
		["UnlearnConfirmTitle"] = "Unlearn this skill?",
		["UnlearnConfirmKeepLeft"] = "You have %d keep chance(s) left (book will be returned).",
		["UnlearnConfirmNoKeep"] = "No keep chances left - book will be lost.",
		["UnlearnNotifyBookReturned"] = "Skill unlearned. Book returned. Keep chances left: %d",
		["UnlearnNotifyNoKeep"] = "Skill unlearned. (No keep chances left - book lost)",
		["Noti_GenericError"] = "Something went wrong.",
		["Noti_NoProfile"] = "Profile not found.",
		["Noti_NotEnoughMoney"] = "Not enough money.",
		["Noti_InventoryFull"] = "Inventory is full!",
		["Noti_MaxFishBodies"] = "Maximum 4 fish can be equipped at once!",
		["Noti_FishLocked"] = "Fish is locked. Unlock to sell.",
		["Noti_NeedLevelIsland"] = "You need Level %d to fish at %s!",
		["Noti_NeedTicketIsland"] = "You need a ticket to fish at %s!",
		["Noti_TicketPurchased"] = "Ticket purchased for %s!",
		["Noti_MasteryBoostActivated"] = "Activated x2 Mastery",
		["UI_Mastery_Format"] = "Mastery: %d/%d",
		["UI_Mastery_Empty"] = "Mastery: 0/0",
		["UI_Rod_NameWithLevel"] = "%s (Lvl. %d)",
		["Rod_Wooden_Rod"] = "Wooden Rod",
		["Rod_Upgraded_Wooden_Rod"] = "Upgraded Wooden Rod",
		["Rod_Rusty_Iron_Rod"] = "Rusty Iron Rod",
		["Rod_Gold_Plated_Rod"] = "Gold Plated Rod",
		["Rod_Stone_Rod"] = "Stone Rod",
		["Rod_Golden_Rod"] = "Golden Rod",
		["Rod_Bamboo_Rod"] = "Bamboo Rod",
		["Rod_Steel_Rod"] = "Steel Rod",
		["Rod_Titanium_Steel_Rod"] = "Titanium Steel Rod",
		["Noti_Skill_InvalidSlot"] = "Invalid slot.",
		["Noti_Skill_InvalidForSlot"] = "Skill cannot go in this slot.",
		["Noti_Skill_RodLevelTooLow"] = "Rod level too low for this slot.",
		["Noti_Skill_NoBook"] = "No skill book.",
		["Noti_Skill_AlreadyInSlot"] = "Slot already has skill.",
		["Noti_Skill_AlreadyEquipped"] = "Already equipped on another slot.",
		["Noti_Skill_NoBookFromSource"] = "No skill book from selected source.",
		["Noti_SkillEquipped"] = "Skill equipped!",
		["Noti_SkillStunned"] = "Stunned!",
		["Noti_NoSkillsOwned"] = "You don\'t have any skill.",
		["Noti_CannotChangeSkillsInCombat"] = "Cannot change skills in combat.",
		["Noti_Gacha_NotEnoughMoney"] = "Not enough money to spin.",
		["Noti_Gacha_UINotFound"] = "Gacha UI not found.",
		["Noti_Gacha_DisplayItemNotFound"] = "DisplayItem not found in Gacha UI.",
		["UI_Stat_Luck"] = "Luck",
		["UI_Stat_Damage"] = "Damage",
		["UI_Stat_Money"] = "Money",
		["UI_Stat_FishHP"] = "Fish HP",
		["UI_Stat_PullForce"] = "Pull Force",
		["UI_Bait_Amount"] = "Amount"
	}
}
function v_u_1.SetLocale(p4)
	-- upvalues: (copy) v_u_3, (ref) v_u_2
	if v_u_3[p4] then
		v_u_2 = p4
	end
end
function v_u_1.GetLocale()
	-- upvalues: (ref) v_u_2
	return v_u_2
end
function v_u_1.Localize(p5, ...)
	-- upvalues: (copy) v_u_3, (ref) v_u_2
	local v6 = v_u_3[v_u_2] or v_u_3.en
	if v6 then
		p5 = v6[p5] or p5
	end
	if select("#", ...) > 0 then
		return string.format(p5, ...)
	else
		return p5
	end
end
function v_u_1.t(p7, ...)
	-- upvalues: (copy) v_u_1
	return v_u_1.Localize(p7, ...)
end
function v_u_1.RodName(p8)
	-- upvalues: (copy) v_u_3, (ref) v_u_2
	if not p8 or p8 == "" then
		return p8
	end
	local v9 = "Rod_" .. p8:gsub(" ", "_")
	local v10 = v_u_3[v_u_2] or v_u_3.en
	if v10 then
		p8 = v10[v9] or p8
	end
	return p8
end
return v_u_1