-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {
	["Common"] = 1,
	["Uncommon"] = 2,
	["Rare"] = 3,
	["Epic"] = 4,
	["Legendary"] = 5
}
local function v3(p2)
	return 100 * p2 ^ 1.5
end
local v4 = {
	["Wooden Rod"] = {
		["Rarity"] = "Common",
		["RarityOrder"] = v1.Common,
		["Display"] = "rbxassetid://78040092050509",
		["Damage"] = 999,
		["Price"] = 0,
		["Luck"] = 1,
		["WeightRange"] = { 1, 100 },
		["PullBackAmount"] = 3,
		["EnergyCostMultiplier"] = 1,
		["MaxLevel"] = 100,
		["GetMasteryRequirement"] = v3
	},
	["Upgraded Wooden Rod"] = {
		["Rarity"] = "Uncommon",
		["RarityOrder"] = v1.Uncommon,
		["Display"] = "rbxassetid://126046344796124",
		["Damage"] = 2000,
		["Price"] = 40000,
		["Luck"] = 5,
		["WeightRange"] = { 100, 200 },
		["PullBackAmount"] = 3,
		["EnergyCostMultiplier"] = 1,
		["MaxLevel"] = 100,
		["GetMasteryRequirement"] = v3
	},
	["Rusty Iron Rod"] = {
		["Rarity"] = "Rare",
		["RarityOrder"] = v1.Rare,
		["Display"] = "rbxassetid://130712680346006",
		["Damage"] = 5000,
		["Luck"] = 10,
		["Price"] = 100000,
		["WeightRange"] = { 200, 300 },
		["PullBackAmount"] = 3,
		["EnergyCostMultiplier"] = 1,
		["MaxLevel"] = 100,
		["GetMasteryRequirement"] = v3
	},
	["Gold Plated Rod"] = {
		["Rarity"] = "Epic",
		["RarityOrder"] = v1.Epic,
		["Display"] = "rbxassetid://123608831772874",
		["Damage"] = 12500,
		["Price"] = 200000,
		["Luck"] = 18,
		["WeightRange"] = { 300, 400 },
		["PullBackAmount"] = 3,
		["EnergyCostMultiplier"] = 1,
		["MaxLevel"] = 100,
		["GetMasteryRequirement"] = v3
	},
	["Stone Rod"] = {
		["Rarity"] = "Epic",
		["RarityOrder"] = v1.Epic + 1,
		["Display"] = "rbxassetid://82905196006381",
		["Damage"] = 16767,
		["Price"] = 300000,
		["Luck"] = 20,
		["WeightRange"] = { 440, 500 },
		["PullBackAmount"] = 3,
		["EnergyCostMultiplier"] = 1,
		["MaxLevel"] = 100,
		["GetMasteryRequirement"] = v3
	},
	["Golden Rod"] = {
		["Rarity"] = "Epic",
		["RarityOrder"] = v1.Epic + 2,
		["Display"] = "rbxassetid://80661675773780",
		["Damage"] = 22000,
		["Price"] = 2363636,
		["Luck"] = 22,
		["WeightRange"] = { 500, 600 },
		["PullBackAmount"] = 3,
		["EnergyCostMultiplier"] = 1,
		["MaxLevel"] = 100,
		["GetMasteryRequirement"] = v3
	},
	["Bamboo Rod"] = {
		["Rarity"] = "Legendary",
		["RarityOrder"] = v1.Legendary,
		["Display"] = "rbxassetid://98213213518209",
		["Damage"] = 18767,
		["Price"] = 0,
		["QuestOnly"] = true,
		["Luck"] = 20,
		["WeightRange"] = { 475, 500 },
		["PullBackAmount"] = 3,
		["EnergyCostMultiplier"] = 1,
		["MaxLevel"] = 100,
		["GetMasteryRequirement"] = v3
	},
	["Steel Rod"] = {
		["Rarity"] = "Legendary",
		["RarityOrder"] = 7,
		["Display"] = "rbxassetid://132145738812737",
		["Damage"] = 35375,
		["Price"] = 0,
		["QuestOnly"] = true,
		["Luck"] = 22,
		["WeightRange"] = { 570, 600 },
		["PullBackAmount"] = 3,
		["EnergyCostMultiplier"] = 1,
		["MaxLevel"] = 100,
		["GetMasteryRequirement"] = v3
	},
	["Titanium Steel Rod"] = {
		["Rarity"] = "Legendary",
		["RarityOrder"] = 7,
		["Display"] = "rbxassetid://121053417672418",
		["Damage"] = 58437,
		["Price"] = 0,
		["QuestOnly"] = true,
		["Luck"] = 22,
		["WeightRange"] = { 600, 700 },
		["PullBackAmount"] = 3,
		["EnergyCostMultiplier"] = 1,
		["MaxLevel"] = 100,
		["GetMasteryRequirement"] = v3
	}
}
return v4