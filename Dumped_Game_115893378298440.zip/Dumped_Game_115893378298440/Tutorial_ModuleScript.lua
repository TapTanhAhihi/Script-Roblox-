-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("Players")
local v_u_6 = false
local v_u_7 = false
local v_u_8 = false
local v_u_9 = false
local v_u_10 = false
local v_u_11 = false
local v_u_12 = false
local v_u_13 = false
local v_u_14 = false
local v_u_15 = false
local v_u_16 = false
function v1.Start(p17)
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_16, (ref) v_u_14, (ref) v_u_15, (copy) v_u_5, (copy) v_u_2, (ref) v_u_10, (copy) v_u_3, (copy) v_u_4, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13
	local v50 = {
		["BuyedSkillBook"] = function()
			-- upvalues: (ref) v_u_6, (ref) v_u_7
			if v_u_6 then
				v_u_7 = true
			end
		end,
		["FishCasted"] = function()
			-- upvalues: (ref) v_u_6, (ref) v_u_16
			if v_u_6 then
				v_u_16 = true
			end
		end,
		["TutorialFirstFishCaught"] = function()
			-- upvalues: (ref) v_u_6, (ref) v_u_14
			if v_u_6 then
				v_u_14 = true
			end
		end,
		["TutorialPlayerCasted"] = function()
			-- upvalues: (ref) v_u_6, (ref) v_u_15
			if v_u_6 then
				v_u_15 = true
			end
		end,
		["Tutorial"] = function()
			-- upvalues: (ref) v_u_6, (ref) v_u_5, (ref) v_u_2, (ref) v_u_10, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (ref) v_u_12, (ref) v_u_15, (ref) v_u_14, (ref) v_u_13
			repeat
				task.wait()
			until not _G.Loading
			v_u_6 = true
			local v18 = v_u_5.LocalPlayer
			local v_u_19 = v18.Character
			local v_u_20 = v_u_19:WaitForChild("Humanoid")
			local v_u_21 = game.ReplicatedStorage.Assets.Templates.Tutorial.Tutorial:Clone()
			v_u_21.Parent = v18.PlayerGui
			local v_u_22 = Instance.new("Attachment", v_u_19.PrimaryPart)
			local v_u_23 = nil
			for _, v24 in pairs(workspace.NPCs:GetChildren()) do
				if v24:IsA("Model") and v24:GetAttribute("OldMan") then
					v_u_23 = v24
				end
			end
			local v_u_25 = Instance.new("Attachment", v_u_23.PrimaryPart)
			local function v_u_30(p26, p27, p28)
				p26.Text = ""
				for v29 = 1, #p27 do
					p26.Text = p27:sub(1, v29)
					task.wait(p28)
				end
			end
			local v_u_31 = v_u_2.RenderStepped:Connect(function()
				-- upvalues: (ref) v_u_10, (copy) v_u_20
				if not v_u_10 then
					_G.Hold = true
					v_u_20.WalkSpeed = 0
					v_u_20.JumpPower = 0
				end
			end)
			workspace.Sounds.Notification:Play()
			v_u_30(v_u_21.TextLabel, "Welcome to Titan Fishing!", 0.05)
			task.delay(2, function()
				-- upvalues: (copy) v_u_30, (copy) v_u_21, (ref) v_u_23, (copy) v_u_22, (copy) v_u_25, (ref) v_u_10, (copy) v_u_20, (ref) v_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (ref) v_u_12, (copy) v_u_19, (ref) v_u_15, (ref) v_u_14, (ref) v_u_13, (ref) v_u_31
				workspace.Sounds.Notification:Play()
				v_u_30(v_u_21.TextLabel, "You have 20k Money go to spin now", 0.05)
				local v_u_32 = game.ReplicatedStorage.Assets.Templates.Tutorial.Beam:Clone()
				task.delay(1, function()
					-- upvalues: (copy) v_u_32, (ref) v_u_23, (ref) v_u_22, (ref) v_u_25
					v_u_32.Parent = v_u_23.PrimaryPart
					v_u_32.Attachment0 = v_u_22
					v_u_32.Attachment1 = v_u_25
				end)
				task.wait(2)
				v_u_10 = true
				v_u_20.WalkSpeed = 30
				v_u_20.JumpPower = 50
				repeat
					task.wait()
				until v_u_7
				v_u_32:Destroy()
				task.wait(1)
				workspace.Sounds.Notification:Play()
				v_u_30(v_u_21.TextLabel, "Nice you got a skill book!", 0.05)
				task.wait(1)
				workspace.Sounds.Notification:Play()
				v_u_30(v_u_21.TextLabel, "Now Let Equip It!", 0.05)
				local v33 = v_u_21.Frame
				v33.Visible = true
				v_u_3:Create(v33, TweenInfo.new(0.3, Enum.EasingStyle.Back), {
					["Size"] = UDim2.new(0.075, 0, 0.124, 0)
				}):Play()
				v_u_3:Create(v33, TweenInfo.new(0.6, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, -1, true), {
					["BackgroundTransparency"] = 1
				}):Play()
				task.wait(0.5)
				if v_u_4.TouchEnabled then
					v_u_3:Create(v33, TweenInfo.new(1, Enum.EasingStyle.Sine), {
						["Position"] = UDim2.new(0.017, 0, 0.45, 0),
						["Size"] = UDim2.new(0.055, 0, 0.1, 0)
					}):Play()
				else
					v_u_3:Create(v33, TweenInfo.new(1, Enum.EasingStyle.Sine), {
						["Position"] = UDim2.new(0.017, 0, 0.524, 0),
						["Size"] = UDim2.new(0.042, 0, 0.069, 0)
					}):Play()
				end
				repeat
					task.wait()
				until v_u_8
				task.wait(0.5)
				v_u_3:Create(v33, TweenInfo.new(1, Enum.EasingStyle.Sine), {
					["Position"] = UDim2.new(0.267, 0, 0.37, 0),
					["Size"] = UDim2.new(0.036, 0, 0.059, 0)
				}):Play()
				repeat
					task.wait()
				until v_u_9
				v_u_3:Create(v33, TweenInfo.new(1, Enum.EasingStyle.Sine), {
					["Position"] = UDim2.new(0.352, 0, 0.348, 0),
					["Size"] = UDim2.new(0.076, 0, 0.114, 0)
				}):Play()
				repeat
					task.wait()
				until v_u_11
				v_u_3:Create(v33, TweenInfo.new(1, Enum.EasingStyle.Sine), {
					["Position"] = UDim2.new(0.363, 0, 0.529, 0),
					["Size"] = UDim2.new(0.134, 0, 0.079, 0)
				}):Play()
				repeat
					task.wait()
				until v_u_12
				v33.Visible = false
				workspace.Sounds.Notification:Play()
				v_u_30(v_u_21.TextLabel, "Go to the dock to cast your rod! Follow the arrow.", 0.05)
				task.wait(0.5)
				local v34 = workspace:FindFirstChild("Map")
				local v35
				if v34 then
					v35 = v34:FindFirstChild("DockLocation")
				else
					v35 = v34
				end
				if v34 then
					v34 = v34:FindFirstChild("FishLocation")
				end
				local v36
				if v35 then
					if v35 then
						if v35:IsA("BasePart") then
							v36 = v35.Position
						elseif v35:IsA("Model") and v35.PrimaryPart then
							v36 = v35.PrimaryPart.Position
						else
							local v37 = v35:FindFirstChildWhichIsA("BasePart")
							v36 = v37 and v37.Position or nil
						end
					else
						v36 = nil
					end
				else
					v36 = v35
				end
				local v38
				if v34 then
					if v34 then
						if v34:IsA("BasePart") then
							v38 = v34.Position
						elseif v34:IsA("Model") and v34.PrimaryPart then
							v38 = v34.PrimaryPart.Position
						else
							local v39 = v34:FindFirstChildWhichIsA("BasePart")
							v38 = v39 and v39.Position or nil
						end
					else
						v38 = nil
					end
				else
					v38 = v34
				end
				local v40 = nil
				if v36 and v35 then
					local v41
					if v35:IsA("BasePart") then
						v41 = Instance.new("Attachment", v35)
					elseif v35.PrimaryPart then
						v41 = Instance.new("Attachment", v35.PrimaryPart)
					else
						local v42 = v35:FindFirstChildWhichIsA("BasePart")
						v41 = v42 and Instance.new("Attachment", v42) or nil
					end
					if v41 then
						v40 = game.ReplicatedStorage.Assets.Templates.Tutorial.Beam:Clone()
						v40.Parent = v_u_19.PrimaryPart
						v40.Attachment0 = v_u_22
						v40.Attachment1 = v41
					end
				end
				while true do
					task.wait(0.5)
					if not (v36 and v38) then
						break
					end
					local v43 = v_u_19.PrimaryPart
					if v43 then
						v43 = v_u_19.PrimaryPart.Position
					end
					if v_u_15 then
						break
					end
					if v43 and (v43 - v36).Magnitude <= 25 then
						if v40 then
							v40:Destroy()
							v40 = nil
						end
						workspace.Sounds.Notification:Play()
						v_u_30(v_u_21.TextLabel, "Now cast your rod here! Follow the arrow.", 0.05)
						task.wait(0.5)
						if v34 then
							local v44
							if v34:IsA("BasePart") then
								v44 = Instance.new("Attachment", v34)
							elseif v34.PrimaryPart then
								v44 = Instance.new("Attachment", v34.PrimaryPart)
							else
								local v45 = v34:FindFirstChildWhichIsA("BasePart")
								v44 = v45 and Instance.new("Attachment", v45) or nil
							end
							if v44 then
								v40 = game.ReplicatedStorage.Assets.Templates.Tutorial.Beam:Clone()
								v40.Parent = v_u_19.PrimaryPart
								v40.Attachment0 = v_u_22
								v40.Attachment1 = v44
							end
						end
						break
					end
				end
				repeat
					task.wait()
				until v_u_15
				if v40 then
					v40:Destroy()
				end
				workspace.Sounds.Notification:Play()
				v_u_30(v_u_21.TextLabel, "Wait for a fish to bite!", 0.05)
				task.wait(1)
				repeat
					task.wait()
				until v_u_14
				workspace.Sounds.Notification:Play()
				v_u_30(v_u_21.TextLabel, "Nice! Now go to the dock to sell your fish! Follow the arrow.", 0.05)
				task.wait(1)
				local v46 = nil
				for _, v47 in pairs(workspace.NPCs:GetChildren()) do
					if v47:IsA("Model") and (v47.Name == "bluewaterrobux" and v47:GetAttribute("First")) then
						v46 = v47
						break
					end
				end
				local v48
				if v46 and v46:FindFirstChild("HumanoidRootPart") then
					local v49 = Instance.new("Attachment", v46.PrimaryPart or v46.HumanoidRootPart)
					v48 = game.ReplicatedStorage.Assets.Templates.Tutorial.Beam:Clone()
					v48.Parent = v_u_19.PrimaryPart
					v48.Attachment0 = v_u_22
					v48.Attachment1 = v49
				else
					v48 = nil
				end
				repeat
					task.wait()
				until v_u_13
				if v48 then
					v48:Destroy()
				end
				workspace.Sounds.Notification:Play()
				v_u_30(v_u_21.TextLabel, "Nice, you complete tutorial! Enjoy the game!", 0.05)
				task.wait(2)
				v_u_31:Disconnect()
				v_u_21:Destroy()
			end)
		end
	}
	p17.Shared.Network:BindEvents(v50)
end
function v1.Pressed(_)
	-- upvalues: (ref) v_u_6, (ref) v_u_8
	if v_u_6 then
		v_u_8 = true
	end
end
function v1.PressedSlot(_)
	-- upvalues: (ref) v_u_6, (ref) v_u_9
	if v_u_6 then
		v_u_9 = true
	end
end
function v1.PressedSkill(_)
	-- upvalues: (ref) v_u_6, (ref) v_u_11
	if v_u_6 then
		v_u_11 = true
	end
end
function v1.PressAccept(_)
	-- upvalues: (ref) v_u_6, (ref) v_u_12
	if v_u_6 then
		v_u_12 = true
	end
end
function v1.WentToDock(_)
	-- upvalues: (ref) v_u_13
	v_u_13 = true
end
return v1