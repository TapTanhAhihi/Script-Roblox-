-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Settings)
local v4 = require(script.VectorMap)
local v_u_5 = {
	["WindDirection"] = Vector3.new(0.5, 0, 0.5),
	["WindPower"] = 0.5,
	["WindSpeed"] = 20
}
local v_u_6 = Instance.new("BindableEvent")
local v_u_7 = Instance.new("BindableEvent")
local v_u_8 = Instance.new("BindableEvent")
local v_u_9 = Instance.new("BindableEvent")
local v_u_10 = Instance.new("BindableEvent")
return {
	["RenderDistance"] = 150,
	["MaxRefreshRate"] = 0.016666666666666666,
	["SharedSettings"] = v_u_3.new(script),
	["ObjectMetadata"] = {},
	["VectorMap"] = v4.new(),
	["Handled"] = 0,
	["Active"] = 0,
	["_partList"] = table.create(500),
	["_cframeList"] = table.create(500),
	["ObjectShakeAdded"] = v_u_8.Event,
	["ObjectShakeRemoved"] = v_u_9.Event,
	["ObjectShakeUpdated"] = v_u_10.Event,
	["Paused"] = v_u_6.Event,
	["Resumed"] = v_u_7.Event,
	["Initialized"] = nil,
	["AddedConnection"] = nil,
	["UpdateConnection"] = nil,
	["RemovedConnection"] = nil,
	["WorkspaceWindConnection"] = nil,
	["AddObjectShake"] = function(p11, p12, p13)
		-- upvalues: (copy) v_u_3, (copy) v_u_8
		if typeof(p12) == "Instance" then
			if p12:IsA("BasePart") or p12:IsA("Bone") then
				local v14 = p11.ObjectMetadata
				if not v14[p12] then
					local v15 = {}
					local v16 = p11.VectorMap
					local v17
					if p12:IsA("Bone") then
						v17 = p12.WorldPosition
					else
						v17 = p12.Position
					end
					v15.ChunkKey = v16:AddObject(v17, p12)
					v15.Settings = v_u_3.new(p12)
					v15.Seed = math.random(5000) * 0.32
					local v18
					if p12:IsA("Bone") then
						v18 = p12.WorldCFrame
					else
						v18 = p12.CFrame
					end
					v15.Origin = v18
					v15.LastUpdate = os.clock()
					v14[p12] = v15
					if p13 then
						p11:UpdateObjectSettings(p12, p13)
					end
					v_u_8:Fire(p12)
					p11.Handled = p11.Handled + 1
				end
			else
				return
			end
		else
			return
		end
	end,
	["RemoveObjectShake"] = function(p19, p20)
		-- upvalues: (copy) v_u_9
		if typeof(p20) == "Instance" then
			if p20:IsA("BasePart") or p20:IsA("Bone") then
				local v21 = p19.ObjectMetadata
				local v22 = v21[p20]
				if v22 then
					p19.Handled = p19.Handled - 1
					v21[p20] = nil
					v22.Settings:Destroy()
					p19.VectorMap:RemoveObject(v22.ChunkKey, p20)
					if p20:IsA("BasePart") then
						p20.CFrame = v22.Origin
					elseif p20:IsA("Bone") then
						p20.WorldCFrame = v22.Origin
					end
				end
				v_u_9:Fire(p20)
			end
		else
			return
		end
	end,
	["Update"] = function(p23, p24)
		debug.profilebegin("WindShake")
		local v_u_25 = 0
		debug.profilebegin("Update")
		local v_u_26 = os.clock()
		local v_u_27 = p24 * 3
		local v28 = p24 * 5
		local v_u_29 = math.min(1, v28)
		local v_u_30 = 0
		local v_u_31 = p23._partList
		local v_u_32 = p23._cframeList
		table.clear(v_u_31)
		table.clear(v_u_32)
		local v_u_33 = p23.ObjectMetadata
		local v34 = workspace.CurrentCamera
		local v_u_35 = v34.CFrame.Position
		local v_u_36 = p23.RenderDistance
		local v_u_37 = p23.MaxRefreshRate
		local v38 = p23.SharedSettings
		local v39 = v38.WindPower
		local v_u_40 = assert(v39)
		local v41 = v38.WindSpeed
		local v_u_42 = assert(v41)
		local v43 = v38.WindDirection
		local v_u_44 = assert(v43)
		p23.VectorMap:ForEachObjectInView(v34, v_u_36, function(p45, p46)
			-- upvalues: (copy) v_u_33, (copy) v_u_35, (copy) v_u_36, (copy) v_u_27, (copy) v_u_37, (copy) v_u_26, (ref) v_u_25, (copy) v_u_44, (copy) v_u_40, (copy) v_u_42, (copy) v_u_29, (ref) v_u_30, (copy) v_u_31, (copy) v_u_32
			local v47 = v_u_33[p46]
			local v48 = v47.LastUpdate or 0
			local v49 = p45 == "Bone"
			local v50
			if v49 then
				v50 = p46.WorldCFrame
			else
				v50 = p46.CFrame
			end
			local v51 = (v_u_35 - v50.Position).Magnitude / v_u_36
			local v52 = v51 * v51
			local v53 = 1 / math.random(60, 120)
			if v_u_27 * v52 + v_u_37 >= v_u_26 - v48 + v53 then
				return
			else
				v47.LastUpdate = v_u_26
				v_u_25 = v_u_25 + 1
				local v54 = v47.Settings
				local v55 = v54.WindDirection or v_u_44
				if v55.Magnitude < 0.00001 then
					return
				else
					local v56 = (v54.WindPower or v_u_40) * 0.2
					if v56 < 0.00001 then
						return
					else
						local v57 = v_u_26 * ((v54.WindSpeed or v_u_42) * 0.08)
						if v57 < 0.00001 then
							return
						else
							local v58 = v47.Seed
							local v59 = (math.noise(v57, 0, v58) + 0.4) * v56
							local v60 = v_u_29 + v52
							local v61 = math.clamp(v60, 0.1, 0.5)
							local v62 = v56 / 3
							local v63 = v47.Origin * (v54.PivotOffset or CFrame.identity)
							local v64 = v63:VectorToObjectSpace(v55)
							if v49 then
								p46.Transform = p46.Transform:Lerp(CFrame.fromAxisAngle(v64:Cross(Vector3.new(0, 1, 0)), -v59) * CFrame.Angles(math.noise(v58, 0, v57) * v62, math.noise(v58, v57, 0) * v62, math.noise(v57, v58, 0) * v62) + v64 * v59 * v56, v61)
							else
								v_u_30 = v_u_30 + 1
								v_u_31[v_u_30] = p46
								v_u_32[v_u_30] = v50:Lerp(v63 * CFrame.fromAxisAngle(v64:Cross(Vector3.new(0, 1, 0)), -v59) * CFrame.Angles(math.noise(v58, 0, v57) * v62, math.noise(v58, v57, 0) * v62, math.noise(v57, v58, 0) * v62) * (v54.PivotOffsetInverse or CFrame.identity) + v55 * v59 * (v56 * 2), v61)
							end
						end
					end
				end
			end
		end)
		p23.Active = v_u_25
		debug.profileend()
		workspace:BulkMoveTo(v_u_31, v_u_32, Enum.BulkMoveMode.FireCFrameChanged)
		debug.profileend()
	end,
	["Pause"] = function(p65)
		-- upvalues: (copy) v_u_6
		if p65.UpdateConnection then
			p65.UpdateConnection:Disconnect()
			p65.UpdateConnection = nil
		end
		p65.Active = 0
		p65.Running = false
		v_u_6:Fire()
	end,
	["Resume"] = function(p_u_66)
		-- upvalues: (copy) v_u_2, (copy) v_u_7
		if not p_u_66.Running then
			local v67 = v_u_2.Heartbeat
			local v_u_68 = p_u_66.Update
			p_u_66.UpdateConnection = v67:Connect(function(...)
				-- upvalues: (copy) v_u_68, (copy) p_u_66
				return v_u_68(p_u_66, ...)
			end)
			p_u_66.Running = true
			v_u_7:Fire()
		end
	end,
	["Init"] = function(p_u_69, p70)
		-- upvalues: (copy) v_u_5, (copy) v_u_1
		if not p_u_69.Initialized then
			local v71 = script:GetAttribute("WindPower")
			local v72 = script:GetAttribute("WindSpeed")
			local v73 = script:GetAttribute("WindDirection")
			if typeof(v71) ~= "number" then
				script:SetAttribute("WindPower", v_u_5.WindPower)
			end
			if typeof(v72) ~= "number" then
				script:SetAttribute("WindSpeed", v_u_5.WindSpeed)
			end
			if typeof(v73) ~= "Vector3" then
				script:SetAttribute("WindDirection", v_u_5.WindDirection)
			end
			p_u_69:Cleanup()
			p_u_69.Initialized = true
			local v74 = v_u_1:GetInstanceAddedSignal("WindShake")
			local v_u_75 = p_u_69.AddObjectShake
			p_u_69.AddedConnection = v74:Connect(function(...)
				-- upvalues: (copy) v_u_75, (copy) p_u_69
				return v_u_75(p_u_69, ...)
			end)
			local v76 = v_u_1:GetInstanceRemovedSignal("WindShake")
			local v_u_77 = p_u_69.RemoveObjectShake
			p_u_69.RemovedConnection = v76:Connect(function(...)
				-- upvalues: (copy) v_u_77, (copy) p_u_69
				return v_u_77(p_u_69, ...)
			end)
			for _, v78 in v_u_1:GetTagged("WindShake") do
				if v78:IsA("BasePart") or v78:IsA("Bone") then
					p_u_69:AddObjectShake(v78)
				end
			end
			if p70 and p70.MatchWorkspaceWind then
				p_u_69:MatchWorkspaceWind()
				p_u_69.WorkspaceWindConnection = workspace:GetPropertyChangedSignal("GlobalWind"):Connect(function()
					-- upvalues: (copy) p_u_69
					p_u_69:MatchWorkspaceWind()
				end)
			end
			p_u_69:Resume()
		end
	end,
	["Cleanup"] = function(p79)
		if p79.Initialized then
			p79:Pause()
			if p79.AddedConnection then
				p79.AddedConnection:Disconnect()
				p79.AddedConnection = nil
			end
			if p79.RemovedConnection then
				p79.RemovedConnection:Disconnect()
				p79.RemovedConnection = nil
			end
			if p79.WorkspaceWindConnection then
				p79.WorkspaceWindConnection:Disconnect()
				p79.WorkspaceWindConnection = nil
			end
			table.clear(p79.ObjectMetadata)
			p79.VectorMap:ClearAll()
			p79.Handled = 0
			p79.Active = 0
			p79.Initialized = false
		end
	end,
	["UpdateObjectSettings"] = function(p80, p81, p82)
		-- upvalues: (copy) v_u_10
		if typeof(p81) == "Instance" then
			if typeof(p82) == "table" then
				if p80.ObjectMetadata[p81] or p81 == script then
					for v83, v84 in pairs(p82) do
						p81:SetAttribute(v83, v84)
					end
					v_u_10:Fire(p81)
				end
			else
				return
			end
		else
			return
		end
	end,
	["UpdateAllObjectSettings"] = function(p85, p86)
		-- upvalues: (copy) v_u_10
		if typeof(p86) == "table" then
			for v87, _ in p85.ObjectMetadata do
				for v88, v89 in pairs(p86) do
					v87:SetAttribute(v88, v89)
				end
				v_u_10:Fire(v87)
			end
		end
	end,
	["SetDefaultSettings"] = function(p90, p91)
		p90:UpdateObjectSettings(script, p91)
	end,
	["MatchWorkspaceWind"] = function(p92)
		local v93 = workspace.GlobalWind
		local v94 = v93.Unit
		local v95 = v93.Magnitude
		local v96, v97
		if v95 > 0 then
			v96 = v95 <= 1 and 0.3 or math.log10(v95) + 0.2
			if v95 < 100 then
				v97 = v95 * 1.2 + 5
			else
				v97 = 125
			end
		else
			v97 = 0
			v96 = 0
		end
		p92:SetDefaultSettings({
			["WindDirection"] = v94,
			["WindSpeed"] = v97,
			["WindPower"] = v96
		})
	end
}