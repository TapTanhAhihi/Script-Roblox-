-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = false
local v_u_3 = nil
function v1.Start(p4)
	-- upvalues: (ref) v_u_3
	local v5 = game:GetService("Players").LocalPlayer
	v_u_3 = p4.Shared.Network
	local v6 = v5.PlayerGui.Shop.Canvas.Main
	local v_u_7 = game:GetService("Players").LocalPlayer
	v_u_7:WaitForChild("PlayerGui")
	local _ = game:GetService("ReplicatedStorage").Modules.Data
	local v_u_8 = p4.Data.ProductConfig
	local v9 = p4.Shared.NumberFormatter
	local v_u_10 = game:GetService("MarketplaceService")
	local v11 = v6.Container
	local v12 = v11.Robux
	local v13 = v11.Coin
	for v_u_14, v15 in pairs(v_u_8.Products) do
		local v16 = game.ReplicatedStorage.Assets.Templates.Shop.Template:Clone()
		v16.Parent = v13.Content
		v16.Main.TextLabel.Text = v9.Format(v15)
		v16.LayoutOrder = v15
		local v17 = v_u_10:GetProductInfo(v_u_14, Enum.InfoType.Product)
		v16.Main.Purchase.Main.TextLabel.Text = "R$" .. v17.PriceInRobux
		v16.Main.ImageButton.Activated:Connect(function()
			-- upvalues: (copy) v_u_10, (copy) v_u_7, (copy) v_u_14
			v_u_10:PromptProductPurchase(v_u_7, v_u_14)
		end)
	end
	for _, v_u_18 in pairs(v12.Content:GetChildren()) do
		print(v_u_18.Name, v_u_8.Robux[v_u_18.Name])
		if v_u_18:IsA("Frame") and v_u_8.Robux[v_u_18.Name] then
			v_u_18.Main.ImageButton.Activated:Connect(function()
				-- upvalues: (copy) v_u_10, (copy) v_u_7, (copy) v_u_8, (copy) v_u_18
				print("Act")
				v_u_10:PromptGamePassPurchase(v_u_7, v_u_8.Robux[v_u_18.Name])
			end)
		end
	end
end
function v1.Active(p19)
	-- upvalues: (ref) v_u_2
	if v_u_2 then
		return
	else
		local v20 = game:GetService("Players").LocalPlayer
		repeat
			task.wait()
		until v20:FindFirstChild("PlayerGui")
		local v21 = v20.PlayerGui:WaitForChild("Shop")
		game:GetService("TweenService")
		local v22 = p19.Shared.sprLib
		v_u_2 = true
		task.delay(0.5, function()
			-- upvalues: (ref) v_u_2
			v_u_2 = false
		end)
		v21.Enabled = not v21.Enabled
		v21.Canvas.Size = UDim2.new(0, 0, 1, 0)
		if v21.Enabled then
			p19.Controllers.HUD:CloseAllUI(v21)
			p19.Controllers.HUD:Effect(true)
			v22.target(v21.Canvas, 1, 4, {
				["Size"] = UDim2.new(1, 0, 1, 0)
			})
		else
			p19.Controllers.HUD:Effect(false)
		end
	end
end
return v1