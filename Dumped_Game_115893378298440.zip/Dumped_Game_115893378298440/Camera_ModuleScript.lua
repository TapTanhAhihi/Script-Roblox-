-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v2 = game:GetService("Players")
game:GetService("RunService")
local v_u_3 = nil
local v_u_4 = v2.LocalPlayer
local v_u_5 = workspace.CurrentCamera
local v_u_6 = nil
local v_u_7 = nil
function v1.Init(p8)
	-- upvalues: (ref) v_u_3, (ref) v_u_6, (ref) v_u_7, (ref) v_u_5
	v_u_3 = p8.Shared.Network
	v_u_6 = p8.Shared.CameraShaker
	if v_u_6 then
		v_u_7 = v_u_6.new(Enum.RenderPriority.Camera.Value, function(p9)
			-- upvalues: (ref) v_u_5
			if v_u_5 then
				v_u_5.CFrame = v_u_5.CFrame * p9
			end
		end)
		v_u_7:Start()
	end
	v_u_3:BindEvents({
		["CameraShake"] = function(p10, ...)
			-- upvalues: (ref) v_u_7, (ref) v_u_6
			if v_u_7 then
				if _G.AllowedCamera then
					local v11 = { ... }
					if p10 == "preset" then
						local v12 = v11[1]
						if v_u_6.Presets and v_u_6.Presets[v12] then
							local v_u_13 = v_u_6.Presets[v12]
							local v_u_14 = v_u_6.CameraShakeInstance.new(v_u_13.Magnitude, v_u_13.Roughness, v_u_13.fadeInDuration, v_u_13.fadeOutDuration)
							v_u_14.PositionInfluence = v_u_13.PositionInfluence
							v_u_14.RotationInfluence = v_u_13.RotationInfluence
							if v12 == "SmallToBig" then
								v_u_14:SetScaleMagnitude(0.1)
								task.spawn(function()
									-- upvalues: (copy) v_u_13, (copy) v_u_14
									local v15 = tick()
									local v16 = v_u_13.fadeOutDuration or 0.3
									while v_u_14:IsShaking() do
										local v17 = (tick() - v15) / v16
										v_u_14:SetScaleMagnitude(math.min(v17, 1) * 0.9 + 0.1)
										task.wait()
									end
								end)
							end
							v_u_7:Shake(v_u_14)
							return
						end
					else
						if p10 == "custom" then
							v_u_7:ShakeOnce(v11[1] or 1, v11[2] or 1, v11[3] or 0.1, v11[4] or 0.5, v11[5] or Vector3.new(0.15, 0.15, 0.15), v11[6] or Vector3.new(1, 1, 1))
							return
						end
						if p10 == "sustain" then
							local v18 = v11[1]
							if v_u_6.Presets and v_u_6.Presets[v18] then
								local v19 = v_u_6.Presets[v18]
								local v20 = v_u_6.CameraShakeInstance.new(v19.Magnitude, v19.Roughness, v19.fadeInDuration, v19.fadeOutDuration)
								v20.PositionInfluence = v19.PositionInfluence
								v20.RotationInfluence = v19.RotationInfluence
								v_u_7:ShakeSustain(v20)
							else
								local v21 = v11[1] or 0.3
								local v22 = v11[2] or 1
								local v23 = v11[3] or 0.5
								local v24 = v11[4] or Vector3.new(0.15, 0.15, 0.15)
								local v25 = v11[5] or Vector3.new(1, 1, 1)
								local v26 = v_u_6.CameraShakeInstance.new(v21, v22, v23, 0)
								v26.PositionInfluence = v24
								v26.RotationInfluence = v25
								v_u_7:ShakeSustain(v26)
							end
						end
						if p10 == "stop" then
							v_u_7:StopSustained(v11[1] or 0.5)
							return
						end
						v_u_7:ShakeOnce(p10 or 1, v11[1] or 1, v11[2] or 0.1, v11[3] or 0.5)
					end
				end
			else
				return
			end
		end,
		["StopShaking"] = function()
			-- upvalues: (ref) v_u_7
			v_u_7:Stop()
		end,
		["CameraShakeSimple"] = function(p27, p28, p29, p30)
			-- upvalues: (ref) v_u_7
			if v_u_7 then
				v_u_7:ShakeOnce(p27 or 1, p28 or 1, p29 or 0.1, p30 or 0.5)
			end
		end,
		["CameraEarthquake"] = function(p31, p32)
			-- upvalues: (ref) v_u_7, (ref) v_u_6
			if v_u_7 then
				if v_u_6.Presets and v_u_6.Presets.Earthquake then
					v_u_7:ShakeSustain(v_u_6.Presets.Earthquake)
				else
					local v33 = v_u_6.CameraShakeInstance.new(p31 or 0.3, 1, 0.3, 0)
					v33.PositionInfluence = Vector3.new(0.15, 0.15, 0.15)
					v33.RotationInfluence = Vector3.new(1, 1, 1)
					local v_u_34 = v_u_7:ShakeSustain(v33)
					if p32 then
						task.delay(p32, function()
							-- upvalues: (copy) v_u_34
							if v_u_34 then
								v_u_34:StartFadeOut(0.5)
							end
						end)
					end
				end
			else
				return
			end
		end
	})
end
function v1.Start(_)
	-- upvalues: (copy) v_u_4, (ref) v_u_5, (ref) v_u_7, (ref) v_u_6
	v_u_4.CharacterAdded:Connect(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_7, (ref) v_u_6
		v_u_5 = workspace.CurrentCamera
		if not v_u_7 then
			if not v_u_6 then
				return
			end
			v_u_7 = v_u_6.new(Enum.RenderPriority.Camera.Value, function(p35)
				-- upvalues: (ref) v_u_5
				if v_u_5 then
					v_u_5.CFrame = v_u_5.CFrame * p35
				end
			end)
			v_u_7:Start()
		end
	end)
	if workspace.CurrentCamera then
		v_u_5 = workspace.CurrentCamera
	end
	if v_u_6 and not v_u_7 then
		if not v_u_6 then
			return
		end
		v_u_7 = v_u_6.new(Enum.RenderPriority.Camera.Value, function(p36)
			-- upvalues: (ref) v_u_5
			if v_u_5 then
				v_u_5.CFrame = v_u_5.CFrame * p36
			end
		end)
		v_u_7:Start()
	end
end
function v1.ShakePreset(_, p37)
	-- upvalues: (ref) v_u_7, (ref) v_u_6
	if v_u_7 then
		if v_u_6.Presets and v_u_6.Presets[p37] then
			v_u_7:Shake(v_u_6.Presets[p37])
		end
	end
end
function v1.ShakeCustom(_, p38, p39, p40, p41, p42, p43)
	-- upvalues: (ref) v_u_7
	if v_u_7 then
		v_u_7:ShakeOnce(p38, p39, p40, p41, p42, p43)
	end
end
function v1.ShakeSustain(_, p44)
	-- upvalues: (ref) v_u_7, (ref) v_u_6
	if v_u_7 then
		if v_u_6.Presets and v_u_6.Presets[p44] then
			return v_u_7:ShakeSustain(v_u_6.Presets[p44])
		else
			return nil
		end
	else
		return
	end
end
function v1.StopSustained(_, p45)
	-- upvalues: (ref) v_u_7
	if v_u_7 then
		v_u_7:StopSustained(p45)
	end
end
return v1