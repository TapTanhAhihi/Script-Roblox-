-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = v2.LocalPlayer
v1._timerConnection = nil
v1._currentExpire = 0
v1._purchased = {}
function v1.Init(p_u_5)
	p_u_5.Shared.Network:BindEvents({
		["UpdateSkillShop"] = function(p6)
			-- upvalues: (copy) p_u_5
			p_u_5._purchased = {}
			p_u_5:Update(p6)
		end
	})
end
function v1.StartTimer(p_u_7, p8)
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	p_u_7._currentExpire = p8
	if p_u_7._timerConnection then
		p_u_7._timerConnection:Disconnect()
		p_u_7._timerConnection = nil
	end
	local v_u_9 = v_u_4:WaitForChild("PlayerGui").SkillShop
	local v_u_10 = v_u_9.Frame.Timer
	p_u_7._timerConnection = v_u_3.Heartbeat:Connect(function()
		-- upvalues: (copy) v_u_9, (copy) p_u_7, (copy) v_u_10
		if v_u_9.Enabled then
			local v11 = p_u_7._currentExpire - os.time()
			local v12 = v_u_10
			local v13 = v11 < 0 and 0 or v11
			local v14 = v13 / 3600
			local v15 = math.floor(v14)
			local v16 = v13 % 3600 / 60
			local v17 = math.floor(v16)
			local v18 = v13 % 60
			v12.Text = "Renew In " .. string.format("%02d:%02d:%02d", v15, v17, v18)
			if v11 <= 0 then
				v_u_10.Text = "Renewing..."
			end
		end
	end)
end
function v1.Update(p_u_19, p20)
	-- upvalues: (copy) v_u_4
	local v21 = v_u_4:WaitForChild("PlayerGui").SkillShop
	local v22 = p_u_19.Data.SkillConfig
	local v_u_23 = p_u_19.Shared.Network
	local v24 = p20 or v_u_23:InvokeServer("GetShopNow")
	if v24 then
		p_u_19:StartTimer(v24.ExpireAt)
		local v25 = v24.Items
		local v26 = nil
		local v27
		if v24.Purchases then
			local v28 = v_u_4.UserId
			local v29 = tostring(v28)
			v27 = v24.Purchases[v29]
			if typeof(v27) ~= "table" then
				v27 = v26
			end
		elseif v24.Bought then
			local v30 = v24.Bought
			if typeof(v30) == "table" then
				v27 = v24.Bought
			else
				v27 = v26
			end
		else
			v27 = v26
		end
		p_u_19._purchased = {}
		if v27 and v24.ExpireAt then
			for v31, v32 in pairs(v27) do
				if v32 == true or v32 == v24.ExpireAt then
					p_u_19._purchased[v31] = true
				end
			end
		end
		for _, v33 in pairs(v21.Frame.ScrollingFrame:GetChildren()) do
			if v33:IsA("ImageButton") then
				v33:Destroy()
			end
		end
		for v_u_34, v35 in pairs(v22.Skills) do
			if v35.InShopChance ~= 0 then
				local v_u_36 = game.ReplicatedStorage.Assets.Templates.SkillShop.Template:Clone()
				v_u_36.Parent = v21.Frame.ScrollingFrame
				v_u_36.Rarity.Text = v35.RarityType
				v_u_36.BookName.Text = v_u_34
				v_u_36.BookPrice.TextColor3 = Color3.fromRGB(255, 1, 81)
				v_u_36.BookPrice.Text = "Offsale"
				v_u_36.BuyButton.Visible = false
				local v37 = v_u_36:FindFirstChild("RobuxButton") or v_u_36:FindFirstChild("Robux", true)
				if v37 then
					if v35.ProductId and v35.ProductId > 0 then
						v37.Visible = true
						if v37:IsA("TextButton") or v37:IsA("ImageButton") then
							v37.Activated:Connect(function()
								-- upvalues: (copy) v_u_23, (copy) v_u_34
								pcall(function()
									-- upvalues: (ref) v_u_23, (ref) v_u_34
									v_u_23:InvokeServer("BuySkillWithRobux", v_u_34)
								end)
							end)
						end
					else
						v37.Visible = false
					end
				end
				if p_u_19._purchased[v_u_34] ~= true and (v25 and table.find(v25, v_u_34)) then
					v_u_36.BuyButton.Visible = true
					v_u_36.BookPrice.TextColor3 = Color3.fromRGB(0, 255, 127)
					v_u_36.BookPrice.Text = "$" .. (v35.BookPrice or 0)
					if v_u_34 == "Motor Fishing Technique" then
						v_u_36.BookPrice.Text = "Free"
					end
				end
				v_u_36.Cooldown.Text = "CD: " .. v35.Cooldown .. "s"
				v_u_36.Name = v_u_34
				v_u_36.Display.Image = v35.Book
				v_u_36.BuyButton.Activated:Connect(function()
					-- upvalues: (copy) v_u_23, (copy) v_u_34, (copy) p_u_19, (copy) v_u_36
					if v_u_23:InvokeServer("BuyThisBook", v_u_34) == "Success" then
						p_u_19._purchased[v_u_34] = true
						v_u_36.BookPrice.TextColor3 = Color3.fromRGB(255, 1, 81)
						v_u_36.BookPrice.Text = "Expired"
						v_u_36.BuyButton.Visible = false
					end
				end)
				local v38 = v35.RarityType
				if v38 == "Common" then
					v_u_36.UIStroke.Color = Color3.fromRGB(131, 131, 131)
					v_u_36.Display.BackgroundColor3 = Color3.fromRGB(131, 131, 131)
					v_u_36.LayoutOrder = 1
				elseif v38 == "Uncommon" then
					v_u_36.UIStroke.Color = Color3.fromRGB(78, 116, 255)
					v_u_36.Display.BackgroundColor3 = Color3.fromRGB(85, 170, 255)
					v_u_36.LayoutOrder = 2
				elseif v38 == "Rare" then
					v_u_36.UIStroke.Color = Color3.fromRGB(85, 0, 127)
					v_u_36.Display.BackgroundColor3 = Color3.fromRGB(170, 85, 255)
					v_u_36.LayoutOrder = 3
				elseif v38 == "Legendary" then
					v_u_36.UIStroke.Color = Color3.fromRGB(255, 130, 47)
					v_u_36.Display.BackgroundColor3 = Color3.fromRGB(255, 195, 43)
					v_u_36.LayoutOrder = 4
				elseif v38 == "Mythical" then
					v_u_36.UIStroke.Color = Color3.fromRGB(170, 0, 0)
					v_u_36.Display.BackgroundColor3 = Color3.fromRGB(255, 83, 86)
					v_u_36.LayoutOrder = 5
				end
				if v_u_34 == "Motor Fishing Technique" then
					v_u_36.LayoutOrder = 0
				end
			end
		end
	end
end
function v1.Activate(p39)
	-- upvalues: (copy) v_u_4
	v_u_4:WaitForChild("PlayerGui").SkillShop.Enabled = true
	p39:Update()
end
return v1