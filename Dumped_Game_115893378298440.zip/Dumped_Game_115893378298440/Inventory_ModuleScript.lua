-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = {}
local v_u_2 = false
local v_u_3 = game:GetService("Players")
game:GetService("TweenService")
local v_u_4 = "Rods"
local v_u_5 = nil
local v_u_6 = nil
pcall(function()
	-- upvalues: (ref) v_u_6
	local v7 = game:GetService("ReplicatedStorage"):FindFirstChild("Modules")
	if v7 then
		local v8 = v7:FindFirstChild("Shared")
		local v9 = v8 and v8:FindFirstChild("Localize")
		if v9 then
			v_u_6 = require(v9)
		end
	end
end)
local v_u_10 = {
	["Rod"] = {}
}
local v_u_11 = {}
local v_u_12 = nil
local v_u_13 = "Normal Bait"
local v_u_14 = nil
v_u_1._unlearnKeepCache = v_u_1._unlearnKeepCache or {}
local function v_u_31(p15, p16, p_u_17, p_u_18)
	-- upvalues: (copy) v_u_1
	if p15 then
		local v19 = p15:FindFirstChild("Canvas")
		local v_u_20 = v19 and v19:FindFirstChild("AcceptFrame") or p15:FindFirstChild("AcceptFrame", true)
		if v_u_20 then
			local v21 = v_u_20:FindFirstChild("TextLabel")
			local v22 = v_u_20:FindFirstChild("YesButton")
			local v23 = v_u_20:FindFirstChild("NoButton")
			if v21 and v21:IsA("TextLabel") then
				v21.Text = p16 or ""
			end
			v_u_20.Visible = true
			v_u_1._acceptFrameOpen = true
			if not v_u_1._acceptFrameConns then
				v_u_1._acceptFrameConns = {}
			end
			for _, v_u_24 in ipairs(v_u_1._acceptFrameConns) do
				if v_u_24 and v_u_24.Disconnect then
					pcall(function()
						-- upvalues: (copy) v_u_24
						v_u_24:Disconnect()
					end)
				end
			end
			v_u_1._acceptFrameConns = {}
			if v22 and (v22:IsA("TextButton") or v22:IsA("ImageButton")) then
				local v25 = v_u_1._acceptFrameConns
				local v26 = v22.Activated
				local function v27()
					-- upvalues: (copy) v_u_20, (ref) v_u_1, (copy) p_u_17
					v_u_20.Visible = false
					v_u_1._acceptFrameOpen = false
					if p_u_17 then
						p_u_17()
					end
				end
				table.insert(v25, v26:Connect(v27))
			end
			if v23 and (v23:IsA("TextButton") or v23:IsA("ImageButton")) then
				local v28 = v_u_1._acceptFrameConns
				local v29 = v23.Activated
				local function v30()
					-- upvalues: (copy) v_u_20, (ref) v_u_1, (copy) p_u_18
					v_u_20.Visible = false
					v_u_1._acceptFrameOpen = false
					if p_u_18 then
						p_u_18()
					end
				end
				table.insert(v28, v29:Connect(v30))
			end
		end
	else
		return
	end
end
function v_u_1.ShowSkillBookPicker(p_u_32, p_u_33, p_u_34, p_u_35, p36, p_u_37, p_u_38)
	-- upvalues: (ref) v_u_5, (copy) v_u_1, (copy) v_u_31
	if v_u_5 then
		local v_u_39 = p_u_32.Data
		if v_u_39 then
			v_u_39 = p_u_32.Data.SkillConfig
		end
		local v_u_40 = {}
		if v_u_39 and v_u_39.Skills then
			for v41, v42 in pairs(v_u_39.Skills) do
				if type(v42) == "table" then
					v_u_40[v41] = true
				end
			end
		end
		if v_u_39 then
			v_u_39 = v_u_39.Skills
		end
		local v43, v44, v45
		if p36 and (p36.Tradeable or (p36.Untradeable or p36.Permanent)) then
			v43 = p36.Tradeable or {}
			v44 = p36.Untradeable or {}
			v45 = p36.Permanent or {}
		else
			v43 = p36 or {}
			v44 = {}
			v45 = {}
		end
		local v_u_46 = {}
		local function v59(p47, p48)
			-- upvalues: (copy) v_u_39, (copy) v_u_40, (copy) v_u_46, (copy) p_u_37
			for v49, v50 in pairs(p47 or {}) do
				if p48 == "Permanent" then
					if v50 then
						if v_u_39 and v_u_39[v49] then
							local v51 = v_u_39[v49]
							if type(v51) ~= "table" or not v_u_40[v49] then
								goto l9
							end
							local v52 = v_u_46
							table.insert(v52, {
								["Name"] = v49,
								["Amount"] = "\226\136\158",
								["Source"] = p48
							})
						else
							::l9::
							if p_u_37 and (p_u_37[v49] and v49 ~= "SlotOrder") then
								local v53 = p_u_37[v49]
								if type(v53) == "table" then
									local v54 = v_u_46
									table.insert(v54, {
										["Name"] = v49,
										["Amount"] = "\226\136\158",
										["Source"] = p48
									})
								end
							end
						end
					end
				elseif type(v50) == "number" and v50 > 0 then
					if v_u_39 and v_u_39[v49] then
						local v55 = v_u_39[v49]
						if type(v55) ~= "table" or not v_u_40[v49] then
							goto l20
						end
						local v56 = v_u_46
						table.insert(v56, {
							["Name"] = v49,
							["Amount"] = v50,
							["Source"] = p48
						})
					else
						::l20::
						if p_u_37 and (p_u_37[v49] and v49 ~= "SlotOrder") then
							local v57 = p_u_37[v49]
							if type(v57) == "table" then
								local v58 = v_u_46
								table.insert(v58, {
									["Name"] = v49,
									["Amount"] = v50,
									["Source"] = p48
								})
							end
						end
					end
				end
			end
		end
		v59(v43, "Gacha")
		v59(v44, "Shop")
		v59(v45, "Permanent")
		if #v_u_46 == 0 then
			pcall(function()
				-- upvalues: (ref) v_u_5
				v_u_5:FireServer("RequestSendNotification", {
					["Text"] = "You don\'t have any skill",
					["Type"] = "Error"
				})
			end)
		end
		if p_u_33 and not (p_u_33:IsA("ScreenGui") and p_u_33) then
			p_u_33 = p_u_33:FindFirstAncestorOfClass("ScreenGui")
		end
		local v_u_60
		if p_u_33 then
			v_u_60 = p_u_33:FindFirstChild("BookInventory")
		else
			v_u_60 = p_u_33
		end
		if v_u_60 then
			v_u_1._skillPickerOpen = true
			local v_u_61 = v_u_60:FindFirstChild("ScrollingFrame")
			local v_u_62
			if v_u_61 then
				v_u_62 = v_u_61:FindFirstChild("SkillTemplate") or v_u_61:FindFirstChild("SkillTemplate", true)
			else
				v_u_62 = v_u_61
			end
			local v63 = v_u_60:FindFirstChild("Close")
			local v64 = v_u_60:FindFirstChild("ButtonFrame")
			if v_u_61 and v_u_62 then
				local function v_u_72(p65)
					-- upvalues: (copy) v_u_46
					if p65 == "All" then
						return v_u_46
					end
					if p65 == "Tradeable" then
						local v66 = {}
						for _, v67 in ipairs(v_u_46) do
							if v67.Source == "Gacha" then
								table.insert(v66, v67)
							end
						end
						return v66
					end
					if p65 == "Untradeable" then
						local v68 = {}
						for _, v69 in ipairs(v_u_46) do
							if v69.Source == "Shop" then
								table.insert(v68, v69)
							end
						end
						return v68
					end
					if p65 ~= "Permanent" then
						return v_u_46
					end
					local v70 = {}
					for _, v71 in ipairs(v_u_46) do
						if v71.Source == "Permanent" then
							table.insert(v70, v71)
						end
					end
					return v70
				end
				local function v_u_94(p73)
					-- upvalues: (copy) v_u_62, (copy) v_u_61, (copy) v_u_39, (copy) p_u_32, (ref) v_u_31, (copy) p_u_33, (ref) v_u_5, (copy) p_u_34, (copy) p_u_35, (copy) v_u_60, (copy) p_u_38, (ref) v_u_1
					v_u_62.Visible = false
					for _, v74 in ipairs(v_u_61:GetChildren()) do
						if v74 ~= v_u_62 and not (v74:IsA("UILayout") or v74:IsA("UIPadding")) then
							v74:Destroy()
						end
					end
					for _, v_u_75 in ipairs(p73) do
						local v76 = v_u_62:Clone()
						v76.Visible = true
						v76.Name = "SkillEntry_" .. v_u_75.Name
						local v77 = v_u_39 and v_u_39[v_u_75.Name]
						if v77 then
							local v78 = v_u_39[v_u_75.Name]
							if type(v78) == "table" then
								v77 = v_u_39[v_u_75.Name]
							else
								v77 = false
							end
						end
						local v79
						if v77 then
							v79 = v77.RarityType
						else
							v79 = v77
						end
						if v77 and v79 then
							if v79 == "Common" then
								v76.BackgroundColor3 = Color3.fromRGB(131, 131, 131)
								v76.UIStroke.Color = Color3.fromRGB(131, 131, 131)
								v76.LayoutOrder = 1
							elseif v79 == "Uncommon" then
								v76.BackgroundColor3 = Color3.fromRGB(85, 170, 255)
								v76.UIStroke.Color = Color3.fromRGB(78, 116, 255)
								v76.LayoutOrder = 2
							elseif v79 == "Rare" then
								v76.BackgroundColor3 = Color3.fromRGB(170, 85, 255)
								v76.UIStroke.Color = Color3.fromRGB(85, 0, 127)
								v76.LayoutOrder = 3
							elseif v79 == "Legendary" then
								v76.BackgroundColor3 = Color3.fromRGB(255, 195, 43)
								v76.UIStroke.Color = Color3.fromRGB(255, 130, 47)
								v76.LayoutOrder = 4
							elseif v79 == "Mythical" then
								v76.BackgroundColor3 = Color3.fromRGB(255, 83, 86)
								v76.UIStroke.Color = Color3.fromRGB(170, 0, 0)
								v76.LayoutOrder = 5
							end
						end
						local v80 = v77 and v77.Book or ""
						if v80 ~= "" then
							if v76:IsA("ImageButton") or v76:IsA("ImageLabel") then
								v76.Image = v80
							else
								local v81 = v76:FindFirstChildWhichIsA("ImageButton") or v76:FindFirstChildWhichIsA("ImageLabel")
								if v81 then
									v81.Image = v80
								end
							end
						end
						local v82 = v76:FindFirstChild("SkillName") or v76:FindFirstChild("SkillName", true)
						if v82 and v82:IsA("TextLabel") then
							local v83 = v_u_75.Source == "Gacha" and "[Gacha] " or (v_u_75.Source == "Shop" and "[Shop] " or (v_u_75.Source == "Permanent" and "[Permanent] " or ""))
							local v84
							if v_u_75.Source == "Permanent" then
								v84 = ""
							else
								local v85 = v_u_75.Amount
								v84 = "x" .. tostring(v85)
							end
							v82.Text = v83 .. v_u_75.Name .. " " .. v84
						end
						v76.Parent = v_u_61
						(v76:IsA("GuiButton") and v76 or v76:FindFirstChildWhichIsA("GuiButton") or (v76:FindFirstChildWhichIsA("TextButton") or v76:FindFirstChildWhichIsA("ImageButton")) or v76).Activated:Connect(function()
							-- upvalues: (ref) p_u_32, (ref) v_u_31, (ref) p_u_33, (copy) v_u_75, (ref) v_u_5, (ref) p_u_34, (ref) p_u_35, (ref) v_u_60, (ref) p_u_38, (ref) v_u_1
							p_u_32.Controllers.Tutorial:PressedSkill()
							v_u_31(p_u_33, "Learn this skill?", function()
								-- upvalues: (ref) p_u_32, (ref) v_u_75, (ref) v_u_5, (ref) p_u_34, (ref) p_u_35, (ref) v_u_60, (ref) p_u_38, (ref) v_u_1
								p_u_32.Controllers.Tutorial:PressAccept()
								local v_u_86 = v_u_75.Source == "Gacha" and "Tradeable" or (v_u_75.Source == "Shop" and "Untradeable" or (v_u_75.Source == "Permanent" and "Permanent" or "Tradeable"))
								local v87, v88 = pcall(function()
									-- upvalues: (ref) v_u_5, (ref) p_u_34, (ref) p_u_35, (ref) v_u_75, (copy) v_u_86
									return v_u_5:InvokeServer("LearnSkill", p_u_34, p_u_35, v_u_75.Name, v_u_86)
								end)
								if v87 and v88 then
									local v_u_89 = p_u_32.Controllers
									if v_u_89 then
										v_u_89 = p_u_32.Controllers.SkillClient
									end
									local v90 = p_u_32.Controllers
									if v90 then
										v90 = p_u_32.Controllers.RodController
									end
									if v_u_89 and (v90 and v90:GetCurrentRodName() == p_u_34) then
										local v_u_91 = v90:GetCurrentRodLevel() or 1
										task.defer(function()
											-- upvalues: (copy) v_u_89, (ref) p_u_34, (copy) v_u_91
											v_u_89:UpdateSkillsUI(p_u_34, v_u_91)
										end)
									end
									local v92 = v_u_60
									local v93 = p_u_38
									if v92 and v92.Parent then
										v92.Visible = false
									end
									v_u_1._skillPickerOpen = false
									if v93 then
										v93()
										return
									end
								elseif not v87 then
									pcall(function()
										-- upvalues: (ref) v_u_5
										v_u_5:FireServer("RequestSendNotification", {
											["Text"] = "Failed to learn skill",
											["Type"] = "Error"
										})
									end)
								end
							end, nil)
						end)
					end
				end
				if v64 then
					if not v_u_1._bookInventoryFilterConns then
						v_u_1._bookInventoryFilterConns = {}
					end
					for _, v95 in pairs(v_u_1._bookInventoryFilterConns) do
						if v95 then
							v95:Disconnect()
						end
					end
					v_u_1._bookInventoryFilterConns = {}
					for _, v96 in ipairs(v64:GetChildren()) do
						if v96:IsA("ImageButton") or v96:IsA("TextButton") then
							local v_u_97 = v96.Name
							if v_u_97 == "All" or (v_u_97 == "Tradeable" or (v_u_97 == "Untradeable" or v_u_97 == "Permanent")) then
								local v98 = v96.Activated:Connect(function()
									-- upvalues: (copy) v_u_94, (copy) v_u_72, (copy) v_u_97
									v_u_94((v_u_72(v_u_97)))
								end)
								local v99 = v_u_1._bookInventoryFilterConns
								table.insert(v99, v98)
							end
						end
					end
				end
				v_u_94(v_u_46)
				v_u_60.Visible = true
				if v63 and (v63:IsA("TextButton") or v63:IsA("ImageButton")) then
					if not v_u_1._bookInventoryCloseConns then
						v_u_1._bookInventoryCloseConns = {}
					end
					local v100 = v_u_1._bookInventoryCloseConns[v63]
					if v100 then
						v100:Disconnect()
					end
					v_u_1._bookInventoryCloseConns[v63] = v63.Activated:Connect(function()
						-- upvalues: (copy) v_u_60, (copy) p_u_38, (ref) v_u_1
						local v101 = v_u_60
						local v102 = p_u_38
						if v101 and v101.Parent then
							v101.Visible = false
						end
						v_u_1._skillPickerOpen = false
						if v102 then
							v102()
						end
					end)
				end
			end
		else
			return
		end
	else
		return
	end
end
function v_u_1.UpdateFor()
	-- upvalues: (copy) v_u_3, (ref) v_u_5, (ref) v_u_10, (ref) v_u_12, (ref) v_u_6, (copy) v_u_1, (copy) v_u_31, (ref) v_u_4, (ref) v_u_2, (ref) v_u_14, (ref) v_u_13
	-- failed to decompile
end
function v_u_1.Start(p_u_103)
	-- upvalues: (ref) v_u_5, (copy) v_u_3, (copy) v_u_1, (ref) v_u_10, (ref) v_u_13, (ref) v_u_4, (ref) v_u_2, (copy) v_u_11
	v_u_5 = p_u_103.Shared.Network
	local v104 = p_u_103.Data.FishConfig
	local v_u_105 = v_u_3.LocalPlayer.PlayerGui:WaitForChild("Inventory")
	local v106 = v_u_105.Canvas.Main.Buttons
	v_u_105.BookInventory.CloseButton.Activated:Connect(function()
		-- upvalues: (copy) v_u_105, (ref) v_u_1
		local v107 = v_u_105.BookInventory
		if v107 and v107.Parent then
			v107.Visible = false
		end
		v_u_1._skillPickerOpen = false
	end)
	if v_u_5 then
		v_u_5:BindEvents({
			["BaitInfo"] = function(p108, p109, _)
				-- upvalues: (ref) v_u_10, (ref) v_u_13, (ref) v_u_4, (copy) p_u_103
				v_u_10.Baits = p108 or {}
				v_u_13 = p109 or "Normal Bait"
				if v_u_4 == "Baits" then
					p_u_103:UpdateFor("Baits")
				end
			end,
			["BaitEquipped"] = function(p110)
				-- upvalues: (ref) v_u_13, (ref) v_u_4, (copy) p_u_103
				v_u_13 = p110 or "Normal Bait"
				if v_u_4 == "Baits" then
					p_u_103:UpdateFor("Baits")
				end
			end,
			["BaitUpdated"] = function(p111, p112)
				-- upvalues: (ref) v_u_10, (ref) v_u_4, (copy) p_u_103
				v_u_10.Baits = v_u_10.Baits or {}
				if p112 <= 0 then
					v_u_10.Baits[p111] = nil
				else
					v_u_10.Baits[p111] = p112
				end
				if v_u_4 == "Baits" then
					p_u_103:UpdateFor("Baits")
				end
			end,
			["FishBodyDrop"] = function(_)
				-- upvalues: (ref) v_u_4, (copy) p_u_103
				if v_u_4 == "Items" then
					p_u_103:UpdateFor("Items")
				end
			end,
			["FishBodyEquipped"] = function(_)
				-- upvalues: (ref) v_u_4, (copy) p_u_103
				if v_u_4 == "Items" then
					p_u_103:UpdateFor("Items")
				end
			end,
			["UpdateSkill"] = function(_)
				-- upvalues: (ref) v_u_4, (copy) p_u_103
				if v_u_4 == "Rods" then
					task.defer(function()
						-- upvalues: (ref) p_u_103
						p_u_103:UpdateFor("Rods")
					end)
				end
			end,
			["SkillUnlearned"] = function(_, _)
				-- upvalues: (ref) v_u_4, (copy) p_u_103
				if v_u_4 == "Rods" then
					task.defer(function()
						-- upvalues: (ref) p_u_103
						p_u_103:UpdateFor("Rods")
					end)
				end
			end,
			["UnlearnKeepUpdated"] = function(p113, p114, p115)
				-- upvalues: (ref) v_u_1
				if p113 and (p114 and p115 ~= nil) then
					if not v_u_1._unlearnKeepCache[p113] then
						v_u_1._unlearnKeepCache[p113] = {}
					end
					v_u_1._unlearnKeepCache[p113][p114] = p115
				end
			end,
			["SkillLearned"] = function(p116, _, p117)
				-- upvalues: (ref) v_u_1
				if p116 and (p117 and v_u_1._unlearnKeepCache[p116]) then
					v_u_1._unlearnKeepCache[p116][p117] = nil
				end
			end
		})
		v_u_5:FireServer("GetBaitInfo")
	end
	task.spawn(function()
		-- upvalues: (copy) p_u_103, (ref) v_u_4
		p_u_103:UpdateFor(v_u_4)
	end)
	for _, v_u_118 in pairs(v106:GetChildren()) do
		if v_u_118:IsA("ImageButton") then
			v_u_118.MouseButton1Click:Connect(function()
				-- upvalues: (ref) v_u_2, (ref) v_u_1, (ref) v_u_4, (copy) v_u_118, (ref) v_u_5, (copy) p_u_103
				if v_u_2 then
					return
				elseif not (v_u_1._skillPickerOpen or v_u_1._acceptFrameOpen) then
					v_u_2 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_4, (ref) v_u_118, (ref) v_u_5, (ref) p_u_103
						pcall(function()
							-- upvalues: (ref) v_u_4, (ref) v_u_118, (ref) v_u_5, (ref) p_u_103
							v_u_4 = v_u_118.Name
							if v_u_4 == "Bait" and v_u_5 then
								v_u_5:FireServer("GetBaitInfo")
							end
							return p_u_103:UpdateFor(v_u_118.Name)
						end)
					end)
					task.wait(0.5)
					v_u_2 = false
				end
			end)
		end
	end
	for v119, v120 in pairs(v104) do
		if v120.Fish then
			v_u_11[v119] = v120.Fish
		end
	end
end
function v_u_1.Active(p121)
	-- upvalues: (ref) v_u_2, (ref) v_u_4
	if v_u_2 then
		return
	else
		local v122 = game:GetService("Players").LocalPlayer
		repeat
			task.wait()
		until v122:FindFirstChild("PlayerGui")
		local v123 = v122.PlayerGui:WaitForChild("Inventory")
		local _ = v123.Canvas.Main.Buttons
		local v124 = p121.Shared.sprLib
		v_u_2 = true
		task.delay(0.5, function()
			-- upvalues: (ref) v_u_2
			v_u_2 = false
		end)
		v123.Enabled = not v123.Enabled
		if v123.Enabled then
			p121.Controllers.HUD:CloseAllUI(v123)
			v123.Canvas.Size = UDim2.new(0, 0, 1, 0)
			p121.Controllers.HUD:Effect(true)
			v124.target(v123.Canvas, 1, 4, {
				["Size"] = UDim2.new(1, 0, 1, 0)
			})
			p121:UpdateFor(v_u_4 or "Rods")
		else
			p121.Controllers.HUD:Effect(false)
		end
	end
end
return v_u_1