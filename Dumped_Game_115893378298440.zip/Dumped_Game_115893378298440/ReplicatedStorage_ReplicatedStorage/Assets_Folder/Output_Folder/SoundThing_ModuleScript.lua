-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return {
	["CreateAndPlay"] = function(p1, p2, p3, p4)
		local v5 = Instance.new("Sound", p1 or workspace)
		v5.SoundId = p2
		v5.Volume = p4 or 1
		v5:Play()
		game:GetService("Debris"):AddItem(v5, p3 or v5.TimeLength + 1)
	end,
	["PlayThis"] = function(p6)
		p6:Play()
	end,
	["StopThis"] = function(p7)
		p7:Stop()
	end
}