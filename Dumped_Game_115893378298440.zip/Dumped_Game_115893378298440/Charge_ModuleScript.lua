-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return {
	["Start"] = function(p1)
		local v_u_2 = game:GetService("RunService")
		game:GetService("ReplicatedStorage")
		local v3 = p1.Shared.Network
		local v4 = game.Players.LocalPlayer
		local v_u_5 = v4:WaitForChild("PlayerGui"):WaitForChild("Charge")
		local v_u_6 = v_u_5.Main.CanvasGroup.Bar
		local v_u_7 = nil
		local v_u_8 = nil
		local v_u_9 = nil
		local v_u_10 = v4.Character or v4.CharacterAdded:Wait()
		local v_u_11 = v_u_5.Main.Frame.Top.BaseLuck
		v3:BindEvents({
			["StartUI"] = function(p12)
				-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_7, (copy) v_u_5, (copy) v_u_2, (copy) v_u_10, (copy) v_u_11, (copy) v_u_6
				v_u_8 = p12.start
				v_u_9 = p12.speed
				_G.Holding = true
				if v_u_7 then
					v_u_7:Disconnect()
				end
				v_u_5.Enabled = true
				v_u_7 = v_u_2.RenderStepped:Connect(function()
					-- upvalues: (ref) v_u_10, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (ref) v_u_6
					task.spawn(function()
						-- upvalues: (ref) v_u_10
						v_u_10.Humanoid.WalkSpeed = 5
					end)
					local v13 = (os.clock() - v_u_8) * v_u_9 - 1.5707963267948966
					local v14 = math.sin(v13) * 0.5 + 1.5
					local v15 = v14 - 1
					v_u_11.Text = string.format("x%.1f", v14) .. " Luck"
					local v16 = v14 - 1 + 0.8
					local v17 = math.clamp(v16, 0.8, 1)
					game:GetService("TweenService"):Create(v_u_11, TweenInfo.new(0.12, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
						["Size"] = UDim2.fromScale(1, v17)
					}):Play()
					v_u_6.Size = UDim2.fromScale(1, v15)
				end)
			end,
			["StopUI"] = function()
				-- upvalues: (ref) v_u_7, (copy) v_u_5, (copy) v_u_6, (ref) v_u_8, (ref) v_u_9
				if v_u_7 then
					v_u_7:Disconnect()
					v_u_7 = nil
				end
				v_u_5.Enabled = false
				v_u_6.Size = UDim2.fromScale(1, 0)
				v_u_8 = nil
				v_u_9 = nil
			end
		})
	end
}