-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = false
local v_u_3 = nil
local v_u_4 = {}
function v1.UpdateThisIsland(p5, p6, p7, p8)
	-- upvalues: (ref) v_u_4
	for _, v9 in pairs(p8:GetChildren()) do
		if v9:IsA("Frame") then
			v9:Destroy()
		end
	end
	local v10 = p5.OwnedFish or (v_u_4 or {})
	local v11 = p8.Parent.TopBar.Discovered.AmountDiscovered
	local v12 = 0
	local v13 = 0
	for v14, v15 in pairs(p7) do
		for v16, v17 in pairs(v15.Fish or {}) do
			local v18 = v10[p6 .. "_" .. v16] == true
			local v19 = (v18 and game.ReplicatedStorage.Assets.Templates.Index.Owned or game.ReplicatedStorage.Assets.Templates.Index.NotOwned):Clone()
			v19.Parent = p8
			if v19:FindFirstChild("Display") then
				v19:FindFirstChild("Display").Image = v17.Display
			end
			if v19:FindFirstChild("FishName") then
				v19:FindFirstChild("FishName").Text = v16
			end
			if v19:FindFirstChild("Rarity") then
				v19:FindFirstChild("Rarity").Text = v14
			end
			v19.LayoutOrder = v15.RarityOrder or 1
			v12 = v12 + 1
			if v18 then
				v13 = v13 + 1
			end
		end
	end
	if v11 then
		v11.Text = tostring(v13) .. "/" .. tostring(v12)
	end
end
function v1.Update(p_u_20)
	-- upvalues: (ref) v_u_3, (ref) v_u_4
	local v_u_21 = game:GetService("Players").LocalPlayer.PlayerGui:WaitForChild("Index").Canvas.Main
	local v22 = p_u_20.Data.FishConfig
	local v23 = p_u_20.Data.FishingZones
	if v_u_3 then
		local v24, _, _, v25 = pcall(function()
			-- upvalues: (ref) v_u_3
			return v_u_3:InvokeServer("GetInventory")
		end)
		if v24 and v25 then
			v_u_4 = v25
			p_u_20.OwnedFish = v25
		end
	end
	for _, v26 in pairs(v_u_21.Islands:GetChildren()) do
		if v26:IsA("ImageButton") then
			v26:Destroy()
		end
	end
	for v_u_27, v_u_28 in pairs(v22) do
		local v29 = game.ReplicatedStorage.Assets.Templates.Index.Template:Clone()
		v29.Parent = v_u_21.Islands
		v29.Main.TextLabel.Text = v_u_27
		v29.LayoutOrder = v23[v_u_27].ReqLevel
		if v_u_27 == "Island 1" then
			p_u_20:UpdateThisIsland(v_u_27, v_u_28, v_u_21.Content.Container)
		end
		v29.Activated:Connect(function()
			-- upvalues: (copy) p_u_20, (copy) v_u_27, (copy) v_u_28, (copy) v_u_21
			p_u_20:UpdateThisIsland(v_u_27, v_u_28, v_u_21.Content.Container)
		end)
	end
end
function v1.Start(p30)
	-- upvalues: (ref) v_u_3
	v_u_3 = p30.Shared.Network
end
function v1.Active(p31)
	-- upvalues: (ref) v_u_2
	local v32 = game:GetService("Players").LocalPlayer
	repeat
		task.wait()
	until v32:FindFirstChild("PlayerGui")
	local v33 = v32.PlayerGui:WaitForChild("Index")
	game:GetService("TweenService")
	if v_u_2 then
		return
	else
		local v34 = p31.Shared.sprLib
		v_u_2 = true
		task.delay(0.5, function()
			-- upvalues: (ref) v_u_2
			v_u_2 = false
		end)
		v33.Enabled = not v33.Enabled
		v33.Canvas.Size = UDim2.new(0, 0, 1, 0)
		if v33.Enabled then
			p31:Update()
			p31.Controllers.HUD:CloseAllUI(v33)
			p31.Controllers.HUD:Effect(true)
			v34.target(v33.Canvas, 1, 4, {
				["Size"] = UDim2.new(1, 0, 1, 0)
			})
		else
			p31.Controllers.HUD:Effect(false)
		end
	end
end
return v1