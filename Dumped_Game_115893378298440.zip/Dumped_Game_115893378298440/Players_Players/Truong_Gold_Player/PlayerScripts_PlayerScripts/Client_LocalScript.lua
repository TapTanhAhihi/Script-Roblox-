-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = game:GetService("ReplicatedStorage")
require(v1.BFW.Client).new():Load(v1.Modules.Controllers, v1.Modules.Shared)