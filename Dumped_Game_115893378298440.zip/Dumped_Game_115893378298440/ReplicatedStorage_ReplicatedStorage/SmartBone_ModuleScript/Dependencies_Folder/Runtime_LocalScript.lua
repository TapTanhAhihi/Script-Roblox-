-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = script.Parent
local v_u_2 = nil
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = false
local v_u_7 = {}
local v_u_8 = nil
v_u_8 = v_u_1:BindToMessage("Setup", function(p9, p10, p11)
	-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_8
	v_u_2 = p9
	v_u_3 = p10
	v_u_4 = p11
	v_u_5 = require(p11)
	v_u_6 = true
	v_u_8:Disconnect()
end)
local v_u_12 = v_u_2
local v13 = v_u_3
local v14 = v_u_4
local v15 = v_u_5
repeat
	task.wait()
until v_u_6
local v16 = game:GetService("CollectionService")
local v17 = game:GetService("RunService")
local v_u_18 = v15.new()
local v19 = v14.Dependencies
local v_u_20 = require(v19.DebugUi)
local v21 = require(v19.Config)
local v_u_22 = require(v19.Utilities)
local v_u_23 = v17:IsStudio() or v21.ALLOW_LIVE_GAME_DEBUG
local v_u_24 = v14:WaitForChild("OverlayEvent")
local v_u_25 = false
local v_u_26 = {
	["Begin"] = function(...)
		-- upvalues: (copy) v_u_24
		v_u_24:Fire("Begin", ...)
	end,
	["End"] = function(...)
		-- upvalues: (copy) v_u_24
		v_u_24:Fire("End", ...)
	end,
	["Text"] = function(...)
		-- upvalues: (copy) v_u_24
		v_u_24:Fire("Text", ...)
	end
}
shared.FrameCounter = 0
local v_u_27
if v_u_23 then
	v_u_27 = require(v19.Iris)
	if not v_u_27.HasInit() then
		v_u_27 = v_u_27.Init()
	end
else
	v_u_27 = nil
end
v_u_1.Name = ("%* - %*"):format(v_u_12.Name, v_u_18.ID)
v_u_18:LoadObject(v_u_12)
for _, v28 in v13 do
	v_u_18:LoadRawCollider(v28[1], v28[2])
end
local v_u_29 = v_u_23 and {
	["DRAW_BONE"] = v_u_27.State(false),
	["DRAW_PHYSICAL_BONE"] = v_u_27.State(false),
	["DRAW_ROOT_PART"] = v_u_27.State(false),
	["DRAW_BOUNDING_BOX"] = v_u_27.State(false),
	["DRAW_AXIS_LIMITS"] = v_u_27.State(false),
	["DRAW_COLLIDERS"] = v_u_27.State(false),
	["DRAW_COLLIDER_INFLUENCE"] = v_u_27.State(false),
	["DRAW_COLLIDER_AWAKE"] = v_u_27.State(false),
	["DRAW_COLLIDER_BROADPHASE"] = v_u_27.State(false),
	["DRAW_FILL_COLLIDERS"] = v_u_27.State(false),
	["DRAW_CONTACTS"] = v_u_27.State(false),
	["DRAW_ROTATION_LIMITS"] = v_u_27.State(false),
	["DRAW_ACCELERATION_INFO"] = v_u_27.State(false)
} or nil
if v_u_23 then
	v_u_27:Connect(function()
		-- upvalues: (ref) v_u_12, (copy) v_u_20, (ref) v_u_27, (copy) v_u_18, (ref) v_u_29
		if v_u_12:GetAttribute("Debug") ~= nil then
			v_u_20(v_u_27, v_u_18, v_u_29)
		end
	end)
end
local v33 = v16:GetInstanceAddedSignal("SmartCollider"):Connect(function(p30)
	-- upvalues: (ref) v_u_12, (copy) v_u_22, (copy) v_u_18
	if p30:IsA("BasePart") then
		local v31 = p30:GetAttribute("ColliderKey")
		local v32 = v_u_12:GetAttribute("ColliderKey")
		if tostring(v31) == tostring(v32) then
			v_u_18:LoadRawCollider(v_u_22.GetCollider(p30), p30)
		end
	else
		return
	end
end)
table.insert(v_u_7, v33)
local v34 = v_u_1:BindToMessage("Destroy", function()
	-- upvalues: (ref) v_u_25
	v_u_25 = true
end)
table.insert(v_u_7, v34)
local v38 = v17.Heartbeat:ConnectParallel(function(p35)
	-- upvalues: (copy) v_u_18, (ref) v_u_25, (copy) v_u_7, (copy) v_u_1, (copy) v_u_23, (ref) v_u_12, (ref) v_u_29, (copy) v_u_26
	local v36 = shared
	v36.FrameCounter = v36.FrameCounter + 1
	if shared.FrameCounter > 131072 then
		shared.FrameCounter = 0
	end
	v_u_18:StepBoneTrees(p35)
	if v_u_18.ShouldDestroy or v_u_25 then
		v_u_18:Destroy()
		task.synchronize()
		for _, v37 in v_u_7 do
			v37:Disconnect()
		end
		v_u_1:Destroy()
	elseif v_u_23 and v_u_12:GetAttribute("Debug") ~= nil then
		task.synchronize()
		v_u_18:DrawDebug(v_u_29.DRAW_COLLIDERS:get(), v_u_29.DRAW_CONTACTS:get(), v_u_29.DRAW_PHYSICAL_BONE:get(), v_u_29.DRAW_BONE:get(), v_u_29.DRAW_AXIS_LIMITS:get(), v_u_29.DRAW_ROOT_PART:get(), v_u_29.DRAW_FILL_COLLIDERS:get(), v_u_29.DRAW_COLLIDER_INFLUENCE:get(), v_u_29.DRAW_COLLIDER_AWAKE:get(), v_u_29.DRAW_COLLIDER_BROADPHASE:get(), v_u_29.DRAW_BOUNDING_BOX:get(), v_u_29.DRAW_ROTATION_LIMITS:get(), v_u_29.DRAW_ACCELERATION_INFO:get())
		v_u_18:DrawOverlay(v_u_26)
	end
end)
table.insert(v_u_7, v38)