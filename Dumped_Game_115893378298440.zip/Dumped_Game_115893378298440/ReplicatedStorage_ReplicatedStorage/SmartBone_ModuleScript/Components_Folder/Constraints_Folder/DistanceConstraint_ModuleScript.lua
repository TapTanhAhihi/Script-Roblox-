-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return function(p1, p2, p3)
	debug.profilebegin("Distance Constraint")
	local v4 = p3.Bones[p1.ParentIndex]
	if v4 then
		local v5 = p1.FreeLength
		local v6 = p2 - v4.Position
		local v7 = v6.Magnitude == 0 and Vector3.new(0, 0, 0) or v6.Unit
		local v8 = v4.Position + v7 * v5
		debug.profileend()
		return v8
	end
	debug.profileend()
end