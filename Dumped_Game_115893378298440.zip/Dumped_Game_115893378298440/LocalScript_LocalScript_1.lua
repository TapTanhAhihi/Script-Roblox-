-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = game:GetService("TweenService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ContentProvider")
local v4 = game:GetService("UserInputService")
local v5 = v2.LocalPlayer:WaitForChild("PlayerGui")
repeat
	task.wait()
until workspace:FindFirstChild("Music")
if game:GetService("RunService"):IsStudio() then
	script:Destroy()
else
	for _, v6 in pairs(workspace.Music:GetChildren()) do
		if v6:IsA("Sound") then
			v6.Volume = 0
		end
	end
	_G.Holding = true
	_G.Loading = true
	local v_u_7 = script.Loading:Clone()
	v_u_7.Parent = v5
	local v_u_8 = v_u_7.LoadingFill.Fill
	local v9 = v_u_7.Display
	local v_u_10 = v_u_7.LoadingFill.TextLabel
	v9.TextTransparency = 1
	v_u_8.Size = UDim2.new(0, 0, 1, 0)
	v_u_10.Text = "Loading: 0%"
	v_u_1:Create(v9, TweenInfo.new(1, Enum.EasingStyle.Sine), {
		["TextTransparency"] = 0
	}):Play()
	task.wait(math.random(2, 5))
	local v11 = {}
	for _, v12 in ipairs(game:GetDescendants()) do
		if v12:IsA("ImageLabel") or (v12:IsA("ImageButton") or (v12:IsA("Sound") or (v12:IsA("MeshPart") or (v12:IsA("Decal") or (v12:IsA("Texture") or (v12:IsA("Animation") or (v12:IsA("ParticleEmitter") or (v12:IsA("Trail") or v12:IsA("Beam"))))))))) then
			table.insert(v11, v12)
		end
	end
	local v_u_13 = 0
	local v14 = #v11
	local v_u_15 = math.max(v14, 1)
	local v_u_16 = 0
	local v_u_17 = false
	local v_u_18 = nil
	local function v_u_20(p19)
		-- upvalues: (ref) v_u_18, (copy) v_u_1, (copy) v_u_8
		if v_u_18 then
			v_u_18:Cancel()
		end
		v_u_18 = v_u_1:Create(v_u_8, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
			["Size"] = UDim2.new(p19, 0, 1, 0)
		})
		v_u_18:Play()
	end
	v3:PreloadAsync(v11, function()
		-- upvalues: (ref) v_u_13, (copy) v_u_15, (ref) v_u_16, (copy) v_u_20, (copy) v_u_10, (ref) v_u_17
		v_u_13 = v_u_13 + 1
		local v21 = v_u_13 / v_u_15
		local v22 = math.clamp(v21, 0, 1)
		local v23 = v22 * 100
		v_u_16 = math.floor(v23)
		v_u_20(v22)
		v_u_10.Text = "Loading: " .. v_u_16 .. "%"
		if v_u_16 >= 50 then
			v_u_17 = true
		end
	end)
	v_u_20(1)
	v_u_10.Text = "Loading: 100%"
	v_u_17 = true
	local v_u_24 = false
	local function v_u_26()
		-- upvalues: (ref) v_u_24, (ref) v_u_17, (copy) v_u_7
		if not v_u_24 and v_u_17 then
			v_u_24 = true
			_G.Loading = nil
			task.wait(0.5)
			_G.Holding = nil
			v_u_7:Destroy()
			script:Destroy()
			for _, v25 in pairs(workspace.Music:GetChildren()) do
				if v25:IsA("Sound") then
					v25.Volume = 0.2
				end
			end
		end
	end
	v_u_26()
	v4.InputBegan:Connect(function(p27, p28)
		-- upvalues: (copy) v_u_26
		if not p28 then
			if p27.UserInputType == Enum.UserInputType.MouseButton1 or p27.UserInputType == Enum.UserInputType.Touch then
				v_u_26()
			end
		end
	end)
end