-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return {
	["Start"] = function(p1)
		local v_u_2 = p1.Shared.Network
		local v_u_3 = false
		local v4 = game:GetService("UserInputService")
		v_u_2:BindEvents({
			["StartMiniGame"] = function(_)
				-- upvalues: (ref) v_u_3
				v_u_3 = true
			end,
			["StopMinigame"] = function()
				-- upvalues: (ref) v_u_3
				v_u_3 = false
			end
		})
		v4.InputBegan:Connect(function(p5, p6)
			-- upvalues: (ref) v_u_3, (copy) v_u_2
			if not p6 then
				if v_u_3 and (p5.UserInputType == Enum.UserInputType.MouseButton1 or p5.UserInputType == Enum.UserInputType.Touch) then
					v_u_2:FireServer("ApplyDamage", 0)
				end
			end
		end)
	end
}