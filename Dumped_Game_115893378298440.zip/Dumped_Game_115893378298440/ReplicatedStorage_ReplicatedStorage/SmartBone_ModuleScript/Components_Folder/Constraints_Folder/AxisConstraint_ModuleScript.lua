-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return function(p1, p2, p3, p4)
	debug.profilebegin("Axis Constraint")
	local v5 = p4:Inverse() * p2
	local v6 = v5.X
	local v7 = v5.Y
	local v8 = v5.Z
	local v9 = p1.XAxisLimits
	local v10 = p1.YAxisLimits
	local v11 = p1.ZAxisLimits
	local v12 = p1.AxisLocked[1] and 0 or 1
	local v13 = p1.AxisLocked[2] and 0 or 1
	local v14 = p1.AxisLocked[3] and 0 or 1
	local v15 = v9.Min + p1.Radius
	local v16
	if v15 <= v9.Max - p1.Radius then
		v16 = v9.Max - p1.Radius or v15
	else
		v16 = v15
	end
	local v17 = v10.Min + p1.Radius
	local v18
	if v17 <= v10.Max - p1.Radius then
		v18 = v10.Max - p1.Radius or v17
	else
		v18 = v17
	end
	local v19 = v11.Min + p1.Radius
	local v20
	if v19 <= v11.Max - p1.Radius then
		v20 = v11.Max - p1.Radius or v19
	else
		v20 = v19
	end
	if v6 < v15 and v15 then
		v6 = v15
	elseif v16 < v6 then
		v6 = v16 or v6
	end
	if v7 < v17 and v17 then
		v7 = v17
	elseif v18 < v7 then
		v7 = v18 or v7
	end
	if v8 < v19 and v19 then
		v8 = v19
	elseif v20 < v8 then
		v8 = v20 or v8
	end
	local v21 = v6 * v12
	local v22 = v7 * v13
	local v23 = v8 * v14
	local v24 = p4 * Vector3.new(v21, v22, v23)
	local v25 = p4.RightVector
	local v26 = p4.UpVector
	local v27 = p4.LookVector
	local v28 = v24 - p3
	local v29 = v28.Magnitude == 0 and Vector3.new(0, 0, 0) or v28.Unit
	if v21 ~= v5.X then
		if v25:Dot(v29) < 0 then
			v25 = -v25 or v25
		end
		p1:ClipVelocity(v24, v25)
	end
	if v22 ~= v5.Y then
		if v26:Dot(v29) < 0 then
			v26 = -v26 or v26
		end
		p1:ClipVelocity(v24, v26)
	end
	if v23 ~= v5.Z then
		if v27:Dot(v29) > 0 then
			v27 = -v27 or v27
		end
		p1:ClipVelocity(v24, v27)
	end
	debug.profileend()
	return v24
end