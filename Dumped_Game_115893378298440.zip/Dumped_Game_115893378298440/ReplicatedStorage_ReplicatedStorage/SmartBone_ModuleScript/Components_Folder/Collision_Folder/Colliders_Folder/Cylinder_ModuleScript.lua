-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local function v_u_39(p1, p2, p3)
	local v4 = p2.Y
	local v5 = p2.Z
	local v6 = math.min(v4, v5) * 0.5
	local v7 = p2.X * 0.5
	local v8 = p1.Position
	local v9 = p1.RightVector
	local v10 = (p3 - v8):Dot(v9)
	local v11 = -v7
	local v12 = math.clamp(v10, v11, v7)
	local v13 = v8 + v9 * v12
	local v14 = p1.Position + -p1.RightVector * v7
	local v15 = p1.Position + p1.RightVector * v7
	local v16 = -p1.RightVector
	local v17 = p1.RightVector
	local v18 = p3 - (p3 - v14):Dot(v16) * v16
	local v19 = p3 - (p3 - v15):Dot(v17) * v17
	local v20 = v18 - v14
	local v21 = v20.Magnitude == 0 and Vector3.new(0, 0, 0) or v20.Unit
	local v22 = (v18 - v14).Magnitude
	local v23 = v14 + v21 * math.min(v22, v6)
	local v24 = v19 - v15
	local v25 = v24.Magnitude == 0 and Vector3.new(0, 0, 0) or v24.Unit
	local v26 = (v19 - v15).Magnitude
	local v27 = v15 + v25 * math.min(v26, v6)
	local v28 = (v13 - p3).Magnitude
	local v29 = p3 - v13
	local v30 = v29.Magnitude == 0 and Vector3.new(0, 0, 0) or v29.Unit
	local v31 = v28 <= v6
	local v32 = v13 + v30 * v6
	local v33 = (v27 - p3).Magnitude
	local v34 = (v23 - p3).Magnitude
	local v35 = (v32 - p3).Magnitude
	local v36 = math.min(v33, v34, v35)
	if v12 == v7 or v36 == v33 then
		local v37 = p3 - v27
		return (v37.Magnitude == 0 and Vector3.new(0, 0, 0) or v37.Unit):Dot(v17) < 0, v27, v17
	end
	if v12 ~= -v7 and v36 ~= v34 then
		return v31, v32, v30
	end
	local v38 = p3 - v23
	return (v38.Magnitude == 0 and Vector3.new(0, 0, 0) or v38.Unit):Dot(v16) < 0, v23, v16
end
return function(p40, p41, p42, p43)
	-- upvalues: (copy) v_u_39
	debug.profilebegin("Cylinder Testing")
	local v44, v45, v46 = v_u_39(p40, p41, p42)
	if v44 then
		return v44, v45, v46
	end
	local v47 = (v45 - p42).Magnitude < p43
	debug.profileend()
	return v47, v45, v46
end