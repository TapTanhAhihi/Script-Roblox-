-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
local v5 = script:WaitForChild("Components")
local v6 = script:WaitForChild("Dependencies")
local v_u_7 = require(v6:WaitForChild("CeiveImOverlay"))
local v_u_8 = require(v6:WaitForChild("Config"))
local v_u_9 = require(v6:WaitForChild("Frustum"))
local v_u_10 = require(v6:WaitForChild("Utilities"))
local v_u_11 = nil
local v_u_12 = require(v5:WaitForChild("Bone"))
local v_u_13 = require(v5:WaitForChild("BoneTree"))
local v_u_14 = require(v5:WaitForChild("Collision"):WaitForChild("ColliderObject"))
local v_u_15 = v6:WaitForChild("Runtime")
local v_u_16 = v_u_10.SB_INDENT_LOG
local v_u_17 = v_u_10.SB_UNINDENT_LOG
local v_u_18 = v_u_10.SB_VERBOSE_LOG
local v_u_19 = v_u_10.SB_VERBOSE_WARN
local v_u_20 = {}
v_u_20.__index = v_u_20
function v_u_20.new()
	-- upvalues: (copy) v_u_2, (copy) v_u_20
	local v21 = {
		["ID"] = v_u_2:GenerateGUID(false),
		["BoneTrees"] = {},
		["ColliderObjects"] = {},
		["ShouldDestroy"] = false
	}
	local v22 = v_u_20
	return setmetatable(v21, v22)
end
function v_u_20.m_AppendBone(_, p23, p24, p25, p26)
	-- upvalues: (copy) v_u_10, (copy) v_u_12, (copy) v_u_18
	local v27 = v_u_10.GatherBoneSettings(p24)
	local v28 = v_u_12.new(p24, p23.Root, p23.RootPart)
	for v29, v31 in v27 do
		if v31 == "\194\172" or not v31 then
			local v31 = nil
		end
		v28[v29] = v31
	end
	local v32 = p23.Bones[p25]
	if p25 > 0 then
		local v33 = (v32.Position - v28.Position).Magnitude
		v28.FreeLength = v33
		v28.Weight = v33 * 0.7
		v28.HeirarchyLength = p26
		v32.HasChild = true
	end
	if p26 <= p23.Settings.AnchorDepth then
		v_u_18("Anchoring bone")
		v28.Anchored = true
	end
	v28.ParentIndex = p25
	local v34 = p23.Bones
	table.insert(v34, v28)
end
function v_u_20.m_CreateBoneTree(p_u_35, p36, p37)
	-- upvalues: (copy) v_u_10, (copy) v_u_13, (copy) v_u_18, (copy) v_u_16, (copy) v_u_17
	local v38 = v_u_10.GatherObjectSettings(p36)
	local v_u_39 = v_u_13.new(p37, p36)
	v_u_39.Settings = v38
	v_u_18((("Creating bone tree %*; %*"):format(p36.Name, p37.Name)))
	v_u_16()
	local function v_u_51(p40, p41, p42)
		-- upvalues: (ref) v_u_18, (ref) v_u_16, (copy) p_u_35, (copy) v_u_39, (copy) v_u_51, (ref) v_u_17
		v_u_18((("Adding bone: %*; %*; %*"):format(p40.Name, p41, p42)))
		v_u_16()
		local v43 = p40:GetChildren()
		for _, v44 in v43 do
			if v44:IsA("Bone") then
				p_u_35:m_AppendBone(v_u_39, v44, p41, p42)
				v_u_51(v44, #v_u_39.Bones, p42 + 1)
			end
		end
		if #v43 == 0 then
			v_u_18("Adding tail bone")
			local v45 = p40.Parent
			local v46 = v45:IsA("Bone") and v45.WorldPosition or v45.Position
			local v47 = p40.WorldCFrame + p40.WorldCFrame.UpVector.Unit * (p40.WorldPosition - v46).Magnitude
			local v48 = Instance.new("Bone")
			v48.Parent = p40
			v48.Name = p40.Name .. "_Tail"
			v48.WorldCFrame = v47
			for v49, v50 in p40:GetAttributes() do
				v48:SetAttribute(v49, v50)
			end
			p_u_35:m_AppendBone(v_u_39, v48, #v_u_39.Bones, p42)
		end
		v_u_17()
	end
	p_u_35:m_AppendBone(v_u_39, p37, 0, 0)
	v_u_51(p37, 1, 1)
	local v52 = p_u_35.BoneTrees
	table.insert(v52, v_u_39)
	v_u_17()
end
function v_u_20.m_UpdateViewFrustum(p53)
	-- upvalues: (copy) v_u_9, (copy) v_u_8
	debug.profilebegin("SmartBone2::m_UpdateViewFrustum")
	local v54, v55, v56, v57, v58, v59, v60, v61, v62 = v_u_9.GetCFrames(workspace.CurrentCamera, v_u_8.FAR_PLANE)
	for _, v63 in p53.BoneTrees do
		debug.profilebegin("BoneTree::m_UpdateViewFrustum")
		local v64 = {
			["CFrame"] = v63.BoundingBoxCFrame,
			["Size"] = v63.BoundingBoxSize
		}
		v63.InView = v_u_9.ObjectInFrustum(v64, v54, v55, v56, v57, v58, v59, v60, v61, v62)
		debug.profileend()
	end
	debug.profileend()
end
function v_u_20.m_CleanColliders(p65)
	-- upvalues: (copy) v_u_19, (copy) v_u_16, (copy) v_u_17
	debug.profilebegin("Clean Colliders")
	if #p65.ColliderObjects ~= 0 then
		for v66, v67 in p65.ColliderObjects do
			if #v67.Colliders == 0 or v67.Destroyed == true then
				v_u_19("Deleting Collider Object")
				v_u_16()
				v67:Destroy()
				v_u_17()
				table.remove(p65.ColliderObjects, v66)
			end
		end
	end
	debug.profileend()
end
function v_u_20.m_ConstrainBoneTree(p68, p69, p70)
	debug.profilebegin("SmartBone2::m_ConstrainBoneTree")
	p69:Constrain(p68.ColliderObjects, p70)
	debug.profileend()
end
function v_u_20.m_UpdateBoneTree(p71, p72, p73, p74)
	-- upvalues: (copy) v_u_18
	debug.profilebegin("SmartBone2::m_UpdateBoneTree")
	if p72.Destroyed then
		p72:Destroy()
		table.remove(p71.BoneTrees, p73)
	else
		p72:PreUpdate(p74)
		if p72.InView then
			local v75 = p72.UpdateRate
			if math.floor(v75) ~= 0 then
				debug.profilebegin("Step Colliders")
				for _, v76 in p71.ColliderObjects do
					v76:Step()
				end
				debug.profileend()
				local v77 = 1 / p72.UpdateRate
				p72.AccumulatedDelta = p72.AccumulatedDelta + p74
				local v78 = false
				while v77 < p72.AccumulatedDelta do
					p72.AccumulatedDelta = p72.AccumulatedDelta - v77
					p72:StepPhysics(v77)
					p71:m_ConstrainBoneTree(p72, p74)
					p72:SolveTransform(v77)
					v78 = true
				end
				debug.profileend()
				if v78 then
					task.synchronize()
					p72:ApplyTransform()
				end
				return
			end
		end
		local v79 = p72.FirstSkipUpdate
		p72:SkipUpdate()
		if not v79 then
			debug.profileend()
			task.synchronize()
			p72:ApplyTransform()
			local v80 = v_u_18
			local v81 = p72.InView
			local v82 = p72.UpdateRate
			v80((("Skipping BoneTree, InView: %*, Update Rate == 0: %*"):format(v81, math.floor(v82) == 0)))
		end
	end
end
function v_u_20.m_CheckDestroy(p83)
	p83.ShouldDestroy = false
	if #p83.BoneTrees ~= 0 then
		return false
	end
	p83.ShouldDestroy = true
	return true
end
function v_u_20.LoadObject(p84, p85)
	local v86 = p85:GetAttribute("Roots")
	if v86 then
		local v87 = v86:split(",")
		local v88 = {}
		for _, v89 in p85:GetDescendants() do
			if v89:IsA("Bone") then
				if v88[v89.Name] then
					warn((("[SmartBone2::LoadObject] Duplicate bones of name: %* in RootPart: %*"):format(v89.Name, p85.Name)))
				else
					v88[v89.Name] = v89
				end
			end
		end
		for _, v90 in v87 do
			local v91 = v88[v90]
			if v91 then
				p84:m_CreateBoneTree(p85, v91)
			else
				warn((("[SmartBone2::LoadObject] Couldn\'t find Root Bone of name: %* in RootPart: %*"):format(v90, p85.Name)))
			end
		end
	else
		warn((("[SmartBone2::LoadObject] Cannot load an object with no roots defined %*"):format(p85.Name)))
	end
end
function v_u_20.LoadColliderModule(p92, p93, p94)
	-- upvalues: (copy) v_u_2, (copy) v_u_14
	assert(p93, "[SmartBone2::LoadColliderModule] No collider module passed in")
	local v95 = v_u_2:JSONDecode((require(p93)))
	local v96 = v_u_14.new(v95, p94)
	local v97 = p92.ColliderObjects
	table.insert(v97, v96)
end
function v_u_20.LoadRawCollider(p98, p99, p100)
	-- upvalues: (copy) v_u_14
	local v101 = v_u_14.new(p99, p100)
	local v102 = p98.ColliderObjects
	table.insert(v102, v101)
end
function v_u_20.SkipUpdate(p103)
	debug.profilebegin("SmartBone2::SkipUpdate")
	for _, v104 in p103.BoneTrees do
		v104:SkipUpdate()
	end
	debug.profileend()
end
function v_u_20.StepBoneTrees(p105, p106)
	-- upvalues: (copy) v_u_19
	if p105:m_CheckDestroy() then
		return
	elseif p106 <= 0 then
		v_u_19("DeltaTime is zero or sub zero, not updating.")
	else
		p105:m_CleanColliders()
		p105:m_UpdateViewFrustum()
		for v107, v108 in p105.BoneTrees do
			p105:m_UpdateBoneTree(v108, v107, p106)
		end
	end
end
function v_u_20.DrawDebug(p109, p110, p111, p112, p113, p114, p115, p116, p117, p118, p119, p120, p121, p122)
	for _, v123 in p109.BoneTrees do
		v123:DrawDebug(p111, p112, p113, p114, p115, p120, p121, p122)
	end
	if p110 then
		for _, v124 in p109.ColliderObjects do
			v124:DrawDebug(p116, p117, p118, p119)
		end
	end
end
function v_u_20.DrawOverlay(p125, p126)
	-- upvalues: (copy) v_u_8
	if not v_u_8.DEBUG_OVERLAY_ENABLED then
		return
	end
	local v127 = Color3.new(1, 0.431373, 0.713725)
	local v128 = Color3.new(1, 1, 1)
	local v129 = Color3.new(0.486275, 0.431373, 1)
	local v130 = Color3.new(1, 1, 1)
	p126.Begin(("SmartBone Instance ID: %*"):format(p125.ID), v127, v128)
	p126.Text((("Frame Counter: %*"):format(shared.FrameCounter)))
	if v_u_8.DEBUG_OVERLAY_TREE then
		for v131, v132 in p125.BoneTrees do
			if v_u_8.DEBUG_OVERLAY_MAX_TREES > 0 and v_u_8.DEBUG_OVERLAY_TREE_OFFSET + v_u_8.DEBUG_OVERLAY_MAX_TREES <= v131 then
				break
			end
			if v131 >= v_u_8.DEBUG_OVERLAY_TREE_OFFSET then
				p126.Begin(("Bone Tree %*"):format(v131), v129, v130)
				v132:DrawOverlay(p126)
				p126.End()
			end
		end
	end
	p126.End()
end
function v_u_20.Destroy(p133)
	-- upvalues: (copy) v_u_18
	v_u_18("Deleting SmartBone Object")
	for _, v134 in p133.BoneTrees do
		v134:Destroy()
	end
	for _, v135 in p133.ColliderObjects do
		v135:Destroy()
	end
	setmetatable(p133, nil)
end
function v_u_20.Start()
	-- upvalues: (copy) v_u_4, (copy) v_u_20, (copy) v_u_8, (copy) v_u_3, (ref) v_u_11, (copy) v_u_1, (copy) v_u_18, (copy) v_u_16, (copy) v_u_10, (copy) v_u_15, (copy) v_u_17, (copy) v_u_7
	if v_u_4:IsClient() then
		if not v_u_20.Running then
			if v_u_8.STARTUP_PRINT_ENABLED or v_u_8.LOG_VERBOSE then
				print((("SmartBone2 v%* Starting"):format(v_u_8.VERSION)))
			end
			v_u_20.Running = true
			local v136 = v_u_3.LocalPlayer:WaitForChild("PlayerScripts")
			local v_u_137 = Instance.new("Folder")
			v_u_137.Name = "SmartBone-Actors"
			v_u_137.Parent = v136
			local v138 = Instance.new("BindableEvent")
			v138.Name = "OverlayEvent"
			v138.Parent = script
			v138.Event:Connect(function(p139, ...)
				-- upvalues: (ref) v_u_8, (ref) v_u_11
				if v_u_8.DEBUG_OVERLAY_ENABLED then
					if p139 == "Text" then
						v_u_11:Text(...)
						return
					elseif p139 == "Begin" then
						v_u_11:Begin(...)
					elseif p139 == "End" then
						v_u_11:End()
					end
				else
					return
				end
			end)
			local function v_u_145()
				-- upvalues: (ref) v_u_1, (ref) v_u_18, (ref) v_u_8
				local v140 = {
					["Key"] = {},
					["Raw"] = {}
				}
				for _, v141 in v_u_1:GetTagged("SmartCollider") do
					if v141:IsA("BasePart") then
						local v142 = v141:GetAttribute("ColliderKey")
						if v142 then
							v142 = tostring(v142)
							if not v140.Key[v142] then
								v140.Key[v142] = {}
							end
							local v143 = v140.Key[v142]
							table.insert(v143, v141)
						end
						v_u_18((("Adding collider: %*, Collider Key: %*"):format(v141.Name, v142)))
						local v144 = v140.Raw
						table.insert(v144, v141)
						if v_u_8.YIELD_ON_COLLIDER_GATHER then
							task.wait()
						end
					end
				end
				return v140
			end
			local function v155(p146)
				-- upvalues: (ref) v_u_18, (ref) v_u_16, (copy) v_u_145, (ref) v_u_10, (ref) v_u_15, (copy) v_u_137, (ref) v_u_17
				if p146:IsA("BasePart") then
					v_u_18((("Setup Object: %*"):format(p146.Name)))
					v_u_16()
					local v147 = v_u_145()
					local v148 = p146:GetAttribute("ColliderKey")
					local v149
					if v148 then
						v149 = v147.Key[tostring(v148)] or {}
					else
						v149 = v147.Raw or {}
					end
					local v150 = {}
					for _, v151 in v149 do
						local v152 = { v_u_10.GetCollider(v151), v151 }
						table.insert(v150, v152)
					end
					local v153 = Instance.new("Actor")
					local v154 = v_u_15:Clone()
					v154.Parent = v153
					v154.Enabled = true
					v153.Parent = v_u_137
					task.wait()
					v153:SendMessage("Setup", p146, v150, script)
					v_u_18("Runtime Started")
					v_u_17()
				end
			end
			v_u_1:GetInstanceAddedSignal("SmartBone"):Connect(v155)
			for _, v156 in v_u_1:GetTagged("SmartBone") do
				v155(v156)
			end
			if v_u_8.DEBUG_OVERLAY_ENABLED then
				v_u_11 = v_u_7.new()
				local v157 = v_u_3.LocalPlayer.PlayerGui
				local v158 = Instance.new("ScreenGui")
				v158.Name = "SmartBoneDebugOverlay"
				v158.IgnoreGuiInset = true
				v158.ResetOnSpawn = false
				v158.Parent = v157
				v_u_11.BackFrame.Parent = v158
				v_u_4.RenderStepped:Connect(function()
					-- upvalues: (ref) v_u_11
					v_u_11:Render()
				end)
			end
			return {
				["Stop"] = function()
					-- upvalues: (ref) v_u_8, (copy) v_u_137
					if v_u_8.RESET_BONE_ON_DESTROY then
						for _, v159 in v_u_137:GetChildren() do
							v159:SendMessage("Destroy")
						end
					else
						v_u_137:Destroy()
					end
				end
			}
		end
		warn("Cannot call Smartbone.Start() multiple times")
	else
		warn("Smartbone.Start() can only be called in client context.")
	end
end
return v_u_20