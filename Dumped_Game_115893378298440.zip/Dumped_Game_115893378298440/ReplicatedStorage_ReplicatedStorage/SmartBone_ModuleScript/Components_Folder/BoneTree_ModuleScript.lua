-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = Random.new(1029410295159813)
local v_u_2 = game:GetService("Lighting")
local v3 = script.Parent.Parent:WaitForChild("Dependencies")
require(script.Parent:WaitForChild("Bone"))
local v_u_4 = require(v3:WaitForChild("Config"))
local v_u_5 = require(v3:WaitForChild("DefaultObjectSettings"))
local v_u_6 = require(v3:WaitForChild("Gizmo"))
local v7 = require(v3:WaitForChild("Utilities"))
if game:GetService("RunService"):IsStudio() or v_u_4.ALLOW_LIVE_GAME_DEBUG then
	v_u_6.Init()
end
local v_u_8 = v7.SB_VERBOSE_LOG
local v_u_9 = {}
v_u_9.__index = v_u_9
function v_u_9.new(p10, p_u_11)
	-- upvalues: (copy) v_u_1, (copy) v_u_9, (copy) v_u_5
	local v12 = {
		["WindOffset"] = v_u_1:NextNumber(0, 1000000),
		["Root"] = p10:IsA("Bone") and p10 and p10 or nil,
		["RootPart"] = p_u_11,
		["RootPartSize"] = p_u_11.Size,
		["Bones"] = {},
		["Settings"] = {},
		["UpdateRate"] = 0,
		["InView"] = true,
		["AccumulatedDelta"] = 0,
		["BoundingBoxCFrame"] = p_u_11.CFrame,
		["BoundingBoxSize"] = p_u_11.Size,
		["Destroyed"] = false,
		["FirstSkipUpdate"] = false,
		["Force"] = Vector3.new(0, 0, 0),
		["ObjectMove"] = Vector3.new(0, 0, 0),
		["ObjectVelocity"] = Vector3.new(0, 0, 0),
		["ObjectAcceleration"] = Vector3.new(0, 0, 0),
		["ObjectPreviousPosition"] = p_u_11.Position
	}
	local v13 = v_u_9
	local v_u_14 = setmetatable(v12, v13)
	v_u_14.DestroyConnection = p_u_11.AncestryChanged:Connect(function()
		-- upvalues: (copy) p_u_11, (copy) v_u_14
		if not p_u_11:IsDescendantOf(game) then
			v_u_14.Destroyed = true
		end
	end)
	v_u_14.AttributeConnection = p_u_11.AttributeChanged:Connect(function(p15)
		-- upvalues: (copy) v_u_14, (copy) p_u_11, (ref) v_u_5
		v_u_14.Settings[p15] = p_u_11:GetAttribute(p15) or v_u_5[p15]
	end)
	return v_u_14
end
function v_u_9.UpdateBoundingBox(p16)
	debug.profilebegin("BoneTree::UpdateBoundingBox")
	if p16.InView then
		debug.profilebegin("Max Min Bones")
		local v17 = Vector3.new(inf, inf, inf)
		local v18 = Vector3.new(-inf, -inf, -inf)
		for _, v19 in p16.Bones do
			debug.profilebegin("Max Min Bone")
			local v20 = v19.Position
			v17 = v17:Min(v20)
			v18 = v18:Max(v20)
			debug.profileend()
		end
		debug.profileend()
		local v21 = (v17 + v18) / 2
		p16.BoundingBoxCFrame = CFrame.new(v21)
		p16.BoundingBoxSize = p16.RootPartSize:Max(v18 - v17)
		debug.profileend()
	else
		p16.BoundingBoxCFrame = p16.RootPart.CFrame
		p16.BoundingBoxSize = p16.RootPart.Size
		debug.profileend()
	end
end
function v_u_9.UpdateThrottling(p22, p23)
	debug.profilebegin("BoneTree::UpdateThrottling")
	local v24 = p22.Settings
	local v25 = (p23 - workspace.CurrentCamera.CFrame.Position).Magnitude
	if v24.ActivationDistance < v25 then
		p22.UpdateRate = 0
		debug.profileend()
	else
		local v26 = v24.ThrottleDistance
		local v27 = v24.ActivationDistance
		local v28 = (v25 - v26) / (v27 - v26) * 1 + 0
		local v29 = 1 - ((v28 < 1 and v28 and v28 or 1) > 0 and (v28 < 1 and v28 and v28 or 1) or 0)
		p22.UpdateRate = v24.UpdateRate * v29
		debug.profileend()
	end
end
function v_u_9.PreUpdate(p30, p31)
	debug.profilebegin("BoneTree::PreUpdate")
	local v32 = p30.RootPart.CFrame.Position
	local v33 = p30.ObjectVelocity
	p30.ObjectMove = v32 - p30.ObjectPreviousPosition
	local v34 = p30.ObjectVelocity
	local v35 = p30.ObjectMove / p31 / 4
	local v36 = p31 * 10
	p30.ObjectVelocity = v34:Lerp(v35, (math.min(v36, 1)))
	p30.ObjectAcceleration = (v33 - p30.ObjectVelocity) * p31
	p30.ObjectPreviousPosition = v32
	p30.RootPartSize = p30.RootPart.Size
	p30:UpdateThrottling(v32)
	p30:UpdateBoundingBox()
	for _, v37 in p30.Bones do
		v37:PreUpdate(p30)
	end
	debug.profileend()
end
function v_u_9.StepPhysics(p38, p39)
	-- upvalues: (copy) v_u_2, (copy) v_u_5
	debug.profilebegin("BoneTree::StepPhysics")
	local v40 = p38.Settings
	local v41 = (v40.Gravity + v40.Force) * p39
	if v40.MatchWorkspaceWind == true then
		local v42 = workspace.GlobalWind
		v40.WindDirection = v42.Magnitude == 0 and Vector3.new(0, 0, 0) or v42.Unit
		v40.WindSpeed = v42.Magnitude
	else
		local v43 = v_u_2:GetAttribute("WindDirection") or v_u_5.WindDirection
		local v44 = v_u_2:GetAttribute("WindSpeed") or v_u_5.WindSpeed
		v40.WindDirection = v43.Magnitude == 0 and Vector3.new(0, 0, 0) or v43.Unit
		v40.WindSpeed = v44
	end
	v40.WindStrength = v_u_2:GetAttribute("WindStrength") or v_u_5.WindStrength
	for _, v45 in p38.Bones do
		v45:StepPhysics(p38, v41, p39)
	end
	debug.profileend()
end
function v_u_9.Constrain(p46, p47, p48)
	debug.profilebegin("BoneTree::Constrain")
	for _, v49 in p46.Bones do
		v49:Constrain(p46, p47, p48)
	end
	debug.profileend()
end
function v_u_9.SkipUpdate(p50)
	debug.profilebegin("BoneTree::SkipUpdate")
	for _, v51 in p50.Bones do
		v51:SkipUpdate()
	end
	p50.FirstSkipUpdate = true
	debug.profileend()
end
function v_u_9.SolveTransform(p52, p53)
	debug.profilebegin("BoneTree::SolveTransform")
	for _, v54 in p52.Bones do
		v54:SolveTransform(p52, p53)
	end
	p52.FirstSkipUpdate = false
	debug.profileend()
end
function v_u_9.ApplyTransform(p55)
	debug.profilebegin("BoneTree::ApplyTransform")
	for _, v56 in p55.Bones do
		v56:ApplyTransform(p55)
	end
	debug.profileend()
end
function v_u_9.DrawDebug(p57, p58, p59, p60, p61, p62, p63, p64, p65)
	-- upvalues: (copy) v_u_6
	debug.profilebegin("BoneTree::DrawDebug")
	local v66 = Color3.fromRGB(248, 168, 20)
	local v67 = Color3.fromRGB(76, 208, 223)
	local v68 = Color3.fromRGB(255, 89, 89)
	local v69 = Color3.new(1, 0, 0)
	local v70 = Color3.new(0, 1, 0)
	local v71 = Color3.new(0, 0, 1)
	if p65 then
		local v72 = p57.RootPart.Position
		local v73 = p57.RootPart.Size.Y / 2 + 1
		local v74 = v72 + Vector3.new(0, v73, 0)
		v_u_6.SetStyle(v69, 0, true)
		v_u_6.Arrow:Draw(v74, v74 + p57.ObjectMove, 0.025, 0.1, 6)
		v_u_6.SetStyle(v70, 0, true)
		v_u_6.Arrow:Draw(v74, v74 + p57.ObjectVelocity, 0.025, 0.1, 6)
		v_u_6.SetStyle(v71, 0, true)
		v_u_6.Arrow:Draw(v74, v74 + p57.ObjectAcceleration, 0.025, 0.1, 6)
	end
	v_u_6.PushProperty("AlwaysOnTop", false)
	if p63 then
		v_u_6.PushProperty("Color3", v67)
		v_u_6.Box:Draw(p57.BoundingBoxCFrame, p57.BoundingBoxSize, true)
	end
	if p62 then
		v_u_6.PushProperty("Color3", v67)
		v_u_6.Box:Draw(p57.RootPart.CFrame, p57.RootPart.Size, true)
		v_u_6.SetStyle(v68, 0.75, false)
		v_u_6.VolumeBox:Draw(p57.RootPart.CFrame, p57.RootPart.Size)
		v_u_6.PushProperty("Transparency", 0)
	end
	for v75, v76 in p57.Bones do
		local v77 = v76.Bone.TransformedWorldCFrame.Position
		local v78 = p57.Bones[v76.ParentIndex]
		v76:DrawDebug(p57, p58, p59, p60, p61, p64)
		if p59 and v75 ~= 1 then
			v_u_6.PushProperty("Color3", v66)
			v_u_6.Ray:Draw(v78.Bone.TransformedWorldCFrame.Position, v77)
		end
	end
	debug.profileend()
end
function v_u_9.DrawOverlay(p79, p80)
	-- upvalues: (copy) v_u_4
	if v_u_4.DEBUG_OVERLAY_TREE_INFO or v_u_4.DEBUG_OVERLAY_TREE_OBJECTS then
		p80.Text((("Root Part: %*"):format(p79.RootPart.Name)))
		p80.Text((("Root Bone: %*"):format(p79.Root.Name)))
		p80.Text((("Root Part Size: %*"):format((string.format("%.3f, %.3f, %.3f", p79.RootPart.Size.X, p79.RootPart.Size.Y, p79.RootPart.Size.Z)))))
	end
	if v_u_4.DEBUG_OVERLAY_TREE_INFO or v_u_4.DEBUG_OVERLAY_TREE_NUMERICS then
		p80.Text((("Update Rate: %*"):format((string.format("%.3f", p79.UpdateRate)))))
		p80.Text((("In View: %*"):format(p79.InView)))
		p80.Text((("Accumulated Delta: %*"):format((string.format("%.3f", p79.AccumulatedDelta)))))
		p80.Text((("Force: %*"):format((string.format("%.3f, %.3f, %.3f", p79.Force.X, p79.Force.Y, p79.Force.Z)))))
	end
	local v81 = Color3.new(0.486275, 0.431373, 1)
	local v82 = Color3.new(1, 1, 1)
	if v_u_4.DEBUG_OVERLAY_BONE then
		for v83, v84 in p79.Bones do
			if v_u_4.DEBUG_OVERLAY_MAX_BONES > 0 and v_u_4.DEBUG_OVERLAY_BONE_OFFSET + v_u_4.DEBUG_OVERLAY_MAX_BONES <= v83 then
				break
			end
			if v83 >= v_u_4.DEBUG_OVERLAY_BONE_OFFSET then
				p80.Begin(("Bone %*"):format(v83), v81, v82)
				v84:DrawOverlay(p80)
				p80.End()
			end
		end
	end
end
function v_u_9.Destroy(p85)
	-- upvalues: (copy) v_u_8
	v_u_8("Destroy BoneTree")
	task.synchronize()
	p85.DestroyConnection:Disconnect()
	p85.AttributeConnection:Disconnect()
	for _, v86 in p85.Bones do
		v86:Destroy()
	end
	setmetatable(p85, nil)
	task.desynchronize()
end
return v_u_9