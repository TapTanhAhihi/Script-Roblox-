-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = game:GetService("Players")
function v1.Start(p_u_3)
	-- upvalues: (copy) v_u_2
	local v_u_4 = workspace.NPCs
	local v_u_5 = p_u_3.Shared.Network
	local v_u_6 = v_u_2.LocalPlayer:WaitForChild("PlayerGui").SellGUI
	local v7 = v_u_6.Canvas.Main
	local v8 = v7.All
	local v9 = v7.One
	task.delay(3, function()
		-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) p_u_3
		for _, v10 in pairs(v_u_4:GetChildren()) do
			if v10.Name == "bluewaterrobux" then
				v10.HumanoidRootPart.ProximityPrompt.Triggered:Connect(function()
					-- upvalues: (ref) v_u_6, (ref) p_u_3
					if not v_u_6.Enabled then
						p_u_3:OpenGUI()
						local v11 = p_u_3.Controllers.Tutorial
						if v11 and v11.WentToDock then
							v11:WentToDock()
						end
					end
				end)
			end
		end
	end)
	v8.Activated:Connect(function()
		-- upvalues: (copy) v_u_6, (copy) v_u_5
		if v_u_6.Enabled then
			local v12 = {}
			for v13, _ in pairs(_G.LockedFish or {}) do
				table.insert(v12, v13)
			end
			local _, _, _ = v_u_5:InvokeServer("SellFishingEverything", v12)
		end
	end)
	v9.Activated:Connect(function()
		-- upvalues: (copy) v_u_6, (copy) v_u_5
		if v_u_6.Enabled then
			local _, _ = v_u_5:InvokeServer("SellBackpackFish")
		end
	end)
	v_u_5:BindEvents({
		["CloseSell"] = function()
			-- upvalues: (copy) p_u_3
			p_u_3.Controllers.HUD:CloseAllUI()
			p_u_3.Controllers.HUD:Effect(false)
		end
	})
end
function v1.OpenGUI(p14)
	-- upvalues: (copy) v_u_2
	local v15 = v_u_2.LocalPlayer:WaitForChild("PlayerGui").SellGUI
	local _ = v15.Canvas.Main
	local v16 = p14.Shared.sprLib
	v15.Enabled = true
	p14.Controllers.HUD:CloseAllUI(v15)
	v15.Canvas.Size = UDim2.new(0, 0, 1, 0)
	p14.Controllers.HUD:Effect(true)
	v16.target(v15.Canvas, 1, 4, {
		["Size"] = UDim2.new(1, 0, 1, 0)
	})
end
return v1