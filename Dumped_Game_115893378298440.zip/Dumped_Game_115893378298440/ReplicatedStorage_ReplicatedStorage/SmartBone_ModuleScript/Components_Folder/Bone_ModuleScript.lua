-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = script.Parent.Parent:WaitForChild("Dependencies")
local v_u_2 = require(v1:WaitForChild("Config"))
local v_u_3 = require(v1:WaitForChild("Gizmo"))
local v_u_4 = require(v1:WaitForChild("Utilities"))
if game:GetService("RunService"):IsStudio() or v_u_2.ALLOW_LIVE_GAME_DEBUG then
	v_u_3.Init()
end
local v5 = script.Parent:WaitForChild("Constraints")
local v_u_6 = require(v5:WaitForChild("AxisConstraint"))
local v_u_7 = require(v5:WaitForChild("CollisionConstraint"))
local v_u_8 = require(v5:WaitForChild("DistanceConstraint"))
local v_u_9 = require(v5:WaitForChild("FrictionConstraint"))
local v_u_10 = require(v5:WaitForChild("RopeConstraint"))
local v_u_11 = require(v5:WaitForChild("RotationConstraint"))
local v_u_12 = require(v5:WaitForChild("SpringConstraint"))
local v_u_13 = v_u_4.SB_ASSERT_CB
local v_u_14 = v_u_4.SB_VERBOSE_LOG
local v_u_15 = {}
local function v_u_21(p16)
	-- upvalues: (copy) v_u_15, (copy) v_u_21
	debug.profilebegin("QueryTransformedWorldCFrameNonSmartbone")
	local v17 = v_u_15[p16]
	if v17 and v17.Frame == shared.FrameCounter then
		return v17.CFrame
	end
	local v18 = p16.Parent
	local v19
	if v18:IsA("Bone") then
		v19 = v_u_21(v18)
	else
		v19 = v18.CFrame
	end
	local v20 = v19 * p16.TransformedCFrame
	v_u_15[p16] = {
		["Frame"] = shared.FrameCounter,
		["CFrame"] = v20
	}
	debug.profileend()
	return v20
end
local function v_u_27(p22, p23)
	-- upvalues: (copy) v_u_21, (copy) v_u_27
	debug.profilebegin("QueryTransformedWorldCFrame")
	p23.SolvedAnimatedCFrame = true
	local v24 = p23.ParentIndex
	local v25 = p23.Bone
	if v24 < 1 then
		debug.profileend()
		return v_u_21(v25)
	end
	local v26 = p22.Bones[v24]
	if not v26.SolvedAnimatedCFrame then
		v26.AnimatedWorldCFrame = v_u_27(p22, v26)
	end
	debug.profileend()
	return v26.AnimatedWorldCFrame * v25.TransformedCFrame
end
local function v_u_77(p28, p_u_29)
	local v_u_30 = p_u_29.Settings
	local v31 = v_u_30.WindType
	if v31 ~= "Sine" and (v31 ~= "Noise" and v31 ~= "Hybrid") then
		return Vector3.new(0, 0, 0)
	end
	local v32 = p_u_29.WindOffset + (os.clock() - p28.HeirarchyLength * 0.2 + (p28.TransformOffset.Position - p_u_29.Root.WorldPosition).Magnitude * 0.2) * v_u_30.WindInfluence
	local v33 = nil
	local function v49(p34, p35)
		-- upvalues: (copy) v_u_30, (copy) p_u_29
		local v36 = p34 or 0
		local v37 = v_u_30.WindStrength ^ 0.8
		local v38 = v_u_30.WindSpeed * 2
		local v39 = p_u_29.WindOffset
		local v40 = math.noise(v37, 0, v39)
		local v41 = math.clamp(v40, -1, 1)
		if p35 then
			v41 = v41 ^ 2
		end
		local v42 = v41 * (v38 + v36)
		local v43 = math.noise(0, v37, v39)
		local v44 = math.clamp(v43, -1, 1)
		if p35 then
			v44 = v44 ^ 2
		end
		local v45 = v44 * (v38 + v36)
		local v46 = math.noise(v39, 0, v37)
		local v47 = math.clamp(v46, -1, 1)
		if p35 then
			v47 = v47 ^ 2
		end
		local v48 = v47 * (v38 + v36)
		return v_u_30.WindDirection * Vector3.new(v42, v45, v48)
	end
	if v_u_30.WindType == "Sine" then
		local v50 = v_u_30.WindStrength ^ 0.8
		local v51 = v_u_30.WindSpeed * 2
		local v52 = v32 * v50
		local v53 = math.sin(v52) ^ 2
		local v54 = v32 * v50
		local v55 = math.cos(v54) ^ 2
		local v56 = (v53 + (v55 - v53) * v55) * v51
		local v57 = v_u_30.WindDirection * v56
		local v58 = v32 * 1
		v33 = v57 * (math.sin(v58) * 0.3 + 0.7)
	elseif v_u_30.WindType == "Noise" then
		local v59 = v49(0, true)
		local v60 = v32 * 1
		v33 = v59 * (math.sin(v60) * 0.3 + 0.7)
	elseif v_u_30.WindType == "Hybrid" then
		local v61 = v_u_30.WindStrength ^ 0.8
		local v62 = v_u_30.WindSpeed * 2
		local v63 = v32 * v61
		local v64 = math.sin(v63) ^ 2
		local v65 = v32 * v61
		local v66 = math.cos(v65) ^ 2
		local v67 = (v64 + (v66 - v64) * v66) * v62
		local v68 = v_u_30.WindDirection * v67
		local v69 = v32 * 1
		local v70 = v68 * (math.sin(v69) * 0.3 + 0.7)
		local v71 = v49(0.5, true)
		local v72 = v32 * 1
		v33 = (v70 + v71 * (math.sin(v72) * 0.3 + 0.7)) * 0.5
	end
	local v73 = p28.FreeLength
	local v74 = v33 / math.max(v73, 0.01)
	local v75 = v_u_30.WindInfluence * (v_u_30.WindStrength * 0.01)
	local v76 = p28.HeirarchyLength
	return v74 * (v75 * (math.clamp(v76, 1, 10) * 0.1)) * p28.Weight
end
local v_u_78 = {}
v_u_78.__index = v_u_78
function v_u_78.new(p_u_79, p80, p81)
	-- upvalues: (copy) v_u_78, (copy) v_u_4
	local v82 = p_u_79.Parent:IsA("Bone") and p_u_79.Parent.TransformedWorldCFrame or p81.CFrame
	local v83 = {
		["Bone"] = p_u_79,
		["FreeLength"] = -1,
		["Weight"] = 0.7,
		["ParentIndex"] = -1,
		["HeirarchyLength"] = 0,
		["Transform"] = p_u_79.TransformedWorldCFrame:ToObjectSpace(v82):Inverse(),
		["LocalTransform"] = p_u_79.TransformedCFrame:ToObjectSpace(p80.TransformedCFrame):Inverse(),
		["RootPart"] = p81,
		["RootBone"] = p80,
		["Radius"] = 0,
		["Friction"] = 0,
		["RotationLimit"] = 0,
		["Force"] = nil,
		["Gravity"] = nil,
		["SolvedAnimatedCFrame"] = false,
		["HasChild"] = false,
		["AnimatedWorldCFrame"] = p_u_79.TransformedWorldCFrame,
		["StartingCFrame"] = p_u_79.TransformedCFrame,
		["TransformOffset"] = CFrame.identity,
		["LocalTransformOffset"] = CFrame.identity,
		["RestPosition"] = Vector3.new(0, 0, 0),
		["CalculatedWorldCFrame"] = p_u_79.TransformedWorldCFrame,
		["Position"] = p_u_79.TransformedWorldCFrame.Position,
		["LastPosition"] = p_u_79.TransformedWorldCFrame.Position,
		["WeldPosition"] = Vector3.new(0, 0, 0),
		["ActiveWeld"] = false,
		["RigidWeld"] = false,
		["Anchored"] = false,
		["AxisLocked"] = { false, false, false },
		["XAxisLimits"] = NumberRange.new((-1 / 0), (1 / 0)),
		["YAxisLimits"] = NumberRange.new((-1 / 0), (1 / 0)),
		["ZAxisLimits"] = NumberRange.new((-1 / 0), (1 / 0)),
		["FirstSkipUpdate"] = false,
		["CollisionHits"] = {},
		["CollisionsData"] = {}
	}
	local v84 = v_u_78
	local v_u_85 = setmetatable(v83, v84)
	v_u_85.AttributeConnection = p_u_79.AttributeChanged:Connect(function(_)
		-- upvalues: (ref) v_u_4, (copy) p_u_79, (copy) v_u_85
		for v86, v89 in v_u_4.GatherBoneSettings(p_u_79) do
			local v88 = v_u_85
			if v89 == "\194\172" or not v89 then
				local v89 = nil
			end
			v88[v86] = v89
		end
	end)
	return v_u_85
end
function v_u_78.ClipVelocity(p90, p91, p92)
	p90.LastPosition = p90.LastPosition * (Vector3.new(1, 1, 1) - p92) + p91 * p92
end
function v_u_78.PreUpdate(p93, p94)
	-- upvalues: (copy) v_u_27, (copy) v_u_21
	debug.profilebegin("Bone::PreUpdate")
	local v95 = p94.Bones[1]
	local v96 = p94.Bones[p93.ParentIndex]
	p93.AnimatedWorldCFrame = v_u_27(p94, p93)
	local v97 = p93.Bone:FindFirstChild("SmartWeld")
	p93.ActiveWeld = false
	if v97 and v97:IsA("ObjectValue") then
		local v98 = v97.Value
		p93.RigidWeld = v97:GetAttribute("Rigid") == true
		if v98 then
			if v98:IsA("Attachment") then
				p93.WeldPosition = v98.WorldPosition
				p93.ActiveWeld = true
			elseif v98:IsA("BasePart") then
				p93.WeldPosition = v98.Position
				p93.ActiveWeld = true
			end
		end
	end
	if p93.ParentIndex < 1 then
		p93.Anchored = true
	end
	if p93.Bone == p93.RootBone then
		local v99
		if p93.Bone.Parent:IsA("Bone") then
			v99 = v_u_21(p93.Bone.Parent)
		else
			v99 = p93.RootPart.CFrame
		end
		p93.TransformOffset = v99 * p93.Transform
	else
		p93.TransformOffset = v96.AnimatedWorldCFrame * p93.Transform
	end
	p93.LocalTransformOffset = v95.Bone.CFrame * p93.LocalTransform
	debug.profileend()
end
function v_u_78.StepPhysics(p100, p101, p102, p103)
	-- upvalues: (copy) v_u_77
	debug.profilebegin("Bone::StepPhysics")
	if p100.Anchored then
		p100.LastPosition = p100.AnimatedWorldCFrame.Position
		p100.Position = p100.AnimatedWorldCFrame.Position
		debug.profileend()
	else
		if p100.Force or p100.Gravity then
			p102 = ((p100.Gravity or p101.Settings.Gravity) + (p100.Force or p101.Settings.Force)) * p103
		end
		local v104 = p101.Settings
		local v105 = p100.Position - p100.LastPosition
		local v106 = p101.ObjectAcceleration * v104.Inertia
		local v107 = v_u_77(p100, p101)
		p100.LastPosition = p100.Position
		p100.Position = p100.Position + (v105 * (1 - v104.Damping) + p102 + v106 + v107)
		debug.profileend()
	end
end
function v_u_78.Constrain(p108, p109, p110, p111)
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (copy) v_u_12, (copy) v_u_8, (copy) v_u_10, (copy) v_u_6, (copy) v_u_11
	debug.profilebegin("Bone::Constrain")
	if p108.Anchored then
		debug.profileend()
	else
		local v112 = p108.Position
		local v113 = p108.RootPart.CFrame
		local v114 = v_u_9(p108, v112, p108.LastPosition)
		if #p110 ~= 0 then
			v114 = v_u_7(p108, v114, p110)
		end
		local v115
		if p109.Settings.Constraint == "Spring" then
			v115 = v_u_12(p108, v114, nil, p109, p111)
		elseif p109.Settings.Constraint == "Distance" then
			v115 = v_u_8(p108, v114, p109)
		elseif p109.Settings.Constraint == "Rope" then
			v115 = v_u_10(p108, v114, p109)
		else
			v115 = p108.AnimatedWorldCFrame.Position
		end
		local v116 = v_u_11(p108, v_u_6(p108, v115, p108.LastPosition, v113), p109)
		if p108.ActiveWeld then
			if p108.RigidWeld then
				v116 = v_u_8(p108, p108.WeldPosition, p109)
			else
				v116 = v_u_12(p108, v116, p108.WeldPosition, p109, p111)
			end
		end
		p108.Friction = 0
		for _, v117 in p108.CollisionHits do
			local v118 = p108.RootPart.CurrentPhysicalProperties
			local v119 = v117.CurrentPhysicalProperties
			local v120 = v118.Friction
			local v121 = v118.FrictionWeight
			local v122 = v119.Friction
			local v123 = v119.FrictionWeight
			local v124 = (v120 * v121 + v122 * v123) / (v121 + v123)
			local v125 = p108.Friction
			p108.Friction = math.max(v124, v125)
		end
		p108.Position = v116
		debug.profileend()
	end
end
function v_u_78.SkipUpdate(p126)
	-- upvalues: (copy) v_u_2, (copy) v_u_14
	if p126.FirstSkipUpdate == false and v_u_2.RESET_TRANSFORM_ON_SKIP then
		v_u_14("Skipping bone, resetting transform.")
		p126.CalculatedWorldCFrame = p126.AnimatedWorldCFrame
		p126.FirstSkipUpdate = true
	end
	p126.Position = p126.Bone.WorldPosition
	p126.LastPosition = p126.Position
end
function v_u_78.SolveTransform(p127, p128, p129)
	-- upvalues: (copy) v_u_4, (copy) v_u_13
	debug.profilebegin("Bone::SolveTransform")
	if p127.ParentIndex < 1 then
		debug.profileend()
	else
		p127.FirstSkipUpdate = false
		local v130 = p128.Bones[p127.ParentIndex]
		local v131 = v130.Bone
		if v130 and v131 then
			local v132 = v130.TransformOffset
			local v133 = p127.Position - v130.Position
			local v134 = v_u_4.GetRotationBetween(v132.UpVector, v133).Rotation * v132.Rotation
			local v135 = 1 - 0.00001 ^ p129
			local v136 = math.min(v135, 1)
			if v130.ActiveWeld and v130.RigidWeld then
				v130.CalculatedWorldCFrame = CFrame.new(v130.Position) * v134
			else
				v130.CalculatedWorldCFrame = v131.WorldCFrame:Lerp(CFrame.new(v130.Position) * v134, v136)
			end
			local v137 = v_u_13
			local v138 = v130.CalculatedWorldCFrame.Position
			v137(v138 == v138, warn, "If you see this report this as a bug, (NaN Calc world cframe)")
		end
		debug.profileend()
	end
end
function v_u_78.ApplyTransform(p139, p140)
	debug.profilebegin("Bone::ApplyTransform")
	p139.SolvedAnimatedCFrame = false
	if p139.ParentIndex < 1 then
		debug.profileend()
	else
		local v141 = p140.Bones[p139.ParentIndex]
		local v142 = v141.Bone
		if v141 and v142 then
			if v141.Anchored and p140.Settings.AnchorsRotate == false then
				v142.WorldCFrame = v141.TransformOffset
			else
				if v141.Anchored and p140.Settings.AnchorsRotate == true then
					v142.WorldCFrame = v141.TransformOffset * v141.CalculatedWorldCFrame.Rotation
					debug.profileend()
					return
				end
				if v141.Anchored then
					v142.WorldCFrame = v141.TransformOffset
					debug.profileend()
					return
				end
				v142.WorldCFrame = v141.CalculatedWorldCFrame
			end
		end
		debug.profileend()
	end
end
function v_u_78.DrawDebug(p143, p144, p145, p146, p147, p148, p149)
	-- upvalues: (copy) v_u_3
	debug.profilebegin("Bone::DrawDebug")
	local v150 = Color3.fromRGB(255, 0, 0)
	local v151 = Color3.fromRGB(255, 94, 0)
	local v152 = Color3.fromRGB(234, 1, 255)
	local v153 = Color3.fromRGB(0, 255, 255)
	local v154 = Color3.fromRGB(255, 0, 0)
	local v155 = Color3.fromRGB(0, 255, 0)
	local v156 = Color3.fromRGB(0, 0, 255)
	local v157 = Color3.fromRGB(0, 183, 255)
	local v158 = Color3.fromRGB(255, 0, 0)
	local v159 = Color3.fromRGB(0, 255, 0)
	local v160 = Color3.fromRGB(0, 0, 255)
	local v161 = Color3.fromRGB(28, 41, 224)
	local v162 = Color3.fromRGB(255, 27, 27)
	local v163 = 1
	local v164 = p143.AnimatedWorldCFrame
	local v165 = v164.Position
	local v166 = CFrame.new(p143.Position)
	local v167 = CFrame.new(p143.LastPosition)
	if p147 then
		v_u_3.PushProperty("AlwaysOnTop", false)
		v_u_3.PushProperty("Color3", v150)
		v_u_3.Sphere:Draw(v166, p143.Radius, 10, 360)
		v_u_3.PushProperty("Color3", v151)
		v_u_3.Sphere:Draw(v167, p143.Radius, 10, 360)
		v_u_3.PushProperty("Color3", v152)
		v_u_3.Ray:Draw(p143.Position, p143.LastPosition)
	end
	if p148 and not p143.Anchored then
		local v168 = p143.AxisLocked[1]
		local v169 = p143.AxisLocked[2]
		local v170 = p143.AxisLocked[3]
		local v171 = p143.RootPart
		local v172 = v171.CFrame:PointToObjectSpace(v165)
		local v173 = v171.CFrame.RightVector
		local v174 = v171.CFrame.UpVector
		local v175 = v171.CFrame.LookVector
		if not v168 then
			v_u_3.PushProperty("Color3", v158)
			v_u_3.Arrow:Draw(v165 - v173 * 2, v165 + v173 * 2, 0.05, 0.15, 9)
			local v176 = p143.XAxisLimits.Min - v172.X
			local v177 = p143.XAxisLimits.Max - v172.X
			v_u_3.Plane:Draw(v165 + v173 * v176, v173, Vector3.new(5, 5, 0))
			v_u_3.Plane:Draw(v165 + v173 * v177, v173, Vector3.new(5, 5, 0))
		end
		if not v169 then
			v_u_3.PushProperty("Color3", v159)
			v_u_3.Arrow:Draw(v165 - v174 * 2, v165 + v174 * 2, 0.05, 0.15, 9)
			local v178 = p143.YAxisLimits.Min - v172.Y
			local v179 = p143.YAxisLimits.Max - v172.Y
			v_u_3.Plane:Draw(v165 + v174 * v178, v174, Vector3.new(5, 5, 0))
			v_u_3.Plane:Draw(v165 + v174 * v179, v174, Vector3.new(5, 5, 0))
		end
		if not v170 then
			v_u_3.PushProperty("Color3", v160)
			v_u_3.Arrow:Draw(v165 - v175 * 2, v165 + v175 * 2, 0.05, 0.15, 9)
			local v180 = p143.ZAxisLimits.Min - v172.Z
			local v181 = p143.ZAxisLimits.Max - v172.Z
			v_u_3.Plane:Draw(v165 - v175 * v180, v175, Vector3.new(5, 5, 0))
			v_u_3.Plane:Draw(v165 - v175 * v181, v175, Vector3.new(5, 5, 0))
		end
	end
	if p146 then
		v_u_3.PushProperty("Color3", v153)
		v_u_3.Sphere:Draw(v164, 0.08, 5, 360)
		v_u_3.PushProperty("Color3", v154)
		v_u_3.VolumeArrow:Draw(v165, v165 + v164.LookVector * 0.25, 0.005, 0.015, 0.05, true)
		v_u_3.PushProperty("Color3", v155)
		v_u_3.VolumeArrow:Draw(v165, v165 + v164.UpVector * 0.25, 0.005, 0.015, 0.05, true)
		v_u_3.PushProperty("Color3", v156)
		v_u_3.VolumeArrow:Draw(v165, v165 + v164.RightVector * 0.25, 0.005, 0.015, 0.05, true)
	end
	if p145 and not p143.Anchored then
		for _, v182 in p143.CollisionsData do
			v_u_3.PushProperty("Color3", v161)
			v_u_3.Sphere:Draw(CFrame.new(v182.ClosestPoint), 0.08, 5, 360)
			v_u_3.PushProperty("Color3", v162)
			v_u_3.Arrow:Draw(v182.ClosestPoint, v182.ClosestPoint + v182.Normal * 0.5, 0.05, 0.15, 9)
		end
	end
	if p149 and (p143.RotationLimit < 180 and (p143.RotationLimit > 0 and (p143.ParentIndex > 0 and p143.HasChild))) then
		local v183 = 1
		local v184
		if p143.RotationLimit < 89.5 then
			local v185 = p143.RotationLimit
			local v186 = math.rad(v185)
			v184 = v163 * math.tan(v186)
		elseif p143.RotationLimit > 90 then
			local v187 = 180 - p143.RotationLimit
			local v188 = math.rad(v187)
			v184 = v163 * math.tan(v188)
			v183 = -1
		else
			v184 = 5
			v163 = 0
		end
		local v189 = math.min(v184, 5)
		local v190 = v189 == 5 and 0 or v163
		local v191 = (p143.Position - p144.Bones[p143.ParentIndex].Position).Unit * v183
		local v192 = CFrame.lookAt(v165 + v191 * (v190 / 2), v165 + -v191 * 500, v164.LookVector)
		v_u_3.PushProperty("Color3", v157)
		v_u_3.Cone:Draw(v192, v189, v190, 8 + v189 * 2)
	end
	debug.profileend()
end
function v_u_78.DrawOverlay(p193, p194)
	-- upvalues: (copy) v_u_2
	p194.Text((("Bone: %*"):format(p193.Bone.Name)))
	if v_u_2.DEBUG_OVERLAY_BONE_INFO or v_u_2.DEBUG_OVERLAY_BONE_NUMERICS then
		p194.Text((("Free Length: %*"):format(p193.FreeLength)))
		p194.Text((("Weight: %*"):format(p193.Weight)))
		p194.Text((("Parent Index: %*"):format(p193.ParentIndex)))
		p194.Text((("Heirarchy Length: %*"):format(p193.HeirarchyLength)))
		p194.Text((("Radius: %*"):format(p193.Radius)))
		p194.Text((("Friction: %*"):format(p193.Friction)))
		p194.Text((("Rotation Limit: %*"):format(p193.RotationLimit)))
	end
	if v_u_2.DEBUG_OVERLAY_BONE_INFO or v_u_2.DEBUG_OVERLAY_BONE_CONSTRAIN then
		p194.Text((("Anchored: %*"):format(p193.Anchored)))
		p194.Text((("Axis Locked: %*, %*, %*"):format(p193.AxisLocked[1], p193.AxisLocked[2], p193.AxisLocked[3])))
		p194.Text((("X Axis Limit: %*"):format(p193.XAxisLimits)))
		p194.Text((("Y Axis Limit: %*"):format(p193.YAxisLimits)))
		p194.Text((("Z Axis Limit: %*"):format(p193.ZAxisLimits)))
	end
	if v_u_2.DEBUG_OVERLAY_BONE_INFO or v_u_2.DEBUG_OVERLAY_BONE_WELD then
		p194.Text((("Active Weld: %*"):format(p193.ActiveWeld)))
		p194.Text((("Rigid Weld: %*"):format(p193.RigidWeld)))
		p194.Text((("Weld Position: %*"):format((string.format("%.3f, %.3f, %.3f", p193.WeldPosition.X, p193.WeldPosition.Y, p193.WeldPosition.Z)))))
	end
	if v_u_2.DEBUG_OVERLAY_BONE_INFO or v_u_2.DEBUG_OVERLAY_BONE_FORCES then
		local v195 = p193.Force and (string.format("%.3f, %.3f, %.3f", p193.Force.X, p193.Force.Y, p193.Force.Z) or "-, -, -") or "-, -, -"
		local v196 = p193.Gravity and string.format("%.3f, %.3f, %.3f", p193.Gravity.X, p193.Gravity.Y, p193.Gravity.Z) or "-, -, -"
		p194.Text((("Force: %*"):format(v195)))
		p194.Text((("Gravity: %*"):format(v196)))
	end
end
function v_u_78.Destroy(p197)
	-- upvalues: (copy) v_u_2
	if v_u_2.RESET_BONE_ON_DESTROY then
		task.synchronize()
		p197.Bone.CFrame = p197.StartingCFrame
	end
	p197.AttributeConnection:Disconnect()
	setmetatable(p197, nil)
end
return v_u_78