-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = false
local v_u_3 = nil
function v1.Start(p4)
	-- upvalues: (ref) v_u_3
	local v5 = game:GetService("Players").LocalPlayer
	v_u_3 = p4.Shared.Network
	repeat
		task.wait()
	until v5:FindFirstChild("PlayerGui")
	local v6 = v5.PlayerGui:WaitForChild("Settings").Canvas.Main.List.Input
	local v_u_7 = v6.TextBox
	v6.Claim.Activated:Connect(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_7
		if v_u_3 then
			local v8 = v_u_7.Text
			if v8 and v8 ~= "" then
				if v_u_3:InvokeServer("RedeemCode", v8) then
					v_u_7.Text = ""
				end
			end
		else
			return
		end
	end)
end
function v1.Active(p9)
	-- upvalues: (ref) v_u_2
	if v_u_2 then
		return
	else
		local v10 = game:GetService("Players").LocalPlayer
		repeat
			task.wait()
		until v10:FindFirstChild("PlayerGui")
		local v11 = v10.PlayerGui:WaitForChild("Settings")
		game:GetService("TweenService")
		local v12 = p9.Shared.sprLib
		v_u_2 = true
		task.delay(0.5, function()
			-- upvalues: (ref) v_u_2
			v_u_2 = false
		end)
		v11.Enabled = not v11.Enabled
		v11.Canvas.Size = UDim2.new(0, 0, 1, 0)
		if v11.Enabled then
			p9.Controllers.HUD:CloseAllUI(v11)
			p9.Controllers.HUD:Effect(true)
			v12.target(v11.Canvas, 1, 4, {
				["Size"] = UDim2.new(1, 0, 1, 0)
			})
		else
			p9.Controllers.HUD:Effect(false)
		end
	end
end
return v1