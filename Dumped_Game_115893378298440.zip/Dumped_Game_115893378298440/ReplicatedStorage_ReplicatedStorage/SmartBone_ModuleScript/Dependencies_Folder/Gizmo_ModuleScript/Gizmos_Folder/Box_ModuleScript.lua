-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = {}
v_u_1.__index = v_u_1
function v_u_1.Init(p2, p3, p4, p5, p6)
	-- upvalues: (copy) v_u_1
	local v7 = v_u_1
	local v8 = setmetatable({}, v7)
	v8.Ceive = p2
	v8.Propertys = p3
	v8.Request = p4
	v8.Release = p5
	v8.Retain = p6
	return v8
end
function v_u_1.Draw(p9, p10, p11, p_u_12)
	local v_u_13 = p9.Ceive
	if v_u_13.Enabled then
		local v_u_14 = p10.Position
		local v15 = p10.UpVector
		local v16 = p10.RightVector
		local v17 = p10.LookVector
		local v18 = p11 * 0.5
		local v19 = v15 * v18.Y
		local v20 = v16 * v18.X
		local v21 = v17 * v18.Z
		local function v29(p22, p23, p24)
			-- upvalues: (copy) v_u_14, (copy) v_u_13, (copy) p_u_12
			local v25 = v_u_14 + (p22 - p23 + p24)
			local v26 = v_u_14 + (p22 + p23 + p24)
			local v27 = v_u_14 + (p22 - p23 - p24)
			local v28 = v_u_14 + (p22 + p23 - p24)
			v_u_13.Ray:Draw(v25, v26)
			v_u_13.Ray:Draw(v25, v27)
			v_u_13.Ray:Draw(v26, v28)
			if p_u_12 ~= false then
				v_u_13.Ray:Draw(v26, v27)
			end
			v_u_13.Ray:Draw(v27, v28)
		end
		local function v37(p30, p31, p32)
			-- upvalues: (copy) v_u_14, (copy) v_u_13, (copy) p_u_12
			local v33 = v_u_14 + (p30 - p31 + p32)
			local v34 = v_u_14 + (p30 + p31 + p32)
			local v35 = v_u_14 + (-p30 - p31 + p32)
			local v36 = v_u_14 + (-p30 + p31 + p32)
			v_u_13.Ray:Draw(v33, v34)
			v_u_13.Ray:Draw(v33, v35)
			v_u_13.Ray:Draw(v34, v36)
			if p_u_12 ~= false then
				v_u_13.Ray:Draw(v34, v35)
			end
			v_u_13.Ray:Draw(v35, v36)
		end
		local function v45(p38, p39, p40)
			-- upvalues: (copy) v_u_14, (copy) v_u_13, (copy) p_u_12
			local v41 = v_u_14 + (p38 - p39 - p40)
			local v42 = v_u_14 + (p38 - p39 + p40)
			local v43 = v_u_14 + (-p38 - p39 - p40)
			local v44 = v_u_14 + (-p38 - p39 + p40)
			v_u_13.Ray:Draw(v41, v42)
			v_u_13.Ray:Draw(v41, v43)
			v_u_13.Ray:Draw(v42, v44)
			if p_u_12 ~= false then
				v_u_13.Ray:Draw(v42, v43)
			end
			v_u_13.Ray:Draw(v43, v44)
		end
		v45(v19, v20, v21)
		v45(v19, -v20, v21)
		v29(v19, v20, v21)
		v29(-v19, v20, v21)
		v37(v19, v20, v21)
		v37(v19, v20, -v21)
	end
end
function v_u_1.Create(p46, p47, p48, p49)
	local v50 = {
		["Transform"] = p47,
		["Size"] = p48,
		["DrawTriangles"] = p49,
		["AlwaysOnTop"] = p46.Propertys.AlwaysOnTop,
		["Transparency"] = p46.Propertys.Transparency,
		["Color3"] = p46.Propertys.Color3,
		["Enabled"] = true,
		["Destroy"] = false
	}
	p46.Retain(p46, v50)
	return v50
end
function v_u_1.Update(p51, p52)
	local v53 = p51.Ceive
	v53.PushProperty("AlwaysOnTop", p52.AlwaysOnTop)
	v53.PushProperty("Transparency", p52.Transparency)
	v53.PushProperty("Color3", p52.Color3)
	p51:Draw(p52.Transform, p52.Size, p52.DrawTriangles)
end
return v_u_1