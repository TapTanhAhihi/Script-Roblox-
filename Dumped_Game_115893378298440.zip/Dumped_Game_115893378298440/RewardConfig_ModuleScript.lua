-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v27 = {
	{
		["Display"] = "rbxassetid://81061472342232",
		["Day"] = 1,
		["RewardType"] = function(p2, _, p3, p4)
			local v5 = p3.BaitService
			if v5 and v5.AddBait then
				v5:AddBait(p2, "Shrimp Bait", 10)
			end
			local v6 = p2:FindFirstChild("leaderstats")
			if v6 then
				v6 = v6:FindFirstChild("Money")
			end
			if v6 then
				v6.Value = v6.Value + 5000
			end
			if p4 then
				p4:FireClient(p2, "SendNotification", {
					["Text"] = "You received 10x " .. "Shrimp Bait" .. " and " .. 5000 .. " money!",
					["Type"] = "Success"
				})
			end
		end
	},
	{
		["Display"] = "rbxassetid://77426829129951",
		["Day"] = 2,
		["RewardType"] = function(p7, _, p8, p9)
			local v10 = p8.BaitService
			if v10 and v10.AddBait then
				v10:AddBait(p7, "Earthworms Bait", 10)
			end
			local v11 = p7:FindFirstChild("leaderstats")
			if v11 then
				v11 = v11:FindFirstChild("Money")
			end
			if v11 then
				v11.Value = v11.Value + 10000
			end
			if p9 then
				p9:FireClient(p7, "SendNotification", {
					["Text"] = "You received 10x " .. "Earthworms Bait" .. " and " .. 10000 .. " money!",
					["Type"] = "Success"
				})
			end
		end
	},
	{
		["Display"] = "rbxassetid://120819946726622",
		["Day"] = 3,
		["RewardType"] = function(p12, _, p13, p14)
			local v15 = p13.BaitService
			if v15 and v15.AddBait then
				v15:AddBait(p12, "Corn Bait", 10)
			end
			local v16 = p12:FindFirstChild("leaderstats")
			if v16 then
				v16 = v16:FindFirstChild("Money")
			end
			if v16 then
				v16.Value = v16.Value + 20000
			end
			if p14 then
				p14:FireClient(p12, "SendNotification", {
					["Text"] = "You received 10x " .. "Corn Bait" .. " and " .. 20000 .. " money!",
					["Type"] = "Success"
				})
			end
		end
	},
	{
		["Display"] = "rbxassetid://95231266000483",
		["Day"] = 4,
		["RewardType"] = function(p17, _, p18, p19)
			local v20 = p18.BaitService
			if v20 and v20.AddBait then
				v20:AddBait(p17, "Boilies Bait", 10)
			end
			local v21 = p17:FindFirstChild("leaderstats")
			if v21 then
				v21 = v21:FindFirstChild("Money")
			end
			if v21 then
				v21.Value = v21.Value + 30000
			end
			if p19 then
				p19:FireClient(p17, "SendNotification", {
					["Text"] = "You received 10x " .. "Boilies Bait" .. " and " .. 30000 .. " money!",
					["Type"] = "Success"
				})
			end
		end
	},
	{
		["Display"] = "rbxassetid://118656124411412",
		["Day"] = 5,
		["RewardType"] = function(p22, _, p23, p24)
			local v25 = p23.BaitService
			if v25 and v25.AddBait then
				v25:AddBait(p22, "Minnow Bait", 10)
			end
			local v26 = p22:FindFirstChild("leaderstats")
			if v26 then
				v26 = v26:FindFirstChild("Money")
			end
			if v26 then
				v26.Value = v26.Value + 40000
			end
			if p24 then
				p24:FireClient(p22, "SendNotification", {
					["Text"] = "You received 10x " .. "Minnow Bait" .. " and " .. 40000 .. " money!",
					["Type"] = "Success"
				})
			end
		end
	}
}
v1.Rewards = v27
v1.CooldownHours = 24
v1.WeeklyReset = true
return v1