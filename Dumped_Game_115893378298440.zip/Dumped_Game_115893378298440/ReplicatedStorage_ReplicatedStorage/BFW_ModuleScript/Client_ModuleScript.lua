-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = game:GetService("Players").LocalPlayer
local v_u_2 = {}
v_u_2.__index = v_u_2
function v_u_2.new()
	-- upvalues: (copy) v_u_2
	local v3 = v_u_2
	return setmetatable({
		["Controllers"] = {},
		["Shared"] = {},
		["Loaded"] = false
	}, v3)
end
function v_u_2.Load(p_u_4, p5, p6)
	-- upvalues: (copy) v_u_1
	if p_u_4.Loaded then
		warn("BFW already loaded")
		return
	else
		p_u_4.Loaded = true
		if p5 and p5.Parent then
			if p6 then
				for _, v7 in ipairs(p6:GetChildren()) do
					if v7:IsA("ModuleScript") then
						local v8, v9 = pcall(require, v7)
						if v8 then
							p_u_4.Shared[v7.Name] = v9
							v7:Destroy()
						else
							warn("Failed loading Shared:", v7.Name, v9)
						end
					end
				end
			end
			local v10 = game.ReplicatedStorage:WaitForChild("Modules", 10)
			if v10 then
				v10 = v10:WaitForChild("Data", 10)
			end
			local v11 = {}
			if v10 then
				for _, v12 in ipairs(v10:GetChildren()) do
					if v12:IsA("ModuleScript") then
						local v13, v14 = pcall(require, v12)
						if v13 then
							v11[v12.Name] = v14
							v12:Destroy()
						else
							warn("Failed loading Data:", v12.Name, v14)
						end
					end
				end
			else
				warn("DataFolder not found")
			end
			p_u_4.Controllers = {}
			_G.Controllers = {}
			for _, v15 in ipairs(p5:GetChildren()) do
				if v15:IsA("ModuleScript") then
					local v16, v17 = pcall(require, v15)
					if v16 and v17 then
						v17.Name = v15.Name
						v17.Shared = p_u_4.Shared
						v17.Controllers = p_u_4.Controllers
						v17.Data = v11
						v17._connections = {}
						p_u_4.Controllers[v15.Name] = v17
						_G.Controllers[v15.Name] = v17
						v15:Destroy()
					else
						warn("Failed loading Controller:", v15.Name, v17)
					end
				end
			end
			for _, v_u_18 in pairs(p_u_4.Controllers) do
				if v_u_18.Init then
					task.spawn(function()
						-- upvalues: (copy) v_u_18
						local v19, v20 = pcall(function()
							-- upvalues: (ref) v_u_18
							v_u_18:Init()
						end)
						if not v19 then
							warn("Init error:", v_u_18.Name, v20)
						end
					end)
				end
			end
			task.delay(0.1, function()
				-- upvalues: (copy) p_u_4
				for _, v_u_21 in pairs(p_u_4.Controllers) do
					if v_u_21.Start then
						task.spawn(function()
							-- upvalues: (copy) v_u_21
							local v22, v23 = pcall(function()
								-- upvalues: (ref) v_u_21
								v_u_21:Start()
							end)
							if not v22 then
								warn("Start error:", v_u_21.Name, v23)
							end
						end)
					end
				end
			end)
			local function v28(p_u_24)
				-- upvalues: (copy) p_u_4
				for _, v_u_25 in pairs(p_u_4.Controllers) do
					if v_u_25.OnCharacter then
						task.spawn(function()
							-- upvalues: (copy) v_u_25, (copy) p_u_24
							local v26, v27 = pcall(function()
								-- upvalues: (ref) v_u_25, (ref) p_u_24
								v_u_25:OnCharacter(p_u_24)
							end)
							if not v26 then
								warn("OnCharacter error:", v_u_25.Name, v27)
							end
						end)
					end
				end
			end
			v_u_1.CharacterAdded:Connect(v28)
			if v_u_1.Character then
				v28(v_u_1.Character)
			end
		else
			warn("ControllersFolder not ready")
		end
	end
end
function v_u_2.Destroy(p29)
	for _, v30 in pairs(p29.Controllers) do
		if v30.Destroy then
			v30:Destroy()
		end
		if v30._connections then
			for _, v31 in pairs(v30._connections) do
				v31:Disconnect()
			end
		end
	end
	p29.Controllers = {}
	p29.Shared = {}
	p29.Loaded = false
end
return v_u_2