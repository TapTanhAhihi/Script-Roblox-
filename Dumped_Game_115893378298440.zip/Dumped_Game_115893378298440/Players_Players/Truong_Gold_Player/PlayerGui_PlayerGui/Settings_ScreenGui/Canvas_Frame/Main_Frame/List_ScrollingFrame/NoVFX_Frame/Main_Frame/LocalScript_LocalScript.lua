-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = script.Parent.Toggle
local _ = v_u_1.On
local _ = v_u_1.Off
local v_u_2 = true
local v3 = v_u_1.ActiveButton
_G.AllowedVFX = true
v3.Activated:Connect(function()
	-- upvalues: (ref) v_u_2, (copy) v_u_1
	v_u_2 = not v_u_2
	if v_u_2 then
		_G.AllowedVFX = false
	else
		_G.AllowedVFX = true
	end
	if v_u_2 then
		v_u_1.On.Visible = true
		v_u_1.Off.Visible = false
	else
		v_u_1.On.Visible = false
		v_u_1.Off.Visible = true
	end
end)