-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v4 = {
	["1MVISITS"] = {
		["Reward"] = function(p1, _)
			local v2 = p1.leaderstats.Money
			v2.Value = v2.Value + 50000
			return true, "You got 50K money!"
		end,
		["Limit"] = nil,
		["PerUser"] = 1,
		["ExpiresAt"] = nil
	},
	["SORRY2026"] = {
		["Reward"] = function(p3, _)
			_G.Services.SkinService:AwardSkin(p3, "Shark Rod")
			_G.Services.SkillService:addSkillBook(_G.Services.DataService:GetProfile(p3), "Heaven-Lifting Hook", 1)
			return true, "You got a new skin, mythical book!"
		end,
		["Limit"] = nil,
		["PerUser"] = 1,
		["ExpiresAt"] = nil
	}
}
return v4