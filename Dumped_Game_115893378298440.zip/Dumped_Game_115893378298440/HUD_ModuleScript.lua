-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Lighting"):WaitForChild("Blur")
local v_u_5 = game:GetService("MarketplaceService")
local v_u_6 = workspace.CurrentCamera
function v1.Start(p_u_7)
	-- upvalues: (copy) v_u_2, (copy) v_u_5
	local v8 = v_u_2.LocalPlayer
	repeat
		task.wait()
	until v8:FindFirstChild("PlayerGui")
	local v9 = v8.PlayerGui
	local v10 = v9:WaitForChild("HUD")
	v9:FindFirstChild("HUD")
	local v11 = v10:WaitForChild("Canvas")
	local v_u_12 = v11:WaitForChild("Currency")
	repeat
		task.wait()
	until v8:FindFirstChild("leaderstats")
	local v_u_13 = v8:WaitForChild("leaderstats")
	v_u_13:WaitForChild("Gems")
	v_u_13:WaitForChild("Money")
	if v_u_12:WaitForChild("Gems", 5) and v_u_12:WaitForChild("Gold", 5) then
		local v14 = v10.SellAll
		v14.Activated:Connect(function()
			-- upvalues: (ref) v_u_5, (copy) p_u_7
			if v_u_5:UserOwnsGamePassAsync(game.Players.LocalPlayer.UserId, 1724471259) then
				local v15 = {}
				for v16, _ in pairs(_G.LockedFish or {}) do
					table.insert(v15, v16)
				end
				local _, _, _ = p_u_7.Shared.Network:InvokeServer("SellAllFishGamepass", v15)
			end
		end)
		if v_u_5:UserOwnsGamePassAsync(game.Players.LocalPlayer.UserId, 1724471259) then
			v14.Visible = true
		else
			v14.Visible = false
		end
		local v_u_17 = p_u_7.Shared.NumberFormatter
		local _ = p_u_7.Shared.Network
		v_u_12:WaitForChild("Gems").TextLabel.Text = v_u_17.Format(v_u_13.Gems.Value)
		v_u_13.Gems.Changed:Connect(function()
			-- upvalues: (copy) v_u_12, (copy) v_u_17, (copy) v_u_13
			v_u_12.Gems.TextLabel.Text = v_u_17.Format(v_u_13.Gems.Value)
		end)
		v_u_12:WaitForChild("Gold").TextLabel.Text = v_u_17.Format(v_u_13.Money.Value)
		v_u_13.Money.Changed:Connect(function()
			-- upvalues: (copy) v_u_12, (copy) v_u_17, (copy) v_u_13
			v_u_12.Gold.TextLabel.Text = v_u_17.Format(v_u_13.Money.Value)
		end)
		local v_u_18 = v8.Level
		local v_u_19 = v8.Exp
		local v20 = v10.Level
		local v_u_21 = v20.Fill
		local v_u_22 = v20.LevlCap
		local function v27()
			-- upvalues: (copy) v_u_18, (copy) v_u_19, (copy) v_u_21, (copy) v_u_22
			local v23 = v_u_18.Value
			local v24 = v23 == 1 and 40 or 50 + v23 * 40
			local v25 = v_u_19.Value / v24
			local v26 = math.clamp(v25, 0, 1)
			v_u_21.Size = UDim2.fromScale(v26, 1)
			v_u_22.Text = "Level: " .. v_u_18.Value .. " [" .. v_u_19.Value .. "/" .. v24 .. "]"
		end
		v_u_18:GetPropertyChangedSignal("Value"):Connect(v27)
		v_u_19:GetPropertyChangedSignal("Value"):Connect(v27)
		local v28 = v_u_18.Value
		local v29 = v28 == 1 and 40 or 50 + v28 * 40
		local v30 = v_u_19.Value / v29
		local v31 = math.clamp(v30, 0, 1)
		v_u_21.Size = UDim2.fromScale(v31, 1)
		v_u_22.Text = "Level: " .. v_u_18.Value .. " [" .. v_u_19.Value .. "/" .. v29 .. "]"
		local v32 = v11.Buttons
		for _, v_u_33 in pairs(v32:GetChildren()) do
			if v_u_33:IsA("ImageButton") then
				v_u_33.Glow.Visible = false
				v_u_33.Activated:Connect(function()
					-- upvalues: (copy) v_u_33, (copy) p_u_7, (copy) v_u_33
					if v_u_33.Name == "Inventory" then
						p_u_7.Controllers.Tutorial:Pressed()
					end
					if p_u_7.Controllers[v_u_33.Name] then
						p_u_7.Controllers[v_u_33.Name]:Active()
					end
				end)
				v_u_33.MouseEnter:Connect(function()
					-- upvalues: (copy) v_u_33
					v_u_33.Glow.Visible = true
				end)
				v_u_33.MouseLeave:Connect(function()
					-- upvalues: (copy) v_u_33
					v_u_33.Glow.Visible = false
				end)
			end
		end
		for _, v34 in pairs(v9:GetDescendants()) do
			if v34:IsA("ImageButton") and v34.Name == "Close" then
				v34.Activated:Connect(function()
					-- upvalues: (copy) p_u_7
					p_u_7:Effect(false)
					p_u_7:CloseAllUI()
				end)
			end
		end
	else
		warn("Currency UI missing Gems or Gold")
	end
end
function v1.Init(_) end
function v1.Effect(_, p35)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_6
	if p35 then
		v_u_4.Enabled = true
		v_u_3:Create(v_u_4, TweenInfo.new(0.4), {
			["Size"] = 33
		}):Play()
		v_u_3:Create(v_u_6, TweenInfo.new(0.4), {
			["FieldOfView"] = 60
		}):Play()
	else
		v_u_3:Create(v_u_4, TweenInfo.new(0.3), {
			["Size"] = 0
		}):Play()
		v_u_3:Create(v_u_6, TweenInfo.new(0.4), {
			["FieldOfView"] = 70
		}):Play()
		task.delay(0.3, function()
			-- upvalues: (ref) v_u_4
			v_u_4.Enabled = false
		end)
	end
end
local v_u_36 = {
	"Settings",
	"Index",
	"Rewards",
	"Inventory",
	"SellGUI",
	"Store",
	"TradeGUI",
	"Shop",
	"SkillShop",
	"Guild",
	"AcceptGUI"
}
function v1.CloseAllUI(_, p37)
	-- upvalues: (copy) v_u_2, (copy) v_u_36
	local v38 = v_u_2.LocalPlayer.PlayerGui
	for _, v39 in ipairs(v_u_36) do
		local v40 = v38:FindFirstChild(v39)
		if v40 then
			if not p37 or v40.Name ~= p37.Name then
				v40.Enabled = false
			end
		end
	end
end
return v1