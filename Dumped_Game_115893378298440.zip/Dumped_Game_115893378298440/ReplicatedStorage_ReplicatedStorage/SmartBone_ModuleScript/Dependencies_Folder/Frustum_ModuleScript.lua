-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = script.Parent
local v_u_2 = require(v1:WaitForChild("Config"))
local v_u_3 = require(v1:WaitForChild("Utilities"))
local v_u_56 = {
	["GetCFrames"] = function(p4, p5)
		debug.profilebegin("Frustum::GetCFrames")
		local v6 = p4.CFrame
		local v7 = v6.Position
		local v8 = v6.RightVector
		local v9 = v6.UpVector
		local v10 = p5 * 0.5
		local v11 = (p4.FieldOfView + 5) * 0.5 * 0.017453
		local v12 = math.tan(v11) * p5
		local v13 = v12 * (p4.ViewportSize.X / p4.ViewportSize.Y)
		local v14 = v6 * CFrame.new(0, 0, -p5)
		local v15 = v14 * Vector3.new(v13, v12, 0)
		local v16 = -v13
		local v17 = -v12
		local v18 = v14 * Vector3.new(v16, v17, 0)
		local v19 = -v12
		local v20 = v14 * Vector3.new(v13, v19, 0)
		local v21 = (v6 * CFrame.new(0, 0, -v10)):Inverse()
		local v22 = v9:Cross(v20 - v7).Unit
		local v23 = v9:Cross(v18 - v7).Unit
		local v24 = v8:Cross(v7 - v15).Unit
		local v25 = v8:Cross(v7 - v20).Unit
		debug.profileend()
		return v21, v13, v12, v10, v22, v23, v24, v25, v6
	end,
	["InViewFrustum"] = function(p26, p27, p28, p29, p30, p31, p32, p33, p34, p35)
		debug.profilebegin("Frustum::InViewFrustum")
		local v36 = p35.Position
		local v37 = p27 * p26
		if p28 < v37.X or (v37.X < -p28 or (p29 < v37.Y or (v37.Y < -p29 or (p30 < v37.Z or v37.Z < -p30)))) then
			debug.profileend()
			return false
		else
			local v38 = p26 - v36
			if p31:Dot(v38) < 0 or (p32:Dot(v38) > 0 or (p33:Dot(v38) < 0 or p34:Dot(v38) > 0)) then
				debug.profileend()
				return false
			else
				debug.profileend()
				return true
			end
		end
	end,
	["ObjectInFrustum"] = function(p39, p40, p41, p42, p43, p44, p45, p46, p47, p48)
		-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_56
		local v49 = p39.CFrame
		local v50 = p39.Size
		local v51 = v_u_2.FAR_PLANE * 0.5
		local v52 = p48.Position + p48.LookVector * v51
		local v53 = v_u_3.ClosestPointOnLine(v52, p48.LookVector, v51, v49.Position)
		local v54, v55 = v_u_3.ClosestPointInBox(v49, v50, v53)
		return v54 and true or (v_u_56.InViewFrustum(v55, p40, p41, p42, p43, p44, p45, p46, p47, p48) and true or false)
	end
}
return v_u_56