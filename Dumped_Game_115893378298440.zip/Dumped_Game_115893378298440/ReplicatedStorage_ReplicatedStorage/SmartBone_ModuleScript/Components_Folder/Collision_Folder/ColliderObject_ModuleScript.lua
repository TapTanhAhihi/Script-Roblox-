-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = require(script.Parent:WaitForChild("Collider"))
local v_u_2 = require(script.Parent.Parent.Parent:WaitForChild("Dependencies"):WaitForChild("Utilities")).SB_VERBOSE_LOG
local v_u_3 = {}
v_u_3.__index = v_u_3
function v_u_3.new(p4, p_u_5)
	-- upvalues: (copy) v_u_3
	local v6 = v_u_3
	local v_u_7 = setmetatable({
		["m_Object"] = p_u_5,
		["m_Awake"] = true,
		["m_LastSleepCycle"] = 0,
		["Destroyed"] = false,
		["Colliders"] = {}
	}, v6)
	v_u_7:m_LoadColliderTable(p4)
	v_u_7.DestroyConnection = p_u_5:GetPropertyChangedSignal("Parent"):Connect(function()
		-- upvalues: (copy) p_u_5, (copy) v_u_7
		if p_u_5.Parent == nil then
			v_u_7.Destroyed = true
		end
	end)
	return v_u_7
end
function v_u_3.m_LoadCollider(p8, p9)
	-- upvalues: (copy) v_u_1
	local v10 = p9.ScaleX
	local v11 = p9.ScaleY
	local v12 = p9.ScaleZ
	local v13 = Vector3.new(v10, v11, v12)
	local v14 = p9.OffsetX
	local v15 = p9.OffsetY
	local v16 = p9.OffsetZ
	local v17 = Vector3.new(v14, v15, v16)
	local v18 = p9.RotationX
	local v19 = p9.RotationY
	local v20 = p9.RotationZ
	local v21 = Vector3.new(v18, v19, v20)
	local v22 = v_u_1.new()
	v22.Scale = v13
	v22.Offset = v17
	v22.Rotation = v21
	v22.Type = p9.Type
	v22:SetObject(p8.m_Object)
	local v23 = p8.Colliders
	table.insert(v23, v22)
end
function v_u_3.m_LoadColliderTable(p24, p25)
	for _, v26 in p25 do
		p24:m_LoadCollider(v26)
	end
end
function v_u_3.GetObject(p27)
	return p27.m_Object
end
function v_u_3.GetCollisions(p28, p29, p30)
	debug.profilebegin("ColliderObject::GetCollisions")
	if not p28.m_Object then
		debug.profileend()
		return {}
	end
	if #p28.Colliders == 0 then
		debug.profileend()
		return {}
	end
	debug.profilebegin("Sleep Cycle")
	if os.clock() - p28.m_LastSleepCycle >= 0.2 then
		p28.m_LastSleepCycle = os.clock()
		if p28.m_Object:IsDescendantOf(workspace) then
			p28.m_Awake = true
		else
			p28.m_Awake = false
		end
	end
	debug.profileend()
	if not p28.m_Awake then
		debug.profileend()
		return {}
	end
	debug.profilebegin("Determine Collisions")
	local v31 = {}
	for _, v32 in p28.Colliders do
		debug.profilebegin("Determine collision")
		local v33, v34, v35 = v32:GetClosestPoint(p29, p30)
		debug.profileend()
		if v33 then
			table.insert(v31, {
				["ClosestPoint"] = v34,
				["Normal"] = v35
			})
		end
	end
	debug.profileend()
	debug.profileend()
	return v31
end
function v_u_3.Step(p36)
	debug.profilebegin("ColliderObject::Step")
	for _, v37 in p36.Colliders do
		v37:Step()
	end
	debug.profileend()
end
function v_u_3.DrawDebug(p38, p39, p40, p41, p42)
	for _, v43 in p38.Colliders do
		v43:DrawDebug(p38, p39, p40, p41, p42)
		v43.InNarrowphase = false
	end
end
function v_u_3.Destroy(p44)
	-- upvalues: (copy) v_u_2
	task.synchronize()
	v_u_2((("Collider object destroying, object: %*"):format(p44.m_Object)))
	p44.DestroyConnection:Disconnect()
	if #p44.Colliders ~= 0 then
		for _, v45 in p44.Colliders do
			v45:Destroy()
		end
	end
	setmetatable(p44, nil)
	task.desynchronize()
end
return v_u_3