-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = Vector3.new(1, 0, 0.3)
local v2 = 20
local v3 = require(script.WindLines)
local v4 = require(script.WindShake)
v3:Init({
	["Direction"] = v1,
	["Speed"] = v2,
	["Lifetime"] = 1.5,
	["SpawnRate"] = 11
})
v4:SetDefaultSettings({
	["WindSpeed"] = v2,
	["WindDirection"] = v1,
	["WindPower"] = 0.5
})
v4:Init({
	["MatchWorkspaceWind"] = true
})
script.WindShake:GetAttribute("WindSpeed")
script.WindShake:GetAttribute("WindDirection")
script.WindShake:GetAttribute("WindPower")