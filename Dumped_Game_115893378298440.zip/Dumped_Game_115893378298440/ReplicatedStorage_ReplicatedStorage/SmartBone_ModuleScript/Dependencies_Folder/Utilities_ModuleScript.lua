-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = game:GetService("HttpService")
local v_u_2 = require(script.Parent:WaitForChild("Config"))
local v_u_3 = require(script.Parent:WaitForChild("DefaultObjectSettings"))
local v_u_4 = {
	["Block"] = "Box",
	["Ball"] = "Sphere",
	["Capsule"] = "Capsule",
	["Sphere"] = "Sphere",
	["Box"] = "Box",
	["Cylinder"] = "Cylinder"
}
local v_u_91 = {
	["LogIndent"] = 0,
	["GetRotationBetween"] = function(p5, p6)
		local v7 = p5:Dot(p6)
		local v8 = p5:Cross(p6).Magnitude
		local v9 = math.atan2(v8, v7)
		local v10 = p5:Cross(p6)
		local v11 = v10.Magnitude == 0 and Vector3.new(-0, -1, -0) or v10.Unit
		return CFrame.fromAxisAngle(v11, v9)
	end,
	["GetCFrameAxis"] = function(p12, p13)
		local v14, v15, v16 = p12:ToEulerAnglesXYZ()
		if p13 == "X" then
			return v14
		elseif p13 == "Y" then
			return v15
		elseif p13 == "Z" then
			return v16
		else
			return nil
		end
	end,
	["GatherObjectSettings"] = function(p17)
		-- upvalues: (copy) v_u_3
		local v18 = {}
		for v19, v20 in v_u_3 do
			local v21 = p17:GetAttribute(v19)
			if v21 ~= nil then
				local v22 = typeof(v20)
				local v23
				if typeof(v21) == v22 then
					v23 = true
				else
					warn((("[SmartBone][Object] Expected attribute %* on %* to be of type %*, got type %*"):format(v19, p17.Name, v22, (typeof(v21)))))
					v23 = false
				end
				if not v23 then
					v21 = nil
				end
			end
			v18[v19] = v21 == nil and v20 and v20 or v21
		end
		return v18
	end,
	["GatherBoneSettings"] = function(p24)
		local v25 = p24:GetAttribute("XAxisLocked") or false
		local v26 = p24:GetAttribute("YAxisLocked") or false
		local v27 = p24:GetAttribute("ZAxisLocked") or false
		local v28 = p24:GetAttribute("XAxisLimits") or NumberRange.new((-1 / 0), (1 / 0))
		local v29 = p24:GetAttribute("YAxisLimits") or NumberRange.new((-1 / 0), (1 / 0))
		local v30 = p24:GetAttribute("ZAxisLimits") or NumberRange.new((-1 / 0), (1 / 0))
		local v31 = p24:GetAttribute("Radius") or 0.25
		local v32 = p24:GetAttribute("RotationLimit") or 180
		local v33 = p24:GetAttribute("Force") or "\194\172"
		local v34 = p24:GetAttribute("Gravity") or "\194\172"
		if typeof(v25) ~= "boolean" then
			warn((("[SmartBone][Bone] Expected attribute XAxisLocked on %* to be of type boolean, got type %*"):format(p24.Name, (typeof(v25)))))
		end
		if typeof(v26) ~= "boolean" then
			warn((("[SmartBone][Bone] Expected attribute YAxisLocked on %* to be of type boolean, got type %*"):format(p24.Name, (typeof(v26)))))
		end
		if typeof(v27) ~= "boolean" then
			warn((("[SmartBone][Bone] Expected attribute ZAxisLocked on %* to be of type boolean, got type %*"):format(p24.Name, (typeof(v27)))))
		end
		if typeof(v28) ~= "NumberRange" then
			warn((("[SmartBone][Bone] Expected attribute XAxisLimits on %* to be of type NumberRange, got type %*"):format(p24.Name, (typeof(v28)))))
		end
		if typeof(v29) ~= "NumberRange" then
			warn((("[SmartBone][Bone] Expected attribute YAxisLimits on %* to be of type NumberRange, got type %*"):format(p24.Name, (typeof(v29)))))
		end
		if typeof(v30) ~= "NumberRange" then
			warn((("[SmartBone][Bone] Expected attribute ZAxisLimits on %* to be of type NumberRange, got type %*"):format(p24.Name, (typeof(v30)))))
		end
		if typeof(v31) ~= "number" then
			warn((("[SmartBone][Bone] Expected attribute Radius on %* to be of type number, got type %*"):format(p24.Name, (typeof(v31)))))
		end
		if typeof(v32) ~= "number" then
			warn((("[SmartBone][Bone] Expected attribute RotationLimit on %* to be of type number, got type %*"):format(p24.Name, (typeof(v32)))))
		end
		if v33 ~= "\194\172" and typeof(v33) ~= "Vector3" then
			warn((("[SmartBone][Bone] Expected attribute Force on %* to be of type Vector3, got type %*"):format(p24.Name, (typeof(v33)))))
		end
		if v33 ~= "\194\172" and typeof(v34) ~= "Vector3" then
			warn((("[SmartBone][Bone] Expected attribute Gravity on %* to be of type Vector3, got type %*"):format(p24.Name, (typeof(v34)))))
		end
		return {
			["AxisLocked"] = { v25, v26, v27 },
			["XAxisLimits"] = v28,
			["YAxisLimits"] = v29,
			["ZAxisLimits"] = v30,
			["RotationLimit"] = v32,
			["Radius"] = v31,
			["Force"] = v33,
			["Gravity"] = v34
		}
	end,
	["ClosestPointOnLine"] = function(p35, p36, p37, p38)
		local v39 = (p38 - p35):Dot(p36)
		local v40 = -p37
		return p35 + p36 * math.clamp(v39, v40, p37)
	end,
	["ClosestPointInBox"] = function(p41, p42, p43)
		local v44 = p41:PointToObjectSpace(p43)
		local v45 = p42.X
		local v46 = p42.X
		local v47 = p42.Z
		local v48 = v44.X
		local v49 = v44.Y
		local v50 = v44.Z
		if v44 == v44 and p42 == p42 then
			local v51 = -v45 * 0.5
			local v52 = v45 * 0.5
			local v53 = math.clamp(v48, v51, v52)
			local v54 = -v46 * 0.5
			local v55 = v46 * 0.5
			local v56 = math.clamp(v49, v54, v55)
			local v57 = -v47 * 0.5
			local v58 = v47 * 0.5
			local v59 = math.clamp(v50, v57, v58)
			if v53 == v48 and (v56 == v49 and v59 == v50) then
				local v60 = v48 - v45 * 0.5
				local v61 = v49 - v46 * 0.5
				local v62 = v50 - v47 * 0.5
				local v63 = -v48 - v45 * 0.5
				local v64 = -v49 - v46 * 0.5
				local v65 = -v50 - v47 * 0.5
				local v66 = math.max(v60, v61, v62, v63, v64, v65)
				if v66 == v60 then
					local v67 = v45 * 0.5
					return true, p41 * Vector3.new(v67, v49, v50), p41.XVector
				elseif v66 == v61 then
					local v68 = v46 * 0.5
					return true, p41 * Vector3.new(v48, v68, v50), p41.YVector
				elseif v66 == v62 then
					local v69 = v47 * 0.5
					return true, p41 * Vector3.new(v48, v49, v69), p41.ZVector
				elseif v66 == v63 then
					local v70 = -v45 * 0.5
					return true, p41 * Vector3.new(v70, v49, v50), -p41.XVector
				elseif v66 == v64 then
					local v71 = -v46 * 0.5
					return true, p41 * Vector3.new(v48, v71, v50), -p41.YVector
				elseif v66 == v65 then
					local v72 = -v47 * 0.5
					return true, p41 * Vector3.new(v48, v49, v72), -p41.ZVector
				else
					warn("CLOSEST POINT ON BOX FAIL")
					return false, Vector3.new(0, 0, 0), Vector3.new(0, 1, 0)
				end
			else
				local v73 = p41 * Vector3.new(v53, v56, v59)
				return false, v73, (p43 - v73).unit
			end
		else
			return false, p41.Position, Vector3.new(0, 1, 0)
		end
	end,
	["GetCollider"] = function(p74)
		-- upvalues: (copy) v_u_1, (copy) v_u_4
		local v75 = p74:FindFirstChild("self.Collider")
		local v76
		if v75 and v75:IsA("ModuleScript") then
			local v_u_77 = require(v75)
			local v_u_78 = nil
			pcall(function()
				-- upvalues: (ref) v_u_78, (ref) v_u_1, (copy) v_u_77
				v_u_78 = v_u_1:JSONDecode(v_u_77)
			end)
			v76 = v_u_78
		else
			v76 = nil
		end
		return v76 or {
			{
				["Type"] = v_u_4[p74:GetAttribute("ColliderShape") or (not p74:IsA("Part") and "Box" or p74.Shape.Name)] or "Box",
				["ScaleX"] = 1,
				["ScaleY"] = 1,
				["ScaleZ"] = 1,
				["OffsetX"] = 0,
				["OffsetY"] = 0,
				["OffsetZ"] = 0,
				["RotationX"] = 0,
				["RotationY"] = 0,
				["RotationZ"] = 0
			}
		}
	end,
	["SB_INDENT_LOG"] = function()
		-- upvalues: (copy) v_u_91
		local v79 = v_u_91
		v79.LogIndent = v79.LogIndent + 1
	end,
	["SB_UNINDENT_LOG"] = function()
		-- upvalues: (copy) v_u_91
		local v80 = v_u_91
		v80.LogIndent = v80.LogIndent - 1
		local v81 = v_u_91
		local v82 = v_u_91.LogIndent
		v81.LogIndent = math.max(v82, 0)
	end,
	["SB_ASSERT_CB"] = function(p83, p84, ...)
		if p83 == false or p83 == nil then
			p84(...)
		end
	end,
	["SB_VERBOSE_LOG"] = function(p85)
		-- upvalues: (copy) v_u_2, (copy) v_u_91
		if v_u_2.LOG_VERBOSE then
			local v86 = string.rep("    ", v_u_91.LogIndent)
			print((("%*[SmartBone][Log]: %*"):format(v86, p85)))
		end
	end,
	["SB_VERBOSE_WARN"] = function(p87)
		-- upvalues: (copy) v_u_2, (copy) v_u_91
		if v_u_2.LOG_VERBOSE then
			local v88 = string.rep("    ", v_u_91.LogIndent)
			warn((("%*[SmartBone][Warn]: %*"):format(v88, p87)))
		end
	end,
	["SB_VERBOSE_ERROR"] = function(p89)
		-- upvalues: (copy) v_u_2, (copy) v_u_91
		if v_u_2.LOG_VERBOSE then
			local v90 = string.rep("    ", v_u_91.LogIndent)
			error((("%*[SmartBone][Error]: %*"):format(v90, p89)))
		end
	end
}
return v_u_91