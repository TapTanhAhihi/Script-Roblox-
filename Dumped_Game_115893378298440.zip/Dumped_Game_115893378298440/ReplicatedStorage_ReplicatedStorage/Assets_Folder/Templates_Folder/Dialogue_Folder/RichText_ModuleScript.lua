-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = {}
local v_u_2 = {
	["Color"] = "TextColor3",
	["StrokeColor"] = "TextStrokeColor3",
	["ImageColor"] = "ImageColor3"
}
v_u_1.ColorShortcuts = {}
v_u_1.ColorShortcuts.Purple = Color3.new(0.721569, 0.439216, 1)
v_u_1.ColorShortcuts.Black = Color3.new(0, 0, 0)
v_u_1.ColorShortcuts.Red = Color3.new(1, 0.4, 0.4)
v_u_1.ColorShortcuts.Green = Color3.new(0.4, 1, 0.4)
v_u_1.ColorShortcuts.Blue = Color3.new(0.4, 0.4, 1)
v_u_1.ColorShortcuts.Cyan = Color3.new(0.4, 0.85, 1)
v_u_1.ColorShortcuts.Orange = Color3.new(1, 0.5, 0.2)
v_u_1.ColorShortcuts.Yellow = Color3.new(1, 0.9, 0.2)
v_u_1.ColorShortcuts.Grey = Color3.new(0.505882, 0.505882, 0.505882)
v_u_1.ColorShortcuts.White = Color3.new(1, 1, 1)
v_u_1.ColorShortcuts.PastelYellow = Color3.new(1, 0.898039, 0.313725)
v_u_1.ColorShortcuts.NiceGreen = Color3.new(0.333333, 1, 0.498039)
v_u_1.ImageShortcuts = {}
v_u_1.ImageShortcuts.Eggplant = 639588687
v_u_1.ImageShortcuts.Thinking = 955646496
v_u_1.ImageShortcuts.Sad = 947900188
v_u_1.ImageShortcuts.Happy = 414889555
v_u_1.ImageShortcuts.Despicable = 711674643
local v_u_3 = {
	["ContainerHorizontalAlignment"] = "Left",
	["ContainerVerticalAlignment"] = "Top",
	["TextYAlignment"] = "Center",
	["TextScaled"] = false,
	["TextScaleRelativeTo"] = "Frame",
	["TextScale"] = 1,
	["TextSize"] = 20
}
if game:GetService("UserInputService").TouchEnabled then
	v_u_3.TextSize = 11
end
v_u_3.Font = "FredokaOne"
v_u_3.TextColor3 = "White"
v_u_3.TextStrokeColor3 = "Black"
v_u_3.TextTransparency = 0
v_u_3.TextStrokeTransparency = 0.85
v_u_3.BackgroundTransparency = 1
v_u_3.BorderSizePixel = 0
v_u_3.ImageColor3 = "White"
v_u_3.ImageTransparency = 0
v_u_3.ImageRectOffset = "0,0"
v_u_3.ImageRectSize = "0,0"
v_u_3.AnimateStepTime = 0
v_u_3.AnimateStepGrouping = "Letter"
v_u_3.AnimateStepFrequency = 4
v_u_3.AnimateYield = 0
v_u_3.AnimateStyle = "Wiggle"
v_u_3.AnimateStyleTime = 0.5
v_u_3.AnimateStyleNumPeriods = 1
v_u_3.AnimateStyleAmplitude = 0.3
local v_u_29 = {
	["Appear"] = function(p4)
		p4.Visible = true
	end,
	["Fade"] = function(p5, p6, p7)
		p5.Visible = true
		if p5:IsA("TextLabel") then
			p5.TextTransparency = 1 - p6 * (1 - p7.TextTransparency)
		elseif p5:IsA("ImageLabel") then
			p5.ImageTransparency = 1 - p6 * (1 - p7.ImageTransparency)
		end
	end,
	["Wiggle"] = function(p8, p9, p10)
		p8.Visible = true
		local v11 = p10.InitialSize.Y.Offset * (1 - p9) * p10.AnimateStyleAmplitude
		local v12 = p10.InitialPosition
		local v13 = UDim2.new
		local v14 = p9 * 3.141592653589793 * 2 * p10.AnimateStyleNumPeriods
		p8.Position = v12 + v13(0, 0, 0, math.sin(v14) * v11 / 2)
	end,
	["Swing"] = function(p15, p16, p17)
		p15.Visible = true
		local v18 = 90 * (1 - p16) * p17.AnimateStyleAmplitude
		local v19 = p16 * 3.141592653589793 * 2 * p17.AnimateStyleNumPeriods
		p15.Rotation = math.sin(v19) * v18
	end,
	["Spin"] = function(p20, p21, p22)
		p20.Visible = true
		p20.Position = p22.InitialPosition + UDim2.new(0, p22.InitialSize.X.Offset / 2, 0, p22.InitialSize.Y.Offset / 2)
		p20.AnchorPoint = Vector2.new(0.5, 0.5)
		p20.Rotation = p21 * p22.AnimateStyleNumPeriods * 360
	end,
	["Rainbow"] = function(p23, p24, p25)
		p23.Visible = true
		local v26 = Color3.fromHSV(p24 * p25.AnimateStyleNumPeriods % 1, 1, 1)
		if p23:IsA("TextLabel") then
			local v27 = getColorFromString(p25.TextColor3)
			p23.TextColor3 = Color3.new(v26.r + p24 * (v27.r - v26.r), v26.g + p24 * (v27.g - v26.g), v26.b + p24 * (v27.b - v26.b))
		else
			local v28 = getColorFromString(p25.ImageColor3)
			p23.ImageColor3 = Color3.new(v26.r + p24 * (v28.r - v26.r), v26.g + p24 * (v28.g - v26.g), v26.b + p24 * (v28.b - v26.b))
		end
	end
}
local v_u_30 = game:GetService("TextService")
local v_u_31 = game:GetService("RunService")
local v_u_32 = 0
function getLayerCollector(p33)
	if p33 then
		if p33:IsA("LayerCollector") then
			return p33
		elseif p33 and p33.Parent then
			return getLayerCollector(p33.Parent)
		else
			return nil
		end
	else
		return nil
	end
end
function shallowCopy(p34)
	local v35 = {}
	for v36, v37 in pairs(p34) do
		v35[v36] = v37
	end
	return v35
end
function getColorFromString(p38)
	-- upvalues: (copy) v_u_1
	if v_u_1.ColorShortcuts[p38] then
		return v_u_1.ColorShortcuts[p38]
	end
	local v39, v40, v41 = p38:match("(%d+),(%d+),(%d+)")
	return Color3.new(v39 / 255, v40 / 255, v41 / 255)
end
function getVector2FromString(p42)
	local v43, v44 = p42:match("(%d+),(%d+)")
	return Vector2.new(v43, v44)
end
function setHorizontalAlignment(p45, p46)
	if p46 == "Left" then
		p45.AnchorPoint = Vector2.new(0, 0)
		p45.Position = UDim2.new(0, 0, 0, 0)
		return
	elseif p46 == "Center" then
		p45.AnchorPoint = Vector2.new(0.5, 0)
		p45.Position = UDim2.new(0.5, 0, 0, 0)
	elseif p46 == "Right" then
		p45.AnchorPoint = Vector2.new(1, 0)
		p45.Position = UDim2.new(1, 0, 0, 0)
	end
end
function v_u_1.New(_, p_u_47, p48, p49, p50, p51)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_30, (copy) v_u_1, (ref) v_u_32, (copy) v_u_31, (copy) v_u_29
	for _, v52 in pairs(p_u_47:GetChildren()) do
		v52:Destroy()
	end
	local v_u_53 = p50 == nil and true or p50
	local v_u_54 = {}
	local v_u_55 = {}
	if p51 then
		p48 = p51.Text
		p49 = p51.StartingProperties
	end
	local v_u_56 = {}
	local v_u_57 = {}
	local v_u_58 = {}
	local v_u_59 = 0
	local v_u_60 = false
	local v_u_61 = Instance.new("TextLabel")
	local v_u_62 = Instance.new("ImageLabel")
	local v_u_63 = getLayerCollector(p_u_47)
	v_u_61.AutoLocalize = true
	local v_u_64 = nil
	local v_u_65 = nil
	local function v_u_69(p66, p67)
		-- upvalues: (ref) v_u_2, (copy) v_u_55, (ref) v_u_54, (ref) v_u_64, (copy) v_u_56, (ref) v_u_3, (ref) v_u_65
		local v68 = v_u_2[p66] or p66
		if p67 == "/" then
			if v_u_55[v68] then
				p67 = v_u_55[v68]
			else
				warn("Attempt to default <" .. v68 .. "> to value with no default")
			end
		end
		if tonumber(p67) then
			p67 = tonumber(p67)
		elseif p67 == "false" or p67 == "true" then
			p67 = p67 == "true"
		end
		v_u_54[v68] = p67
		if not v_u_64(v68, p67) then
			if v68 == "ContainerHorizontalAlignment" and v_u_56[#v_u_56] then
				setHorizontalAlignment(v_u_56[#v_u_56].Container, p67)
			elseif not v_u_3[v68] then
				if v68 ~= "Img" then
					return false
				end
				v_u_65(p67)
			end
		end
		return true
	end
	v_u_64 = function(p_u_70, p71, p72)
		-- upvalues: (copy) v_u_61, (copy) v_u_62
		local v_u_73 = nil
		local v74 = false
		for _, v_u_75 in pairs(p72 and { p72 } or { v_u_61, v_u_62 }) do
			if pcall(function()
				-- upvalues: (ref) v_u_73, (copy) v_u_75, (copy) p_u_70
				local v76 = v_u_75[p_u_70]
				v_u_73 = typeof(v76)
			end) then
				if v_u_73 == "Color3" then
					v_u_75[p_u_70] = getColorFromString(p71)
				elseif v_u_73 == "Vector2" then
					v_u_75[p_u_70] = getVector2FromString(p71)
				elseif p_u_70 == "TextXAlignment" and type(p71) == "string" then
					v_u_75[p_u_70] = p71 == "Left" and Enum.TextXAlignment.Left or (p71 == "Right" and Enum.TextXAlignment.Right or Enum.TextXAlignment.Center)
				elseif p_u_70 == "TextYAlignment" and type(p71) == "string" then
					v_u_75[p_u_70] = p71 == "Top" and Enum.TextYAlignment.Top or (p71 == "Bottom" and Enum.TextYAlignment.Bottom or Enum.TextYAlignment.Center)
				else
					v_u_75[p_u_70] = p71
				end
				v74 = true
			end
		end
		return v74
	end
	local v_u_77 = v_u_64
	for v78, v79 in pairs(v_u_3) do
		v_u_69(v78, v79)
		v_u_55[v_u_2[v78] or v78] = v_u_54[v_u_2[v78] or v78]
	end
	for v80, v81 in pairs(p49 or {}) do
		if v80 ~= "SingleLabel" and v80 ~= "TypewriterDelay" then
			v_u_69(v80, v81)
			v_u_55[v_u_2[v80] or v80] = v_u_54[v_u_2[v80] or v80]
		end
	end
	local v82 = p49 and p49.SingleLabel == true and true or false
	if v82 then
		v_u_54.AnimateStepGrouping = "All"
	end
	if p51 then
		v_u_54 = p51.OverflowPickupProperties
		for v83, v84 in pairs(v_u_54) do
			v_u_69(v83, v84)
		end
	end
	local v_u_85 = 0
	local function v_u_94()
		-- upvalues: (copy) v_u_56, (ref) v_u_85, (ref) v_u_53, (ref) v_u_54, (copy) v_u_63, (copy) p_u_47, (ref) v_u_60, (copy) v_u_57, (ref) v_u_59
		local v86 = v_u_56[#v_u_56]
		if v86 then
			v_u_85 = v_u_85 + v86.Size.Y.Offset
			if not v_u_53 then
				local v87 = v_u_85
				local v88
				if v_u_54.TextScaled == true then
					local v89 = nil
					if v_u_54.TextScaleRelativeTo == "Screen" then
						v89 = v_u_63.AbsoluteSize.Y
					elseif v_u_54.TextScaleRelativeTo == "Frame" then
						v89 = p_u_47.AbsoluteSize.Y
					end
					local v90 = v_u_54.TextScale * v89
					v88 = math.min(v90, 100)
				else
					v88 = v_u_54.TextSize
				end
				if v87 + v88 > p_u_47.AbsoluteSize.Y then
					v_u_60 = true
					return
				end
			end
		end
		local v91 = Instance.new("Frame")
		v91.Name = string.format("Line%03d", #v_u_56 + 1)
		v91.Size = UDim2.new(0, 0, 0, 0)
		v91.BackgroundTransparency = 1
		local v92 = Instance.new("Frame", v91)
		v92.Name = "Container"
		v92.Size = UDim2.new(0, 0, 0, 0)
		v92.BackgroundTransparency = 1
		setHorizontalAlignment(v92, v_u_54.ContainerHorizontalAlignment)
		v91.Parent = p_u_47
		local v93 = v_u_56
		table.insert(v93, v91)
		v_u_57[#v_u_56] = {}
		v_u_59 = 0
	end
	v_u_94()
	local function v_u_106(p95, p96, p97, p98)
		-- upvalues: (copy) v_u_56, (ref) v_u_54, (ref) v_u_59, (copy) p_u_47, (copy) v_u_57, (copy) v_u_94, (copy) v_u_58
		local v99 = v_u_56[#v_u_56]
		local v100 = v_u_54.TextYAlignment
		local v101 = tostring(v100)
		if v101 == "Top" then
			p95.Position = UDim2.new(0, v_u_59, 0, 0)
			p95.AnchorPoint = Vector2.new(0, 0)
		elseif v101 == "Center" then
			p95.Position = UDim2.new(0, v_u_59, 0.5, 0)
			p95.AnchorPoint = Vector2.new(0, 0.5)
		elseif v101 == "Bottom" then
			p95.Position = UDim2.new(0, v_u_59, 1, 0)
			p95.AnchorPoint = Vector2.new(0, 1)
		end
		v_u_59 = v_u_59 + p97
		if v_u_59 > p_u_47.AbsoluteSize.X and v_u_59 ~= p97 then
			p95:Destroy()
			local v102 = v_u_57[#v_u_56][#v_u_57[#v_u_56]]
			if v102:IsA("TextLabel") and v102.Text == " " then
				v99.Container.Size = UDim2.new(0, v_u_59 - p97 - v102.Size.X.Offset, 1, 0)
				v102:Destroy()
				table.remove(v_u_57[#v_u_56])
			end
			v_u_94()
			p98()
		else
			p95.Size = UDim2.new(0, p97, 0, p96)
			v99.Container.Size = UDim2.new(0, v_u_59, 1, 0)
			local v103 = UDim2.new
			local v104 = v99.Size.Y.Offset
			v99.Size = v103(1, 0, 0, (math.max(v104, p96)))
			p95.Name = string.format("Group%03d", #v_u_57[#v_u_56] + 1)
			p95.Parent = v99.Container
			local v105 = v_u_57[#v_u_56]
			table.insert(v105, p95)
			v_u_58[p95] = shallowCopy(v_u_54)
			v_u_58[p95].InitialSize = p95.Size
			v_u_58[p95].InitialPosition = p95.Position
			v_u_58[p95].InitialAnchorPoint = p95.AnchorPoint
			v_u_54.AnimateYield = 0
		end
	end
	local function v_u_120(p_u_107)
		-- upvalues: (copy) v_u_94, (ref) v_u_59, (ref) v_u_54, (copy) v_u_63, (copy) p_u_47, (ref) v_u_30, (copy) v_u_61, (copy) v_u_58, (ref) v_u_106, (ref) v_u_60, (ref) v_u_120
		if p_u_107 == "\n" then
			v_u_94()
			return
		elseif p_u_107 ~= " " or v_u_59 ~= 0 then
			local v108
			if v_u_54.TextScaled == true then
				local v109 = nil
				if v_u_54.TextScaleRelativeTo == "Screen" then
					v109 = v_u_63.AbsoluteSize.Y
				elseif v_u_54.TextScaleRelativeTo == "Frame" then
					v109 = p_u_47.AbsoluteSize.Y
				end
				local v110 = v_u_54.TextScale * v109
				v108 = math.min(v110, 100)
			else
				v108 = v_u_54.TextSize
			end
			local v111 = v_u_30:GetTextSize(p_u_107, v108, v_u_61.Font, Vector2.new(v_u_63.AbsoluteSize.X, v108)).X
			local v112 = v_u_61:Clone()
			v112.TextScaled = false
			v112.TextSize = v108
			v112.Text = p_u_107
			v112.TextTransparency = 1
			v112.TextStrokeTransparency = 1
			v112.TextWrapped = false
			local v113 = 1
			local v114 = 0
			for v115, v116 in utf8.graphemes(p_u_107) do
				local v117 = string.sub(p_u_107, v115, v116)
				local v118 = v_u_30:GetTextSize(v117, v108, v_u_61.Font, Vector2.new(v_u_63.AbsoluteSize.X, v108)).X
				local v119 = v_u_61:Clone()
				v119.Text = v117
				v119.TextScaled = false
				v119.TextSize = v108
				v119.Position = UDim2.new(0, v114, 0, 0)
				v119.Size = UDim2.new(0, v118 + 1, 0, v108)
				v119.Name = string.format("Char%03d", v113)
				v119.Parent = v112
				v119.Visible = false
				v_u_58[v119] = shallowCopy(v_u_54)
				v_u_58[v119].InitialSize = v119.Size
				v_u_58[v119].InitialPosition = v119.Position
				v_u_58[v119].InitialAnchorPoint = v119.AnchorPoint
				v114 = v114 + v118
				v113 = v113 + 1
			end
			v_u_106(v112, v108, v111, function()
				-- upvalues: (ref) v_u_60, (ref) v_u_120, (copy) p_u_107
				if not v_u_60 then
					v_u_120(p_u_107)
				end
			end)
		end
	end
	v_u_65 = function(p_u_121)
		-- upvalues: (ref) v_u_54, (copy) v_u_63, (copy) p_u_47, (copy) v_u_62, (ref) v_u_1, (ref) v_u_106, (ref) v_u_60, (ref) v_u_65
		local v122
		if v_u_54.TextScaled == true then
			local v123 = nil
			if v_u_54.TextScaleRelativeTo == "Screen" then
				v123 = v_u_63.AbsoluteSize.Y
			elseif v_u_54.TextScaleRelativeTo == "Frame" then
				v123 = p_u_47.AbsoluteSize.Y
			end
			local v124 = v_u_54.TextScale * v123
			v122 = math.min(v124, 100)
		else
			v122 = v_u_54.TextSize
		end
		local v125 = v_u_62:Clone()
		if v_u_1.ImageShortcuts[p_u_121] then
			local v126 = v_u_1.ImageShortcuts[p_u_121]
			v125.Image = typeof(v126) == "number" and "rbxassetid://" .. v_u_1.ImageShortcuts[p_u_121] or v_u_1.ImageShortcuts[p_u_121]
		else
			v125.Image = "rbxassetid://" .. p_u_121
		end
		v125.Size = UDim2.new(0, v122, 0, v122)
		v125.Visible = false
		v_u_106(v125, v122, v122, function()
			-- upvalues: (ref) v_u_60, (ref) v_u_65, (copy) p_u_121
			if not v_u_60 then
				v_u_65(p_u_121)
			end
		end)
	end
	local function v131(p127)
		-- upvalues: (ref) v_u_69, (ref) v_u_120
		for _, v128 in pairs(p127) do
			local v129, v130 = string.match(v128, "<(.+)=(.+)>")
			if v129 and v130 then
				if not v_u_69(v129, v130) then
					warn("Could not apply markup: ", v128)
				end
			else
				v_u_120(v128)
			end
		end
	end
	local v132 = 1
	local v133 = #(p48 or "")
	local v134 = {}
	local v135
	if v82 then
		local v136 = (p48 or ""):gsub("<[^>]+>", " ")
		local v137 = v136:gsub("%s+", " "):match("^%s*(.-)%s*$") or v136
		local v138 = #v137 == 0 and " " or v137
		local v139
		if p49 then
			v139 = p49.TypewriterDelay
		else
			v139 = p49
		end
		local v140 = v139 == nil and 0.03 or v139
		local v141 = v_u_60
		local v142 = {}
		for v143, v144 in utf8.graphemes(v138) do
			local v145 = string.sub(v138, v143, v144)
			table.insert(v142, v145)
		end
		local v146 = v_u_56[1]
		local v147
		if v_u_54.TextScaled == true then
			local v148 = nil
			if v_u_54.TextScaleRelativeTo == "Screen" then
				v148 = v_u_63.AbsoluteSize.Y
			elseif v_u_54.TextScaleRelativeTo == "Frame" then
				v148 = p_u_47.AbsoluteSize.Y
			end
			local v149 = v_u_54.TextScale * v148
			v147 = math.min(v149, 100)
		else
			v147 = v_u_54.TextSize
		end
		local v150 = p_u_47.AbsoluteSize.X
		local v151 = math.max(v150, 10)
		local v152 = v_u_30:GetTextSize(v138, v147, v_u_61.Font, Vector2.new(v151, 10000))
		local v153 = v_u_61:Clone()
		v153.AutoLocalize = true
		v153.Text = v140 and v140 > 0 and "" or v138
		v153.TextWrapped = true
		v153.TextScaled = false
		v153.TextSize = v147
		v153.TextTransparency = 0
		v153.TextStrokeTransparency = v_u_54.TextStrokeTransparency
		local v154 = UDim2.new
		local v155 = v152.Y
		v153.Size = v154(1, 0, 0, (math.max(v155, v147)))
		v153.Position = UDim2.new(0, 0, 0, 0)
		v153.AnchorPoint = Vector2.new(0, 0)
		v153.Name = "Group001"
		v_u_77("Font", v_u_54.Font, v153)
		v_u_77("TextColor3", v_u_54.TextColor3, v153)
		v_u_77("TextStrokeColor3", v_u_54.TextStrokeColor3, v153)
		local v156 = v_u_54.TextXAlignment or "Left"
		v153.TextXAlignment = v156 == "Left" and Enum.TextXAlignment.Left or (v156 == "Right" and Enum.TextXAlignment.Right or Enum.TextXAlignment.Center)
		local v157 = v_u_54.TextYAlignment or "Top"
		v153.TextYAlignment = v157 == "Top" and Enum.TextYAlignment.Top or (v157 == "Bottom" and Enum.TextYAlignment.Bottom or Enum.TextYAlignment.Center)
		v153.Visible = false
		v153.Parent = v146.Container
		local v158 = v_u_57[1]
		table.insert(v158, v153)
		v_u_58[v153] = shallowCopy(v_u_54)
		v_u_58[v153].InitialSize = v153.Size
		v_u_58[v153].InitialPosition = v153.Position
		v_u_58[v153].InitialAnchorPoint = v153.AnchorPoint
		if v140 and (v140 > 0 and #v142 > 0) then
			v_u_58[v153].TypewriterGraphemes = v142
			v_u_58[v153].TypewriterDelay = v140
		end
		v146.Container.Size = UDim2.new(1, 0, 0, v152.Y)
		v146.Size = UDim2.new(1, 0, 0, v152.Y)
		v135 = v133 + 1
	else
		if p51 then
			v132 = p51.OverflowPickupIndex
		end
		while true do
			if not v132 or v132 > v133 then
				v135 = v132
				break
			end
			local v159
			v135, v159 = string.find(p48, "<.->", v132)
			local v160, v161 = string.find(p48, "[ \t\n]", v132)
			local v162
			if v135 and (v159 and (not v160 or v135 < v160)) then
				v162 = nil
			else
				v135 = v160 or v133 + 1
				v159 = v161 or v133 + 1
				v162 = true
			end
			local v163
			if v132 < v135 then
				local v164 = v135 - 1
				v163 = string.sub(p48, v132, v164) or nil
			else
				v163 = nil
			end
			local v165
			if v135 <= v133 then
				v165 = string.sub(p48, v135, v159) or nil
			else
				v165 = nil
			end
			table.insert(v134, v163)
			if v162 then
				v131(v134)
				if v141 then
					v135 = v132
					break
				end
				v131({ v165 })
				if v141 then
					break
				end
				v134 = {}
			else
				table.insert(v134, v165)
			end
			v132 = v159 + 1
		end
		if not v141 then
			v131(v134)
		end
	end
	local v166 = Instance.new("UIListLayout")
	v166.HorizontalAlignment = v_u_54.ContainerHorizontalAlignment
	v166.VerticalAlignment = v_u_54.ContainerVerticalAlignment
	v166.Parent = p_u_47
	local v167 = p_u_47.AbsoluteSize.X
	local v168 = 0
	local v169 = 0
	for _, v170 in pairs(v_u_56) do
		v168 = v168 + v170.Size.Y.Offset
		local v171 = v170.Container
		local v172 = nil
		local v173 = nil
		if v171.AnchorPoint.X == 0 then
			v172 = v171.Position.X.Offset
			v173 = v171.Size.X.Offset
		elseif v171.AnchorPoint.X == 0.5 then
			v172 = v170.AbsoluteSize.X / 2 - v171.Size.X.Offset / 2
			v173 = v170.AbsoluteSize.X / 2 + v171.Size.X.Offset / 2
		elseif v171.AnchorPoint.X == 1 then
			v172 = v170.AbsoluteSize.X - v171.Size.X.Offset
			v173 = v170.AbsoluteSize.X
		end
		v167 = math.min(v167, v172)
		v169 = math.max(v169, v173)
	end
	v_u_32 = v_u_32 + 1
	local v_u_174 = false
	local v_u_175 = false
	local v_u_176 = false
	local v_u_177 = "TextAnimation" .. v_u_32
	local v_u_178 = {}
	local function v_u_186()
		-- upvalues: (ref) v_u_175, (ref) v_u_178, (ref) v_u_174, (ref) v_u_31, (copy) v_u_177, (ref) v_u_29
		if v_u_175 and #v_u_178 == 0 or v_u_174 then
			v_u_174 = true
			v_u_31:UnbindFromRenderStep(v_u_177)
			v_u_178 = {}
		else
			local v179 = tick()
			for v180 = #v_u_178, 1, -1 do
				local v181 = v_u_178[v180]
				local v182 = v181.Settings
				local v183 = v_u_29[v182.AnimateStyle]
				if not v183 then
					warn("No animation style found for: ", v182.AnimateStyle, ", defaulting to Appear")
					v183 = v_u_29.Appear
				end
				local v184 = (v179 - v181.Start) / v182.AnimateStyleTime
				local v185 = math.min(v184, 1)
				v183(v181.Char, v185, v182)
				if v185 >= 1 then
					table.remove(v_u_178, v180)
				end
			end
		end
	end
	local function v_u_190(p187)
		-- upvalues: (copy) v_u_58, (ref) v_u_77
		p187.Position = v_u_58[p187].InitialPosition
		p187.Size = v_u_58[p187].InitialSize
		p187.AnchorPoint = v_u_58[p187].InitialAnchorPoint
		for v188, v189 in pairs(v_u_58[p187]) do
			v_u_77(v188, v189, p187)
		end
	end
	local function v_u_194(p191, p192)
		-- upvalues: (copy) v_u_58, (copy) v_u_190
		p191.Visible = p192
		if p192 and (p191:IsA("TextLabel") and (v_u_58[p191] and v_u_58[p191].TypewriterGraphemes)) then
			p191.Text = table.concat(v_u_58[p191].TypewriterGraphemes, "")
		end
		for _, v193 in pairs(p191:GetChildren()) do
			v193.Visible = p192
			if p192 then
				v_u_190(v193)
			end
		end
		if p192 and p191:IsA("ImageLabel") then
			v_u_190(p191)
		end
	end
	local function v_u_227(p195)
		-- upvalues: (ref) v_u_174, (ref) v_u_31, (copy) v_u_177, (copy) v_u_186, (copy) v_u_57, (ref) v_u_178, (ref) v_u_176, (copy) v_u_58, (ref) v_u_175
		v_u_174 = false
		v_u_31:BindToRenderStep(v_u_177, Enum.RenderPriority.Last.Value, v_u_186)
		local v196 = nil
		local v197 = nil
		local _ = nil
		local v198 = nil
		for _, v199 in pairs(v_u_57) do
			for _, v200 in pairs(v199) do
				v200.Visible = false
				for _, v201 in pairs(v200:GetChildren()) do
					v201.Visible = false
				end
			end
		end
		for _, v202 in pairs(v_u_57) do
			for _, v203 in pairs(v202) do
				local v204 = v_u_58[v203]
				v196 = (v204.AnimateStepGrouping ~= v198 or v204.AnimateStepFrequency ~= v197) and 0 or v196
				v198 = v204.AnimateStepGrouping
				local v205 = v204.AnimateStepTime
				local v206 = v204.AnimateStepFrequency
				if v204.AnimateYield > 0 then
					wait(v204.AnimateYield)
				end
				local v207
				if v198 == "Word" or v198 == "All" then
					local v208
					if v203:IsA("TextLabel") and (v204.TypewriterGraphemes and #v204.TypewriterGraphemes > 0) then
						v203.Visible = true
						v203.Text = ""
						local v209 = v204.TypewriterDelay or 0.03
						local v210 = workspace:FindFirstChild("Sounds")
						if v210 then
							v210 = workspace.Sounds:FindFirstChild("Dialogue")
						end
						v208 = v205
						v197 = v206
						for _, v211 in ipairs(v204.TypewriterGraphemes) do
							if v_u_174 then
								return
							end
							v203.Text = v203.Text .. v211
							if v210 and v210:IsA("Sound") then
								v210:Play()
							end
							wait(v209)
						end
					elseif v203:IsA("TextLabel") then
						v203.Visible = true
						v208 = v205
						v197 = v206
						for _, v212 in pairs(v203:GetChildren()) do
							local v213 = v_u_178
							local v214 = {
								["Char"] = v212,
								["Settings"] = v_u_58[v212],
								["Start"] = tick()
							}
							table.insert(v213, v214)
						end
					else
						local v215 = v_u_178
						local v216 = {
							["Char"] = v203,
							["Settings"] = v204,
							["Start"] = tick()
						}
						table.insert(v215, v216)
						v208 = v205
						v197 = v206
					end
					if v198 == "Word" then
						v207 = v196 + 1
						if v_u_176 or (v207 % v197 ~= 0 or v208 < 0) then
							v196 = v207
						else
							local v217 = v208 > 0 and v208 or nil
							wait(v217)
							v196 = v207
						end
					end
				elseif v198 == "Letter" then
					if v203:IsA("TextLabel") then
						v203.Visible = true
						local _ = v203.Text
						local v218 = v205
						v197 = v206
						local v219 = 1
						while true do
							local v220 = v203:FindFirstChild(string.format("Char%03d", v219))
							if not v220 then
								break
							end
							local v221 = v_u_178
							local v222 = {
								["Char"] = v220,
								["Settings"] = v_u_58[v220],
								["Start"] = tick()
							}
							table.insert(v221, v222)
							v207 = v196 + 1
							if not v_u_176 and (v207 % v197 == 0 and v218 >= 0) then
								local v223
								if v218 > 0 then
									v223 = v218 or nil
								else
									v223 = nil
								end
								wait(v223)
							end
							if v_u_174 then
								return
							end
							v219 = v219 + 1
							v196 = v207
						end
					else
						local v224 = v_u_178
						local v225 = {
							["Char"] = v203,
							["Settings"] = v204,
							["Start"] = tick()
						}
						table.insert(v224, v225)
						v207 = v196 + 1
						if v_u_176 or (v207 % v206 ~= 0 or v205 < 0) then
							v196 = v207
							v197 = v206
						else
							local v226 = v205 > 0 and v205 or nil
							wait(v226)
							v196 = v207
							v197 = v206
						end
					end
				else
					warn("Invalid step grouping: ", v198)
					v197 = v206
				end
				if v_u_174 then
					return
				end
			end
		end
		v_u_175 = true
		if p195 then
			while #v_u_178 > 0 do
				v_u_31.RenderStepped:Wait()
			end
		end
	end
	local v228 = {
		["Overflown"] = v141,
		["OverflowPickupIndex"] = v135,
		["StartingProperties"] = p49,
		["OverflowPickupProperties"] = v_u_54,
		["Text"] = p48
	}
	if p51 then
		p51.NextTextObject = v228
	end
	v228.ContentSize = Vector2.new(v169 - v167, v168)
	function v228.Animate(p229, p230)
		-- upvalues: (copy) v_u_227
		if p230 then
			v_u_227()
		else
			coroutine.wrap(v_u_227)()
		end
		if p229.NextTextObject then
			p229.NextTextObject:Animate(p230)
		end
	end
	function v228.Show(p231, p232)
		-- upvalues: (ref) v_u_176, (ref) v_u_174, (copy) v_u_57, (copy) v_u_194
		if p232 then
			v_u_176 = true
		else
			v_u_174 = true
			for _, v233 in pairs(v_u_57) do
				for _, v234 in pairs(v233) do
					v_u_194(v234, true)
				end
			end
		end
		if p231.NextTextObject then
			p231.NextTextObject:Show(p232)
		end
	end
	function v228.Hide(p235)
		-- upvalues: (ref) v_u_174, (copy) v_u_57
		v_u_174 = true
		for _, v236 in pairs(v_u_57) do
			for _, v237 in pairs(v236) do
				v237.Visible = false
				for _, v238 in pairs(v237:GetChildren()) do
					v238.Visible = false
				end
			end
		end
		if p235.NextTextObject then
			p235.NextTextObject:Hide()
		end
	end
	return v228
end
function v_u_1.ContinueOverflow(_, p239, p240)
	-- upvalues: (copy) v_u_1
	return v_u_1:New(p239, nil, nil, false, p240)
end
return v_u_1