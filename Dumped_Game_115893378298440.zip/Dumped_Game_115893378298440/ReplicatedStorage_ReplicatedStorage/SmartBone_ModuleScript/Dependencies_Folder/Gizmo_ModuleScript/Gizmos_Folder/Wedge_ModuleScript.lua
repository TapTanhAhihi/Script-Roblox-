-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = {}
v_u_1.__index = v_u_1
function v_u_1.Init(p2, p3, p4, p5, p6)
	-- upvalues: (copy) v_u_1
	local v7 = v_u_1
	local v8 = setmetatable({}, v7)
	v8.Ceive = p2
	v8.Propertys = p3
	v8.Request = p4
	v8.Release = p5
	v8.Retain = p6
	return v8
end
function v_u_1.Draw(p9, p10, p11, p_u_12)
	local v_u_13 = p9.Ceive
	if v_u_13.Enabled then
		local v_u_14 = p10.Position
		local v15 = p10.UpVector
		local v16 = p10.RightVector
		local v17 = p10.LookVector
		local v18 = p11 * 0.5
		local v19 = v15 * v18.Y
		local v20 = v16 * v18.X
		local v21 = v17 * v18.Z
		local v_u_22 = nil
		local v_u_23 = nil
		local v_u_24 = nil
		local v_u_25 = nil
		local function v33(p26, p27, p28)
			-- upvalues: (copy) v_u_14, (ref) v_u_24, (ref) v_u_25, (copy) v_u_13, (copy) p_u_12
			local v29 = v_u_14 + (p26 - p27 + p28)
			local v30 = v_u_14 + (p26 + p27 + p28)
			local v31 = v_u_14 + (-p26 - p27 + p28)
			local v32 = v_u_14 + (-p26 + p27 + p28)
			v_u_24 = v29
			v_u_25 = v30
			v_u_13.Ray:Draw(v29, v30)
			v_u_13.Ray:Draw(v29, v31)
			v_u_13.Ray:Draw(v30, v32)
			if p_u_12 ~= false then
				v_u_13.Ray:Draw(v30, v31)
			end
			v_u_13.Ray:Draw(v31, v32)
		end
		(function(p34, p35, p36)
			-- upvalues: (copy) v_u_14, (ref) v_u_22, (ref) v_u_23, (copy) v_u_13, (copy) p_u_12
			local v37 = v_u_14 + (p34 - p35 + p36)
			local v38 = v_u_14 + (p34 + p35 + p36)
			local v39 = v_u_14 + (p34 - p35 - p36)
			local v40 = v_u_14 + (p34 + p35 - p36)
			v_u_22 = v37
			v_u_23 = v38
			v_u_13.Ray:Draw(v37, v38)
			v_u_13.Ray:Draw(v37, v39)
			v_u_13.Ray:Draw(v38, v40)
			if p_u_12 ~= false then
				v_u_13.Ray:Draw(v38, v39)
			end
			v_u_13.Ray:Draw(v39, v40)
		end)(-v19, v20, v21)
		v33(v19, v20, -v21)
		v_u_13.Ray:Draw(v_u_22, v_u_24)
		v_u_13.Ray:Draw(v_u_23, v_u_25)
		if p_u_12 ~= false then
			v_u_13.Ray:Draw(v_u_23, v_u_24)
		end
	end
end
function v_u_1.Create(p41, p42, p43, p44)
	local v45 = {
		["Transform"] = p42,
		["Size"] = p43,
		["DrawTriangles"] = p44,
		["AlwaysOnTop"] = p41.Propertys.AlwaysOnTop,
		["Transparency"] = p41.Propertys.Transparency,
		["Color3"] = p41.Propertys.Color3,
		["Enabled"] = true,
		["Destroy"] = false
	}
	p41.Retain(p41, v45)
	return v45
end
function v_u_1.Update(p46, p47)
	local v48 = p46.Ceive
	v48.PushProperty("AlwaysOnTop", p47.AlwaysOnTop)
	v48.PushProperty("Transparency", p47.Transparency)
	v48.PushProperty("Color3", p47.Color3)
	p46:Draw(p47.Transform, p47.Size, p47.DrawTriangles)
end
return v_u_1