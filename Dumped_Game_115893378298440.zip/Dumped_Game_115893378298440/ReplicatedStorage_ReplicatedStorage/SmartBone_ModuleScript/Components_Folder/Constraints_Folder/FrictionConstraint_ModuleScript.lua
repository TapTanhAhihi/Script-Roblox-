-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return function(p1, p2, p3)
	return p3:Lerp(p2, 1 - p1.Friction)
end