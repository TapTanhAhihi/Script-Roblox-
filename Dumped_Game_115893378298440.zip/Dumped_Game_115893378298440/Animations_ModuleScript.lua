-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return {
	["Get"] = function(_, p1)
		return game.ReplicatedStorage.Assets.Animations:FindFirstChild(p1)
	end,
	["GetBySkin"] = function(_, p2, p3)
		local v4 = game.ReplicatedStorage.Assets.Animations:FindFirstChild(p2)
		if v4 and v4:FindFirstChild(p3) then
			return v4:FindFirstChild(p3)
		else
			return nil
		end
	end,
	["StopAll"] = function(_, p5)
		local v6 = p5:FindFirstChildOfClass("Animator")
		if v6 then
			for _, v7 in pairs(v6:GetPlayingAnimationTracks()) do
				if v7.Name ~= "RodIdle" then
					v7:Stop()
				end
			end
		end
	end,
	["StopAllForce"] = function(_, p8)
		local v9 = p8:FindFirstChildOfClass("Animator")
		if v9 then
			for _, v10 in pairs(v9:GetPlayingAnimationTracks()) do
				v10:Stop()
			end
		end
	end,
	["StopByName"] = function(_, p11, p12)
		local v13 = p11:FindFirstChildOfClass("Animator")
		if v13 then
			for _, v14 in pairs(v13:GetPlayingAnimationTracks()) do
				if v14.Name == p12 then
					v14:Stop()
				end
			end
		end
	end
}