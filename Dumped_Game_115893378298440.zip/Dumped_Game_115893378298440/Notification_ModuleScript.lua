-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return {
	["Start"] = function(p1)
		local v_u_2 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("Notification")
		local v_u_3 = game:GetService("TweenService")
		p1.Shared.Network:BindEvents({
			["SendNotification"] = function(p4)
				-- upvalues: (copy) v_u_2, (copy) v_u_3
				local v5 = p4.Text
				local v6 = p4.Type
				local v7 = p4.Duration or 3
				local v_u_8 = game.ReplicatedStorage.Assets.Templates.Template:Clone()
				v_u_8.Text = v5
				if v6 == "Sucess" or v6 == "Success" then
					v_u_8.Sucess.Enabled = true
					workspace.Sounds.Sucess:Play()
				elseif v6 == "Error" then
					workspace.Sounds.Error:Play()
					v_u_8.Fail.Enabled = true
				elseif v6 == "Fish" then
					workspace.Sounds.Fail:Play()
					v_u_8.Fail.Enabled = true
				else
					workspace.Sounds.Notification:Play()
				end
				v_u_8.Parent = v_u_2.Frame
				v_u_8.Size = UDim2.new(0, 0, 0.328, 0)
				v_u_3:Create(v_u_8, TweenInfo.new(0.2, Enum.EasingStyle.Back), {
					["Size"] = UDim2.new(1, 0, 0.328, 0)
				}):Play()
				task.delay(v7, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_8
					v_u_3:Create(v_u_8, TweenInfo.new(0.2), {
						["Size"] = UDim2.new(1, 0, 0, 0)
					}):Play()
					game:GetService("Debris"):AddItem(v_u_8, 0.2)
				end)
			end,
			["SendNotificationBoss"] = function(p9)
				-- upvalues: (copy) v_u_2, (copy) v_u_3
				local v10 = p9.Text
				local v11 = p9.Type
				local v_u_12 = game.ReplicatedStorage.Assets.Templates.Template:Clone()
				v_u_12.Text = v10
				workspace.Sounds.Boss:Play()
				v_u_12.Fail.Enabled = true
				if v11 ~= "Sucess" and (v11 ~= "Success" and v11 == "Error") then
					workspace.Sounds.Error:Play()
				end
				v_u_12.Parent = v_u_2.Frame
				v_u_12.Size = UDim2.new(0, 0, 0.328, 0)
				v_u_3:Create(v_u_12, TweenInfo.new(0.2, Enum.EasingStyle.Back), {
					["Size"] = UDim2.new(1, 0, 0.5, 0)
				}):Play()
				task.delay(5, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_12
					v_u_3:Create(v_u_12, TweenInfo.new(0.2), {
						["Size"] = UDim2.new(1, 0, 0, 0)
					}):Play()
					game:GetService("Debris"):AddItem(v_u_12, 0.2)
				end)
			end
		})
	end
}