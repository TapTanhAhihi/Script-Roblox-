-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("TextChatService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("StarterGui")
local v_u_5 = game:GetService("GuiService")
local v6 = game:GetService("RunService")
local v_u_7 = game:GetService("VRService")
local v8 = game:GetService("Players")
local v9 = v8.LocalPlayer:WaitForChild("PlayerGui")
local v_u_10 = {
	["OpenClose"] = nil,
	["IsOpen"] = false,
	["StateChanged"] = Instance.new("BindableEvent"),
	["ModuleName"] = "Backpack",
	["KeepVRTopbarOpen"] = true,
	["VRIsExclusive"] = true,
	["VRClosesNonExclusive"] = true,
	["BackpackEmpty"] = Instance.new("BindableEvent")
}
v_u_10.BackpackEmpty.Name = "BackpackEmpty"
v_u_10.BackpackItemAdded = Instance.new("BindableEvent")
v_u_10.BackpackItemAdded.Name = "BackpackAdded"
v_u_10.BackpackItemRemoved = Instance.new("BindableEvent")
v_u_10.BackpackItemRemoved.Name = "BackpackRemoved"
local v11 = script
require(script.Attribution)
local v12 = v_u_5.PreferredTransparency or 1
local v_u_13 = not v11:GetAttribute("OutlineEquipBorder") or false
local v_u_14 = v11:GetAttribute("InsetIconPadding")
local v_u_15 = v11:GetAttribute("BackgroundTransparency") or 0.3
local v_u_16 = v_u_15 * v12
local v17 = UDim.new(0, 8)
local v_u_18 = v11:GetAttribute("BackgroundColor3") or Color3.new(0.09803921568627451, 0.10588235294117647, 0.11372549019607843)
local v_u_19 = v11:GetAttribute("EquipBorderColor3") or Color3.new(0, 0.6352941176470588, 1)
local v_u_20 = v11:GetAttribute("BackgroundTransparency") or 0.3
local v_u_21 = v_u_20 * v12
local v_u_22 = v11:GetAttribute("EquipBorderSizePixel") or 5
local v_u_23 = v11:GetAttribute("CornerRadius") or UDim.new(0, 8)
local v_u_24 = Color3.new(1, 1, 1)
local v_u_25 = v_u_23 - UDim.new(0, 5) or UDim.new(0, 3)
local v_u_26 = v11:GetAttribute("BackgroundColor3") or Color3.new(0.09803921568627451, 0.10588235294117647, 0.11372549019607843)
local v_u_27 = v11:GetAttribute("TextColor3") or Color3.new(1, 1, 1)
local v_u_28 = v11:GetAttribute("TextStrokeTransparency") or 0.5
local v_u_29 = v11:GetAttribute("TextStrokeColor3") or Color3.new(0, 0, 0)
local v30 = Color3.new(0.09803921568627451, 0.10588235294117647, 0.11372549019607843)
local v_u_31 = v12 * 0.2
local v32 = Color3.new(1, 1, 1)
local v33 = UDim.new(0, 3)
local v_u_34 = v11:GetAttribute("FontFace") or Font.new("rbxasset://fonts/families/BuilderSans.json")
local v_u_35 = v11:GetAttribute("TextSize") or 16
local v_u_36 = Enum.KeyCode.Backspace.Value
local v_u_37 = Enum.KeyCode.Zero.Value
local v_u_38 = {
	[Enum.UserInputType.MouseButton1] = true,
	[Enum.UserInputType.MouseButton2] = true,
	[Enum.UserInputType.MouseButton3] = true,
	[Enum.UserInputType.MouseMovement] = true,
	[Enum.UserInputType.MouseWheel] = true
}
local v_u_39 = {
	[Enum.UserInputType.Gamepad1] = true,
	[Enum.UserInputType.Gamepad2] = true,
	[Enum.UserInputType.Gamepad3] = true,
	[Enum.UserInputType.Gamepad4] = true,
	[Enum.UserInputType.Gamepad5] = true,
	[Enum.UserInputType.Gamepad6] = true,
	[Enum.UserInputType.Gamepad7] = true,
	[Enum.UserInputType.Gamepad8] = true
}
local v_u_40 = true
local v_u_41 = require(script.Parent.topbarplus).new():setName("Inventory"):setImage("rbxasset://textures/ui/TopBar/inventoryOn.png", "Selected"):setImage("rbxasset://textures/ui/TopBar/inventoryOff.png", "Deselected"):setImageScale(1):setCaption("Inventory"):bindToggleKey(Enum.KeyCode.Backquote):autoDeselect(false):setOrder(-1)
v_u_41.toggled:Connect(function()
	-- upvalues: (copy) v_u_5, (copy) v_u_10
	if not v_u_5.MenuIsOpen then
		v_u_10.OpenClose()
	end
end)
local v_u_42 = Instance.new("ScreenGui")
v_u_42.DisplayOrder = 120
v_u_42.IgnoreGuiInset = true
v_u_42.ResetOnSpawn = false
v_u_42.Name = "BackpackGui"
v_u_42.Parent = v9
local v_u_43 = v_u_5:IsTenFootInterface()
local v_u_44
if v_u_43 then
	v_u_35 = 24
	v_u_44 = 100
else
	v_u_44 = 60
end
local v_u_45 = false
local v46 = v_u_3.TouchEnabled
if v46 then
	v46 = workspace.CurrentCamera.ViewportSize.X < 1024
end
local v_u_47 = v8.LocalPlayer
local v_u_48 = nil
local v_u_49 = nil
local v_u_50 = nil
local v_u_51 = nil
local v_u_52 = nil
local v_u_53 = nil
local v_u_54 = nil
local v_u_55 = v_u_47.Character or v_u_47.CharacterAdded:Wait()
local v_u_56 = v_u_55:WaitForChild("Humanoid")
local v_u_57 = v_u_47:WaitForChild("Backpack")
local v_u_58 = {}
local v_u_59 = nil
local v_u_60 = {}
local v_u_61 = {}
local v_u_62 = {}
local v_u_63 = 0
local v_u_64 = nil
local v_u_65 = false
local v_u_66 = false
local v_u_67 = false
local v_u_68 = false
local v_u_69 = {}
local v_u_70 = false
local v_u_71 = v_u_7.VREnabled
local v_u_72 = v_u_71 and 6 or (v46 and 6 or 10)
local v_u_73 = v_u_71 and 3 or (v46 and 2 or 4)
local v_u_74 = nil
function v_u_10.IsInventoryEmpty()
	-- upvalues: (copy) v_u_72, (copy) v_u_58
	for v75 = v_u_72 + 1, #v_u_58 do
		local v76 = v_u_58[v75]
		if v76 and v76.Tool then
			return false
		end
	end
	return true
end
local function v_u_82()
	-- upvalues: (ref) v_u_50, (copy) v_u_72, (ref) v_u_63, (copy) v_u_58
	local v77 = v_u_50.Visible
	local v78 = v77 and v_u_72 or v_u_63
	local v79 = 0
	for v80 = 1, v_u_72 do
		local v81 = v_u_58[v80]
		if v81.Tool or v77 then
			v79 = v79 + 1
			v81:Readjust(v79, v78)
			v81.Frame.Visible = true
		else
			v81.Frame.Visible = false
		end
	end
end
local function v_u_89()
	-- upvalues: (copy) v_u_72, (copy) v_u_58, (ref) v_u_52, (ref) v_u_44, (ref) v_u_53
	for v83 = v_u_72 + 1, #v_u_58 do
		local v84 = v_u_58[v83]
		v84.Frame.LayoutOrder = v84.Index
		v84.Frame.Visible = v84.Tool ~= nil
	end
	local v85 = v_u_52.AbsoluteSize.X / (v_u_44 + 5)
	local v86 = math.floor(v85)
	local v87 = (#v_u_53:GetChildren() - 1) / v86
	local v88 = math.ceil(v87) * (v_u_44 + 5) + 5
	v_u_52.CanvasSize = UDim2.fromOffset(0, v88)
end
local function v90()
	-- upvalues: (ref) v_u_49, (copy) v_u_72, (ref) v_u_44, (ref) v_u_50, (copy) v_u_73, (copy) v_u_71, (ref) v_u_52, (copy) v_u_82, (copy) v_u_89
	v_u_49.Size = UDim2.new(0, v_u_72 * (v_u_44 + 5) + 5, 0, v_u_44 + 5 + 5)
	v_u_49.Position = UDim2.new(0.5, -v_u_49.Size.X.Offset / 2, 1, -v_u_49.Size.Y.Offset)
	v_u_50.Size = UDim2.new(0, v_u_49.Size.X.Offset, 0, v_u_49.Size.Y.Offset * v_u_73 + 40 + (v_u_71 and 80 or 0))
	v_u_50.Position = UDim2.new(0.5, -v_u_50.Size.X.Offset / 2, 1, v_u_49.Position.Y.Offset - v_u_50.Size.Y.Offset)
	v_u_52.Size = UDim2.new(1, v_u_52.ScrollBarThickness + 1, 1, -40 - (v_u_71 and 80 or 0))
	v_u_52.Position = UDim2.fromOffset(0, 40 + (v_u_71 and 40 or 0))
	v_u_82()
	v_u_89()
end
local function v_u_92()
	-- upvalues: (ref) v_u_55
	if not (v_u_55 and v_u_55.Parent) then
		return false
	end
	if _G.Holding then
		return false
	end
	local v91 = not (v_u_55:GetAttribute("InCombat") or (_G.Holding or v_u_55:GetAttribute("Using")))
	if v91 then
		v91 = not v_u_55:GetAttribute("CastingSkill")
	end
	return v91
end
local function v_u_191(p93, p94)
	-- upvalues: (copy) v_u_58, (ref) v_u_21, (ref) v_u_49, (ref) v_u_44, (copy) v_u_72, (ref) v_u_50, (copy) v_u_3, (ref) v_u_63, (ref) v_u_66, (ref) v_u_45, (copy) v_u_1, (ref) v_u_54, (copy) v_u_60, (ref) v_u_59, (ref) v_u_55, (ref) v_u_74, (copy) v_u_22, (copy) v_u_19, (copy) v_u_13, (ref) v_u_52, (ref) v_u_53, (copy) v_u_92, (ref) v_u_56, (ref) v_u_64, (ref) v_u_57, (copy) v_u_18, (copy) v_u_24, (copy) v_u_23, (copy) v_u_14, (copy) v_u_27, (copy) v_u_28, (copy) v_u_29, (copy) v_u_34, (ref) v_u_35, (copy) v_u_26, (copy) v_u_25, (copy) v_u_191, (ref) v_u_68, (copy) v_u_61, (copy) v_u_37, (copy) v_u_62, (copy) v_u_41
	local v95 = p94 or #v_u_58 + 1
	local v_u_96 = {
		["Tool"] = nil,
		["Index"] = v95,
		["Frame"] = nil
	}
	local v_u_97 = nil
	local v_u_98 = nil
	local v_u_99 = nil
	local v_u_100 = nil
	local v_u_101 = nil
	local v_u_102 = nil
	local v_u_103 = nil
	local v_u_104 = nil
	function v_u_96.Readjust(_, p105, p106)
		-- upvalues: (ref) v_u_49, (ref) v_u_44, (ref) v_u_97
		local v107 = v_u_49.Size.X.Offset / 2
		local v108 = v_u_44 + 5
		local v109 = p105 - (p106 / 2 + 0.5)
		v_u_97.Position = UDim2.fromOffset(v107 - v_u_44 / 2 + v108 * v109, 5)
	end
	function v_u_96.Fill(p110, p_u_111)
		-- upvalues: (ref) v_u_99, (ref) v_u_100, (ref) v_u_103, (ref) v_u_101, (ref) v_u_72, (ref) v_u_50, (ref) v_u_3, (ref) v_u_97, (ref) v_u_63, (ref) v_u_66, (ref) v_u_45, (ref) v_u_1, (ref) v_u_54, (ref) v_u_60, (ref) v_u_59, (ref) v_u_58
		if not p_u_111 then
			return p110:Clear()
		end
		p110.Tool = p_u_111
		local function v_u_113()
			-- upvalues: (copy) p_u_111, (ref) v_u_99, (ref) v_u_100, (ref) v_u_103
			local v112 = p_u_111.TextureId
			v_u_99.Image = v112
			if v112 == "" then
				v_u_100.Visible = true
			else
				v_u_100.Visible = false
			end
			v_u_100.Text = p_u_111.Name
			if v_u_103 and p_u_111:IsA("Tool") then
				v_u_103.Text = p_u_111.ToolTip
				v_u_103.Size = UDim2.fromOffset(0, 16)
				v_u_103.Position = UDim2.new(0.5, 0, 0, -5)
			end
		end
		v_u_113()
		if v_u_101 then
			v_u_101:Disconnect()
			v_u_101 = nil
		end
		v_u_101 = p_u_111.Changed:Connect(function(p114)
			-- upvalues: (copy) v_u_113
			if p114 == "TextureId" or (p114 == "Name" or p114 == "ToolTip") then
				v_u_113()
			end
		end)
		local v115 = p110.Index <= v_u_72
		if (not v115 or v_u_50.Visible) and not v_u_3.VREnabled then
			v_u_97.Draggable = true
		end
		p110:UpdateEquipView()
		if v115 then
			v_u_63 = v_u_63 + 1
			if v_u_66 and (v_u_63 >= 1 and not v_u_45) then
				v_u_45 = true
				v_u_1:BindAction("BackpackHotbarEquip", v_u_54, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
			end
		end
		v_u_60[p_u_111] = p110
		for v116 = 1, v_u_72 do
			v117 = v_u_58[v116]
			if not v117.Tool then
				::l21::
				v_u_59 = v117
				return
			end
		end
		local v117 = nil
		goto l21
	end
	function v_u_96.Clear(p118)
		-- upvalues: (ref) v_u_101, (ref) v_u_99, (ref) v_u_100, (ref) v_u_103, (ref) v_u_97, (ref) v_u_72, (ref) v_u_63, (ref) v_u_45, (ref) v_u_1, (ref) v_u_60, (ref) v_u_59, (ref) v_u_58
		if not p118.Tool then
			return
		end
		if v_u_101 then
			v_u_101:Disconnect()
			v_u_101 = nil
		end
		v_u_99.Image = ""
		v_u_100.Text = ""
		if v_u_103 then
			v_u_103.Text = ""
			v_u_103.Visible = false
		end
		v_u_97.Draggable = false
		p118:UpdateEquipView(true)
		if p118.Index <= v_u_72 then
			v_u_63 = v_u_63 - 1
			if v_u_63 < 1 then
				v_u_45 = false
				v_u_1:UnbindAction("BackpackHotbarEquip")
			end
		end
		v_u_60[p118.Tool] = nil
		p118.Tool = nil
		for v119 = 1, v_u_72 do
			v120 = v_u_58[v119]
			if not v120.Tool then
				::l14::
				v_u_59 = v120
				return
			end
		end
		local v120 = nil
		goto l14
	end
	function v_u_96.UpdateEquipView(p121, p122)
		-- upvalues: (ref) v_u_55, (ref) v_u_74, (copy) v_u_96, (ref) v_u_102, (ref) v_u_22, (ref) v_u_19, (ref) v_u_13, (ref) v_u_99, (ref) v_u_97, (ref) v_u_21
		if p122 or false then
			::l2::
			if v_u_102 then
				v_u_102.Parent = nil
			end
		else
			local v123 = p121.Tool
			if v123 then
				v123 = v123.Parent == v_u_55
			end
			if not v123 then
				goto l2
			end
			v_u_74 = v_u_96
			if not v_u_102 then
				v_u_102 = Instance.new("UIStroke")
				v_u_102.Name = "Border"
				v_u_102.Thickness = v_u_22
				v_u_102.Color = v_u_19
				v_u_102.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			end
			if v_u_13 == true then
				v_u_102.Parent = v_u_99
			else
				v_u_102.Parent = v_u_97
			end
		end
		v_u_97.SelectionImageObject = nil
		v_u_97.BackgroundTransparency = v_u_97.Draggable and 0 or v_u_21
	end
	function v_u_96.IsEquipped(p124)
		-- upvalues: (ref) v_u_55
		local v125 = p124.Tool
		if v125 then
			v125 = v125.Parent == v_u_55
		end
		return v125
	end
	function v_u_96.Delete(p126)
		-- upvalues: (ref) v_u_97, (ref) v_u_58, (ref) v_u_52, (ref) v_u_44, (ref) v_u_53
		v_u_97:Destroy()
		table.remove(v_u_58, p126.Index)
		local v127 = #v_u_58
		for v128 = p126.Index, v127 do
			v_u_58[v128]:SlideBack()
		end
		local v129 = v_u_52.AbsoluteSize.X / (v_u_44 + 5)
		local v130 = math.floor(v129)
		local v131 = (#v_u_53:GetChildren() - 1) / v130
		local v132 = math.ceil(v131) * (v_u_44 + 5) + 5
		v_u_52.CanvasSize = UDim2.fromOffset(0, v132)
	end
	function v_u_96.Swap(p133, p134)
		local v135 = p133.Tool
		local v136 = p134.Tool
		p133:Clear()
		if v136 then
			p134:Clear()
			p133:Fill(v136)
		end
		if v135 then
			p134:Fill(v135)
		else
			p134:Clear()
		end
	end
	function v_u_96.SlideBack(p137)
		-- upvalues: (ref) v_u_97
		p137.Index = p137.Index - 1
		v_u_97.Name = p137.Index
		v_u_97.LayoutOrder = p137.Index
	end
	function v_u_96.TurnNumber(_, p138)
		-- upvalues: (ref) v_u_104
		if v_u_104 then
			v_u_104.Visible = p138
		end
	end
	function v_u_96.SetClickability(p139, p140)
		-- upvalues: (ref) v_u_3, (ref) v_u_97, (ref) v_u_21
		if p139.Tool then
			if v_u_3.VREnabled then
				v_u_97.Draggable = false
			else
				v_u_97.Draggable = not p140
			end
			v_u_97.SelectionImageObject = nil
			v_u_97.BackgroundTransparency = v_u_97.Draggable and 0 or v_u_21
		end
	end
	function v_u_96.CheckTerms(p141, p142)
		-- upvalues: (ref) v_u_100, (ref) v_u_103
		local v143 = 0
		local v144 = p141.Tool
		local v145
		if v144 then
			v145 = v143
			for v146 in pairs(p142) do
				local _, v147 = v_u_100.Text:lower():gsub(v146, "")
				v143 = v145 + v147
				if v144:IsA("Tool") then
					local _, v148 = (v_u_103 and v_u_103.Text or ""):lower():gsub(v146, "")
					v143 = v143 + v148
					v145 = v143
				else
					v145 = v143
				end
			end
		else
			v145 = v143
		end
		return v145
	end
	function v_u_96.Select(_)
		-- upvalues: (copy) v_u_96, (ref) v_u_55, (ref) v_u_92, (ref) v_u_56, (ref) v_u_64, (ref) v_u_60, (ref) v_u_57
		local v149 = v_u_96.Tool
		if v149 then
			local v150
			if v149 then
				v150 = v149.Parent == v_u_55
			else
				v150 = v149
			end
			if v150 then
				if not v_u_92() then
					return
				end
				if v_u_56 then
					v_u_56:UnequipTools()
					if v_u_64 then
						v_u_64:ToggleSelect()
						v_u_60[v_u_64]:UpdateEquipView()
						v_u_64 = nil
						return
					end
				end
			elseif v149.Parent == v_u_57 then
				if not v_u_92() then
					return
				end
				if v_u_92() and v_u_56 then
					v_u_56:UnequipTools()
					if v_u_64 then
						v_u_64:ToggleSelect()
						v_u_60[v_u_64]:UpdateEquipView()
						v_u_64 = nil
					end
				end
				v_u_56:EquipTool(v149)
			end
		end
	end
	v_u_97 = Instance.new("TextButton")
	v_u_97.Name = tostring(v95)
	v_u_97.BackgroundColor3 = v_u_18
	v_u_97.BorderColor3 = v_u_24
	v_u_97.Text = ""
	v_u_97.BorderSizePixel = 0
	v_u_97.Size = UDim2.fromOffset(v_u_44, v_u_44)
	v_u_97.Active = true
	v_u_97.Draggable = false
	v_u_97.BackgroundTransparency = v_u_21
	v_u_97.MouseButton1Click:Connect(function()
		-- upvalues: (copy) v_u_96
		changeSlot(v_u_96)
	end)
	local v151 = Instance.new("UICorner")
	v151.Name = "Corner"
	v151.CornerRadius = v_u_23
	v151.Parent = v_u_97
	v_u_96.Frame = v_u_97
	local v152 = Instance.new("Frame")
	v152.Name = "SelectionObjectClipper"
	v152.BackgroundTransparency = 1
	v152.Visible = false
	v152.Parent = v_u_97
	local v153 = Instance.new("ImageLabel")
	v153.Name = "Selector"
	v153.BackgroundTransparency = 1
	v153.Size = UDim2.fromScale(1, 1)
	v153.Image = "rbxasset://textures/ui/Keyboard/key_selection_9slice.png"
	v153.ScaleType = Enum.ScaleType.Slice
	v153.SliceCenter = Rect.new(12, 12, 52, 52)
	v153.Parent = v152
	v_u_99 = Instance.new("ImageLabel")
	v_u_99.BackgroundTransparency = 1
	v_u_99.Name = "Icon"
	v_u_99.Size = UDim2.fromScale(1, 1)
	v_u_99.Position = UDim2.fromScale(0.5, 0.5)
	v_u_99.AnchorPoint = Vector2.new(0.5, 0.5)
	if v_u_14 == true then
		v_u_99.Size = UDim2.new(1, -v_u_22 * 2, 1, -v_u_22 * 2)
	else
		v_u_99.Size = UDim2.fromScale(1, 1)
	end
	v_u_99.Parent = v_u_97
	local v154 = Instance.new("UICorner")
	v154.Name = "Corner"
	if v_u_14 == true then
		v154.CornerRadius = v_u_23 - UDim.new(0, v_u_22)
	else
		v154.CornerRadius = v_u_23
	end
	v154.Parent = v_u_99
	v_u_100 = Instance.new("TextLabel")
	v_u_100.BackgroundTransparency = 1
	v_u_100.Name = "ToolName"
	v_u_100.Text = ""
	v_u_100.TextColor3 = v_u_27
	v_u_100.TextStrokeTransparency = v_u_28
	v_u_100.TextStrokeColor3 = v_u_29
	v_u_100.FontFace = Font.new(v_u_34.Family, Enum.FontWeight.Medium, Enum.FontStyle.Normal)
	v_u_100.TextSize = v_u_35
	v_u_100.Size = UDim2.new(1, -v_u_22 * 2, 1, -v_u_22 * 2)
	v_u_100.Position = UDim2.fromScale(0.5, 0.5)
	v_u_100.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_100.TextWrapped = true
	v_u_100.TextTruncate = Enum.TextTruncate.AtEnd
	v_u_100.Parent = v_u_97
	v_u_96.Frame.LayoutOrder = v_u_96.Index
	if v95 <= v_u_72 then
		v_u_103 = Instance.new("TextLabel")
		v_u_103.Name = "ToolTip"
		v_u_103.Text = ""
		v_u_103.Size = UDim2.fromScale(1, 1)
		v_u_103.TextColor3 = v_u_27
		v_u_103.TextStrokeTransparency = v_u_28
		v_u_103.TextStrokeColor3 = v_u_29
		v_u_103.FontFace = Font.new(v_u_34.Family, Enum.FontWeight.Medium, Enum.FontStyle.Normal)
		v_u_103.TextSize = v_u_35
		v_u_103.ZIndex = 2
		v_u_103.TextWrapped = false
		v_u_103.TextYAlignment = Enum.TextYAlignment.Center
		v_u_103.BackgroundColor3 = v_u_26
		v_u_103.BackgroundTransparency = v_u_21
		v_u_103.AnchorPoint = Vector2.new(0.5, 1)
		v_u_103.BorderSizePixel = 0
		v_u_103.Visible = false
		v_u_103.AutomaticSize = Enum.AutomaticSize.X
		v_u_103.Parent = v_u_97
		local v155 = Instance.new("UICorner")
		v155.Name = "Corner"
		v155.CornerRadius = v_u_25
		v155.Parent = v_u_103
		local v156 = Instance.new("UIPadding")
		v156.PaddingLeft = UDim.new(0, 4)
		v156.PaddingRight = UDim.new(0, 4)
		v156.PaddingTop = UDim.new(0, 4)
		v156.PaddingBottom = UDim.new(0, 4)
		v156.Parent = v_u_103
		v_u_97.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_103
			if v_u_103.Text ~= "" then
				v_u_103.Visible = true
			end
		end)
		v_u_97.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_103
			v_u_103.Visible = false
		end)
		function v_u_96.MoveToInventory(p157)
			-- upvalues: (copy) v_u_96, (ref) v_u_72, (ref) v_u_191, (ref) v_u_53, (ref) v_u_55, (ref) v_u_92, (ref) v_u_56, (ref) v_u_64, (ref) v_u_60, (ref) v_u_68, (ref) v_u_50
			if v_u_96.Index <= v_u_72 then
				local v158 = v_u_96.Tool
				p157:Clear()
				local v159 = v_u_191(v_u_53)
				v159:Fill(v158)
				if v158 then
					v158 = v158.Parent == v_u_55
				end
				if v158 and (v_u_92() and v_u_56) then
					v_u_56:UnequipTools()
					if v_u_64 then
						v_u_64:ToggleSelect()
						v_u_60[v_u_64]:UpdateEquipView()
						v_u_64 = nil
					end
				end
				if v_u_68 then
					v159.Frame.Visible = false
					v159.Parent = v_u_50
				end
			end
		end
		if v95 < 10 or v95 == v_u_72 then
			local v160 = v95 < 10 and (v95 or 0) or 0
			v_u_104 = Instance.new("TextLabel")
			v_u_104.BackgroundTransparency = 1
			v_u_104.Name = "Number"
			v_u_104.TextColor3 = v_u_27
			v_u_104.TextStrokeTransparency = v_u_28
			v_u_104.TextStrokeColor3 = v_u_29
			v_u_104.TextSize = v_u_35
			v_u_104.Text = tostring(v160)
			v_u_104.FontFace = Font.new(v_u_34.Family, Enum.FontWeight.Heavy, Enum.FontStyle.Normal)
			v_u_104.Size = UDim2.fromScale(0.4, 0.4)
			v_u_104.Visible = false
			v_u_104.Parent = v_u_97
			v_u_61[v_u_37 + v160] = v_u_96.Select
		end
	end
	local v_u_161 = v_u_97.Position
	local v_u_162 = 0
	local v_u_163 = nil
	v_u_97.DragBegin:Connect(function(p164)
		-- upvalues: (ref) v_u_62, (ref) v_u_97, (ref) v_u_161, (ref) v_u_41, (ref) v_u_99, (ref) v_u_100, (ref) v_u_104, (ref) v_u_163, (ref) v_u_53, (ref) v_u_50, (ref) v_u_98
		v_u_62[v_u_97] = true
		v_u_161 = p164
		v_u_97.BorderSizePixel = 2
		v_u_41:lock()
		v_u_97.ZIndex = 2
		v_u_99.ZIndex = 2
		v_u_100.ZIndex = 2
		v_u_97.Parent.ZIndex = 2
		if v_u_104 then
			v_u_104.ZIndex = 2
		end
		v_u_163 = v_u_97.Parent
		if v_u_163 == v_u_53 then
			local v165 = UDim2.new(0, v_u_97.AbsolutePosition.X - v_u_50.AbsolutePosition.X, 0, v_u_97.AbsolutePosition.Y - v_u_50.AbsolutePosition.Y)
			v_u_97.Parent = v_u_50
			v_u_97.Position = v165
			v_u_98 = Instance.new("Frame")
			v_u_98.Name = "FakeSlot"
			v_u_98.LayoutOrder = v_u_97.LayoutOrder
			v_u_98.Size = v_u_97.Size
			v_u_98.BackgroundTransparency = 1
			v_u_98.Parent = v_u_53
		end
	end)
	v_u_97.DragStopped:Connect(function(p166, p167)
		-- upvalues: (ref) v_u_98, (ref) v_u_97, (ref) v_u_161, (ref) v_u_163, (ref) v_u_41, (ref) v_u_99, (ref) v_u_100, (ref) v_u_104, (ref) v_u_62, (copy) v_u_96, (ref) v_u_50, (ref) v_u_72, (ref) v_u_162, (ref) v_u_59, (ref) v_u_49, (ref) v_u_58, (ref) v_u_55, (ref) v_u_92, (ref) v_u_56, (ref) v_u_64, (ref) v_u_60, (ref) v_u_68
		if v_u_98 then
			v_u_98:Destroy()
		end
		local v168 = os.clock()
		v_u_97.Position = v_u_161
		v_u_97.Parent = v_u_163
		v_u_97.BorderSizePixel = 0
		v_u_41:unlock()
		v_u_97.ZIndex = 1
		v_u_99.ZIndex = 1
		v_u_100.ZIndex = 1
		v_u_163.ZIndex = 1
		if v_u_104 then
			v_u_104.ZIndex = 1
		end
		v_u_62[v_u_97] = nil
		if v_u_96.Tool then
			local v169 = v_u_50
			local v170 = v169.AbsolutePosition
			local v171 = v169.AbsoluteSize
			local v172
			if v170.X < p166 and (p166 <= v170.X + v171.X and v170.Y < p167) then
				v172 = p167 <= v170.Y + v171.Y
			else
				v172 = false
			end
			if v172 then
				if v_u_96.Index <= v_u_72 then
					v_u_96:MoveToInventory()
				end
				if v_u_72 < v_u_96.Index and v168 - v_u_162 < 0.5 then
					if v_u_59 then
						local v173 = v_u_96.Tool
						v_u_96:Clear()
						v_u_59:Fill(v173)
						v_u_96:Delete()
						v168 = 0
					else
						v168 = 0
					end
				end
			else
				local v174 = v_u_49
				local v175 = v174.AbsolutePosition
				local v176 = v174.AbsoluteSize
				local v177
				if v175.X < p166 and (p166 <= v175.X + v176.X and v175.Y < p167) then
					v177 = p167 <= v175.Y + v176.Y
				else
					v177 = false
				end
				if v177 then
					local v178 = { (1 / 0), nil }
					for v179 = 1, v_u_72 do
						local v180 = v_u_58[v179]
						local v181 = v180.Frame
						local v182 = Vector2.new(p166, p167)
						local v183 = (v181.AbsolutePosition + v181.AbsoluteSize / 2 - v182).Magnitude
						if v183 < v178[1] then
							v178 = { v183, v180 }
						end
					end
					local v184 = v178[2]
					if v184 ~= v_u_96 then
						v_u_96:Swap(v184)
						if v_u_72 < v_u_96.Index then
							local v185 = v_u_96.Tool
							if v185 then
								if v185 then
									v185 = v185.Parent == v_u_55
								end
								if v185 and (v_u_92() and v_u_56) then
									v_u_56:UnequipTools()
									if v_u_64 then
										v_u_64:ToggleSelect()
										v_u_60[v_u_64]:UpdateEquipView()
										v_u_64 = nil
									end
								end
								if v_u_68 then
									v_u_96.Frame.Visible = false
									v_u_96.Frame.Parent = v_u_50
								end
							else
								v_u_96:Delete()
							end
						end
					end
				elseif v_u_96.Index <= v_u_72 then
					v_u_96:MoveToInventory()
				end
			end
			v_u_162 = v168
		end
	end)
	v_u_97.Parent = p93
	v_u_58[v95] = v_u_96
	if v_u_72 < v95 then
		local v186 = v_u_52.AbsoluteSize.X / (v_u_44 + 5)
		local v187 = math.floor(v186)
		local v188 = (#v_u_53:GetChildren() - 1) / v187
		local v189 = math.ceil(v188) * (v_u_44 + 5) + 5
		v_u_52.CanvasSize = UDim2.fromOffset(0, v189)
		if v_u_50.Visible and not v_u_68 then
			local v190 = v_u_52.CanvasSize.Y.Offset - v_u_52.AbsoluteSize.Y
			v_u_52.CanvasPosition = Vector2.new(0, (math.max(0, v190)))
		end
	end
	return v_u_96
end
local function v_u_200(p192)
	-- upvalues: (ref) v_u_55, (ref) v_u_56, (ref) v_u_64, (copy) v_u_60, (ref) v_u_65, (ref) v_u_47, (ref) v_u_59, (copy) v_u_191, (ref) v_u_53, (copy) v_u_58, (ref) v_u_57, (copy) v_u_82, (copy) v_u_72, (ref) v_u_50, (copy) v_u_92, (copy) v_u_10
	if p192:IsA("Tool") or p192:IsA("HopperBin") then
		local _ = p192.Parent == v_u_55
		if v_u_64 and p192.Parent == v_u_55 then
			v_u_64:ToggleSelect()
			v_u_60[v_u_64]:UpdateEquipView()
			v_u_64 = nil
		end
		if not v_u_65 and (p192.Parent == v_u_55 and not v_u_60[p192]) then
			local v193 = v_u_47:FindFirstChild("StarterGear")
			if v193 and v193:FindFirstChild(p192.Name) then
				v_u_65 = true
				for v194 = (v_u_59 or v_u_191(v_u_53)).Index, 1, -1 do
					local v195 = v_u_58[v194]
					local v196 = v194 - 1
					if v196 > 0 then
						v_u_58[v196]:Swap(v195)
					else
						v195:Fill(p192)
					end
				end
				for _, v197 in pairs(v_u_55:GetChildren()) do
					if v197:IsA("Tool") and v197 ~= p192 then
						v197.Parent = v_u_57
					end
				end
				v_u_82()
				return
			end
		end
		local v198 = v_u_60[p192]
		if v198 then
			v198:UpdateEquipView()
		else
			local v199 = v_u_59 or v_u_191(v_u_53)
			v199:Fill(p192)
			if v199.Index <= v_u_72 and not v_u_50.Visible then
				v_u_82()
			end
			if p192:IsA("HopperBin") and p192.Active then
				if v_u_92() and v_u_56 then
					v_u_56:UnequipTools()
					if v_u_64 then
						v_u_64:ToggleSelect()
						v_u_60[v_u_64]:UpdateEquipView()
						v_u_64 = nil
					end
				end
				v_u_64 = p192
			end
		end
		v_u_10.BackpackItemAdded:Fire()
	elseif p192:IsA("Humanoid") and p192.Parent == v_u_55 then
		v_u_56 = p192
	end
end
local function v_u_207(p201)
	-- upvalues: (ref) v_u_55, (ref) v_u_57, (copy) v_u_60, (copy) v_u_72, (ref) v_u_50, (copy) v_u_82, (ref) v_u_64, (copy) v_u_10, (copy) v_u_58
	if not (p201:IsA("Tool") or p201:IsA("HopperBin")) then
		return
	end
	local v202 = p201.Parent
	if v202 == v_u_55 or v202 == v_u_57 then
		return
	end
	local v203 = v_u_60[p201]
	if v203 then
		v203:Clear()
		if v_u_72 < v203.Index then
			v203:Delete()
		elseif not v_u_50.Visible then
			v_u_82()
		end
	end
	if p201 == v_u_64 then
		v_u_64 = nil
	end
	v_u_10.BackpackItemRemoved:Fire()
	for v204 = v_u_72 + 1, #v_u_58 do
		local v205 = v_u_58[v204]
		if v205 and v205.Tool then
			v206 = false
			::l19::
			if v206 then
				v_u_10.BackpackEmpty:Fire()
			end
			return
		end
	end
	local v206 = true
	goto l19
end
local function v226(p208)
	-- upvalues: (copy) v_u_58, (copy) v_u_72, (ref) v_u_64, (ref) v_u_69, (ref) v_u_55, (copy) v_u_207, (copy) v_u_200, (ref) v_u_57, (ref) v_u_47, (copy) v_u_82
	for v209 = #v_u_58, 1, -1 do
		local v210 = v_u_58[v209]
		if v210.Tool then
			v210:Clear()
		end
		if v_u_72 < v209 then
			v210:Delete()
		end
	end
	v_u_64 = nil
	for _, v211 in pairs(v_u_69) do
		v211:Disconnect()
	end
	v_u_69 = {}
	v_u_55 = p208
	local v212 = v_u_69
	local v213 = p208.ChildRemoved
	local v214 = v_u_207
	table.insert(v212, v213:Connect(v214))
	local v215 = v_u_69
	local v216 = p208.ChildAdded
	local v217 = v_u_200
	table.insert(v215, v216:Connect(v217))
	for _, v218 in pairs(p208:GetChildren()) do
		v_u_200(v218)
	end
	v_u_57 = v_u_47:WaitForChild("Backpack")
	local v219 = v_u_69
	local v220 = v_u_57.ChildRemoved
	local v221 = v_u_207
	table.insert(v219, v220:Connect(v221))
	local v222 = v_u_69
	local v223 = v_u_57.ChildAdded
	local v224 = v_u_200
	table.insert(v222, v223:Connect(v224))
	for _, v225 in pairs(v_u_57:GetChildren()) do
		v_u_200(v225)
	end
	v_u_82()
end
local function v232(p227, p228)
	-- upvalues: (copy) v_u_2, (ref) v_u_67, (ref) v_u_66, (copy) v_u_36, (copy) v_u_61, (ref) v_u_50, (copy) v_u_41
	local v229 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
	local v230 = p227.UserInputType == Enum.UserInputType.Keyboard and (not v_u_67 and (not v229.IsFocused and (v_u_66 or p227.KeyCode.Value == v_u_36))) and v_u_61[p227.KeyCode.Value]
	if v230 then
		v230(p228)
	end
	local v231 = p227.UserInputType
	if not p228 and (v231 == Enum.UserInputType.MouseButton1 or v231 == Enum.UserInputType.Touch) and v_u_50.Visible then
		v_u_41:deselect()
	end
end
local function v239()
	-- upvalues: (copy) v_u_3, (copy) v_u_72, (copy) v_u_58, (copy) v_u_38, (copy) v_u_39
	if v_u_3:GetLastInputType() == Enum.UserInputType.Touch then
		for v233 = 1, v_u_72 do
			v_u_58[v233]:TurnNumber(false)
		end
		return
	elseif v_u_3:GetLastInputType() == Enum.UserInputType.Keyboard then
		for v234 = 1, v_u_72 do
			v_u_58[v234]:TurnNumber(true)
		end
	else
		for _, v235 in pairs(v_u_38) do
			if v_u_3:GetLastInputType() == v235 then
				for v236 = 1, v_u_72 do
					v_u_58[v236]:TurnNumber(true)
				end
				return
			end
		end
		for _, v237 in pairs(v_u_39) do
			if v_u_3:GetLastInputType() == v237 then
				for v238 = 1, v_u_72 do
					v_u_58[v238]:TurnNumber(false)
				end
				return
			end
		end
	end
end
local v_u_240 = nil
local v_u_241 = nil
local function v_u_242() end
function unbindAllGamepadEquipActions()
	-- upvalues: (copy) v_u_1
	v_u_1:UnbindAction("BackpackHasGamepadFocus")
	v_u_1:UnbindAction("BackpackCloseInventory")
end
local function v_u_251(_, p243, p_u_244)
	-- upvalues: (ref) v_u_240, (ref) v_u_241, (copy) v_u_92, (ref) v_u_56, (ref) v_u_64, (copy) v_u_60, (copy) v_u_72, (copy) v_u_58, (ref) v_u_74
	if p243 == Enum.UserInputState.Begin then
		if v_u_240 and (v_u_240.KeyCode == Enum.KeyCode.ButtonR1 and p_u_244.KeyCode == Enum.KeyCode.ButtonL1 or v_u_240.KeyCode == Enum.KeyCode.ButtonL1 and p_u_244.KeyCode == Enum.KeyCode.ButtonR1) and os.clock() - v_u_241 <= 0.06 then
			if v_u_92() and v_u_56 then
				v_u_56:UnequipTools()
				if v_u_64 then
					v_u_64:ToggleSelect()
					v_u_60[v_u_64]:UpdateEquipView()
					v_u_64 = nil
				end
			end
			v_u_240 = p_u_244
			v_u_241 = os.clock()
		else
			v_u_240 = p_u_244
			v_u_241 = os.clock()
			task.delay(0.06, function()
				-- upvalues: (ref) v_u_240, (copy) p_u_244, (ref) v_u_72, (ref) v_u_58, (ref) v_u_92, (ref) v_u_56, (ref) v_u_64, (ref) v_u_60, (ref) v_u_74
				if v_u_240 == p_u_244 then
					local v245 = p_u_244.KeyCode == Enum.KeyCode.ButtonL1 and -1 or 1
					for v246 = 1, v_u_72 do
						if v_u_58[v246]:IsEquipped() then
							local v247 = v245 + v246
							local v248 = false
							if v_u_72 < v247 then
								v247 = 1
								v248 = true
							elseif v247 < 1 then
								v247 = v_u_72
								v248 = true
							end
							local v249 = v247
							while not v_u_58[v247].Tool do
								v247 = v247 + v245
								if v247 == v249 then
									return
								end
								if v_u_72 < v247 then
									v247 = 1
									v248 = true
								elseif v247 < 1 then
									v247 = v_u_72
									v248 = true
								end
							end
							if v248 then
								if v_u_92() and v_u_56 then
									v_u_56:UnequipTools()
									if v_u_64 then
										v_u_64:ToggleSelect()
										v_u_60[v_u_64]:UpdateEquipView()
										v_u_64 = nil
									end
								end
								v_u_74 = nil
							else
								v_u_58[v247]:Select()
							end
						end
					end
					if v_u_74 and v_u_74.Tool then
						v_u_74:Select()
					else
						for v250 = v245 == -1 and (v_u_72 or 1) or 1, v245 == -1 and 1 or v_u_72, v245 do
							if v_u_58[v250].Tool then
								v_u_58[v250]:Select()
								return
							end
						end
					end
				else
					return
				end
			end)
		end
	else
		return
	end
end
function getGamepadSwapSlot()
	-- upvalues: (copy) v_u_58
	for v252 = 1, #v_u_58 do
		if v_u_58[v252].Frame.BorderSizePixel > 0 then
			return v_u_58[v252]
		end
	end
end
function changeSlot(p_u_253)
	-- upvalues: (copy) v_u_7, (ref) v_u_50, (copy) v_u_5, (ref) v_u_51, (copy) v_u_72
	local v254 = not v_u_7.VREnabled or v_u_50.Visible
	if p_u_253.Frame == v_u_5.SelectedObject and v254 then
		local v255 = getGamepadSwapSlot()
		if not v255 then
			local v_u_256 = p_u_253.Frame.Size
			local v_u_257 = p_u_253.Frame.Position
			p_u_253.Frame:TweenSizeAndPosition(v_u_256 + UDim2.fromOffset(10, 10), v_u_257 - UDim2.fromOffset(5, 5), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.1, true, function()
				-- upvalues: (copy) p_u_253, (copy) v_u_256, (copy) v_u_257
				p_u_253.Frame:TweenSizeAndPosition(v_u_256, v_u_257, Enum.EasingDirection.In, Enum.EasingStyle.Quad, 0.1, true)
			end)
			p_u_253.Frame.BorderSizePixel = 3
			v_u_51.SelectionImageObject.Visible = true
			return
		end
		v255.Frame.BorderSizePixel = 0
		if v255 ~= p_u_253 then
			p_u_253:Swap(v255)
			v_u_51.SelectionImageObject.Visible = false
			if v_u_72 < p_u_253.Index and not p_u_253.Tool then
				if v_u_5.SelectedObject == p_u_253.Frame then
					v_u_5.SelectedObject = v255.Frame
				end
				p_u_253:Delete()
			end
			if v_u_72 < v255.Index and not v255.Tool then
				if v_u_5.SelectedObject == v255.Frame then
					v_u_5.SelectedObject = p_u_253.Frame
				end
				v255:Delete()
				return
			end
		end
	else
		p_u_253:Select()
		v_u_51.SelectionImageObject.Visible = false
	end
end
function vrMoveSlotToInventory()
	-- upvalues: (copy) v_u_7, (ref) v_u_51
	if v_u_7.VREnabled then
		local v258 = getGamepadSwapSlot()
		if v258 and v258.Tool then
			v258.Frame.BorderSizePixel = 0
			v258:MoveToInventory()
			v_u_51.SelectionImageObject.Visible = false
		end
	end
end
function enableGamepadInventoryControl()
	-- upvalues: (ref) v_u_50, (copy) v_u_41, (copy) v_u_1, (copy) v_u_242, (copy) v_u_5, (ref) v_u_49
	local function v260()
		-- upvalues: (ref) v_u_50, (ref) v_u_41
		if getGamepadSwapSlot() then
			local v259 = getGamepadSwapSlot()
			if v259 then
				v259.Frame.BorderSizePixel = 0
				return
			end
		elseif v_u_50.Visible then
			v_u_41:deselect()
		end
	end
	v_u_1:BindAction("BackpackHasGamepadFocus", v_u_242, false, Enum.UserInputType.Gamepad1)
	v_u_1:BindAction("BackpackCloseInventory", v260, false, Enum.KeyCode.ButtonB, Enum.KeyCode.ButtonStart)
	if true then
		v_u_5.SelectedObject = v_u_49:FindFirstChild("1")
	end
end
function disableGamepadInventoryControl()
	-- upvalues: (copy) v_u_72, (copy) v_u_58, (copy) v_u_5, (ref) v_u_48
	unbindAllGamepadEquipActions()
	for v261 = 1, v_u_72 do
		local v262 = v_u_58[v261]
		if v262 and v262.Frame then
			v262.Frame.BorderSizePixel = 0
		end
	end
	if v_u_5.SelectedObject and v_u_5.SelectedObject:IsDescendantOf(v_u_48) then
		v_u_5.SelectedObject = nil
	end
end
function gamepadDisconnected()
	-- upvalues: (ref) v_u_70
	v_u_70 = false
	disableGamepadInventoryControl()
end
function gamepadConnected()
	-- upvalues: (ref) v_u_70, (copy) v_u_5, (ref) v_u_48, (ref) v_u_63, (ref) v_u_66, (ref) v_u_45, (copy) v_u_1, (ref) v_u_251, (ref) v_u_50
	v_u_70 = true
	v_u_5:AddSelectionParent("BackpackSelection", v_u_48)
	if v_u_63 >= 1 and (v_u_66 and not v_u_45) then
		v_u_45 = true
		v_u_1:BindAction("BackpackHotbarEquip", v_u_251, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
	end
	if v_u_50.Visible then
		enableGamepadInventoryControl()
	end
end
local function v_u_266(p_u_263)
	-- upvalues: (copy) v_u_4, (ref) v_u_66, (ref) v_u_48, (ref) v_u_63, (ref) v_u_45, (copy) v_u_1, (ref) v_u_251
	local v265, _ = pcall(function()
		-- upvalues: (copy) p_u_263, (ref) v_u_4
		local v264 = p_u_263
		if v264 then
			v264 = v_u_4:GetCore("TopbarEnabled")
		end
		return v264
	end)
	if v265 then
		v_u_66 = p_u_263
		v_u_48.Visible = p_u_263
		if p_u_263 then
			if v_u_63 >= 1 and (v_u_66 and not v_u_45) then
				v_u_45 = true
				v_u_1:BindAction("BackpackHotbarEquip", v_u_251, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
				return
			end
		else
			disableGamepadInventoryControl()
			v_u_45 = false
			v_u_1:UnbindAction("BackpackHotbarEquip")
		end
	end
end
local function v272(p267, p268)
	local v269 = Instance.new("ImageButton")
	v269.BackgroundTransparency = 1
	v269.Name = p267
	v269.Size = UDim2.fromOffset(40, 40)
	v269.Image = "rbxasset://textures/ui/Keyboard/close_button_background.png"
	local v270 = Instance.new("ImageLabel")
	v270.Name = "Icon"
	v270.BackgroundTransparency = 1
	v270.Size = UDim2.fromScale(0.5, 0.5)
	v270.Position = UDim2.fromScale(0.25, 0.25)
	v270.Image = p268
	v270.Parent = v269
	local v271 = Instance.new("ImageLabel")
	v271.BackgroundTransparency = 1
	v271.Name = "Selection"
	v271.Size = UDim2.fromScale(0.9, 0.9)
	v271.Position = UDim2.fromScale(0.05, 0.05)
	v271.Image = "rbxasset://textures/ui/Keyboard/close_button_selection.png"
	v269.SelectionImageObject = v271
	return v269, v270, v271
end
local v273 = Instance.new("Frame")
v273.BackgroundTransparency = 1
v273.Name = "Backpack"
v273.Size = UDim2.fromScale(1, 1)
v273.Visible = false
v273.Parent = v_u_42
local v274 = Instance.new("Frame")
v274.BackgroundTransparency = 1
v274.Name = "Hotbar"
v274.Size = UDim2.fromScale(1, 1)
v274.Parent = v273
local v275 = v273
local v_u_276 = v274
for v277 = 1, v_u_72 do
	local v278 = v_u_191(v_u_276, v277)
	v278.Frame.Visible = false
	if not v_u_59 then
		local v279 = v278
		v_u_59 = v279
	end
end
local v280 = Instance.new("ImageLabel")
v280.BackgroundTransparency = 1
v280.Name = "LeftBumper"
v280.Size = UDim2.fromOffset(40, 40)
v280.Position = UDim2.new(0, -v280.Size.X.Offset, 0.5, -v280.Size.Y.Offset / 2)
local v281 = Instance.new("ImageLabel")
v281.BackgroundTransparency = 1
v281.Name = "RightBumper"
v281.Size = UDim2.fromOffset(40, 40)
v281.Position = UDim2.new(1, 0, 0.5, -v281.Size.Y.Offset / 2)
local v_u_282 = Instance.new("Frame")
v_u_282.Name = "Inventory"
v_u_282.Size = UDim2.fromScale(1, 1)
v_u_282.BackgroundTransparency = v_u_16
v_u_282.BackgroundColor3 = v_u_18
v_u_282.Active = true
v_u_282.Visible = false
v_u_282.Parent = v275
local v283 = Instance.new("UICorner")
v283.Name = "Corner"
v283.CornerRadius = v17
v283.Parent = v_u_282
local v284 = Instance.new("TextButton")
v284.Name = "VRInventorySelector"
v284.Position = UDim2.new(0, 0, 0, 0)
v284.Size = UDim2.fromScale(1, 1)
v284.BackgroundTransparency = 1
v284.Text = ""
v284.Parent = v_u_282
local v285 = Instance.new("ImageLabel")
v285.BackgroundTransparency = 1
v285.Name = "Selector"
v285.Size = UDim2.fromScale(1, 1)
v285.Image = "rbxasset://textures/ui/Keyboard/key_selection_9slice.png"
v285.ScaleType = Enum.ScaleType.Slice
v285.SliceCenter = Rect.new(12, 12, 52, 52)
v285.Visible = false
v284.SelectionImageObject = v285
v284.MouseButton1Click:Connect(function()
	vrMoveSlotToInventory()
end)
local v_u_286 = Instance.new("ScrollingFrame")
v_u_286.BackgroundTransparency = 1
v_u_286.Name = "ScrollingFrame"
v_u_286.Size = UDim2.fromScale(1, 1)
v_u_286.Selectable = false
v_u_286.ScrollingDirection = Enum.ScrollingDirection.Y
v_u_286.BorderSizePixel = 0
v_u_286.ScrollBarThickness = 8
v_u_286.ScrollBarImageColor3 = Color3.new(1, 1, 1)
v_u_286.VerticalScrollBarInset = Enum.ScrollBarInset.ScrollBar
v_u_286.CanvasSize = UDim2.new(0, 0, 0, 0)
v_u_286.Parent = v_u_282
local v_u_287 = Instance.new("Frame")
v_u_287.BackgroundTransparency = 1
v_u_287.Name = "UIGridFrame"
v_u_287.Selectable = false
v_u_287.Size = UDim2.new(1, -10, 1, 0)
v_u_287.Position = UDim2.fromOffset(5, 0)
v_u_287.Parent = v_u_286
local v288 = Instance.new("UIGridLayout")
v288.SortOrder = Enum.SortOrder.LayoutOrder
v288.CellSize = UDim2.fromOffset(v_u_44, v_u_44)
v288.CellPadding = UDim2.fromOffset(5, 5)
v288.Parent = v_u_287
local v_u_289 = v272("ScrollUpButton", "rbxasset://textures/ui/Backpack/ScrollUpArrow.png")
v_u_289.Size = UDim2.fromOffset(34, 34)
v_u_289.Position = UDim2.new(0.5, -v_u_289.Size.X.Offset / 2, 0, 43)
v_u_289.Icon.Position = v_u_289.Icon.Position - UDim2.fromOffset(0, 2)
v_u_289.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_286, (ref) v_u_44
	local v290 = v_u_286
	local v291 = Vector2.new
	local v292 = v_u_286.CanvasPosition.X
	local v293 = v_u_286.CanvasSize.Y.Offset - v_u_286.AbsoluteWindowSize.Y
	local v294 = v_u_286.CanvasPosition.Y - (v_u_44 + 5)
	local v295 = math.max(0, v294)
	v290.CanvasPosition = v291(v292, (math.min(v293, v295)))
end)
local v_u_296 = v272("ScrollDownButton", "rbxasset://textures/ui/Backpack/ScrollUpArrow.png")
v_u_296.Rotation = 180
v_u_296.Icon.Position = v_u_296.Icon.Position - UDim2.fromOffset(0, 2)
v_u_296.Size = UDim2.fromOffset(34, 34)
v_u_296.Position = UDim2.new(0.5, -v_u_296.Size.X.Offset / 2, 1, -v_u_296.Size.Y.Offset - 3)
v_u_296.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_286, (ref) v_u_44
	local v297 = v_u_286
	local v298 = Vector2.new
	local v299 = v_u_286.CanvasPosition.X
	local v300 = v_u_286.CanvasSize.Y.Offset - v_u_286.AbsoluteWindowSize.Y
	local v301 = v_u_286.CanvasPosition.Y + (v_u_44 + 5)
	local v302 = math.max(0, v301)
	v297.CanvasPosition = v298(v299, (math.min(v300, v302)))
end)
v_u_286.Changed:Connect(function(p303)
	-- upvalues: (ref) v_u_286, (ref) v_u_289, (ref) v_u_296
	if p303 == "AbsoluteWindowSize" or (p303 == "CanvasPosition" or p303 == "CanvasSize") then
		local v304 = v_u_286.CanvasPosition.Y ~= 0
		local v305 = v_u_286.CanvasPosition.Y < v_u_286.CanvasSize.Y.Offset - v_u_286.AbsoluteWindowSize.Y
		v_u_289.Visible = v304
		v_u_296.Visible = v305
	end
end)
v90()
local v_u_306 = Instance.new("Frame")
v_u_306.Name = "GamepadHintsFrame"
v_u_306.Size = UDim2.fromOffset(v_u_276.Size.X.Offset, v_u_43 and 95 or 60)
v_u_306.BackgroundTransparency = v_u_16
v_u_306.BackgroundColor3 = v_u_18
v_u_306.Visible = false
v_u_306.Parent = v275
local v307 = Instance.new("UIListLayout")
v307.Name = "Layout"
v307.Padding = UDim.new(0, 25)
v307.FillDirection = Enum.FillDirection.Horizontal
v307.HorizontalAlignment = Enum.HorizontalAlignment.Center
v307.SortOrder = Enum.SortOrder.LayoutOrder
v307.Parent = v_u_306
local v308 = Instance.new("UICorner")
v308.Name = "Corner"
v308.CornerRadius = v17
v308.Parent = v_u_306
local function v316(p309, p310)
	-- upvalues: (copy) v_u_306, (copy) v_u_43, (copy) v_u_34
	local v311 = Instance.new("Frame")
	v311.Name = "HintFrame"
	v311.AutomaticSize = Enum.AutomaticSize.XY
	v311.BackgroundTransparency = 1
	v311.Parent = v_u_306
	local v312 = Instance.new("UIListLayout")
	v312.Name = "Layout"
	v312.Padding = v_u_43 and UDim.new(0, 20) or UDim.new(0, 12)
	v312.FillDirection = Enum.FillDirection.Horizontal
	v312.SortOrder = Enum.SortOrder.LayoutOrder
	v312.VerticalAlignment = Enum.VerticalAlignment.Center
	v312.Parent = v311
	local v313 = Instance.new("ImageLabel")
	v313.Name = "HintImage"
	v313.Size = v_u_43 and UDim2.fromOffset(60, 60) or UDim2.fromOffset(30, 30)
	v313.BackgroundTransparency = 1
	v313.Image = p309
	v313.Parent = v311
	local v314 = Instance.new("TextLabel")
	v314.Name = "HintText"
	v314.AutomaticSize = Enum.AutomaticSize.XY
	v314.FontFace = Font.new(v_u_34.Family, Enum.FontWeight.Medium, Enum.FontStyle.Normal)
	v314.TextSize = v_u_43 and 32 or 19
	v314.BackgroundTransparency = 1
	v314.Text = p310
	v314.TextColor3 = Color3.new(1, 1, 1)
	v314.TextXAlignment = Enum.TextXAlignment.Left
	v314.TextYAlignment = Enum.TextYAlignment.Center
	v314.TextWrapped = true
	v314.Parent = v311
	local v315 = Instance.new("UITextSizeConstraint")
	v315.MaxTextSize = v314.TextSize
	v315.Parent = v314
end
v316(v_u_3:GetImageForKeyCode(Enum.KeyCode.ButtonX), "Remove From Hotbar")
v316(v_u_3:GetImageForKeyCode(Enum.KeyCode.ButtonA), "Select/Swap")
v316(v_u_3:GetImageForKeyCode(Enum.KeyCode.ButtonB), "Close Backpack")
local function v_u_324()
	-- upvalues: (copy) v_u_306, (ref) v_u_276, (copy) v_u_43, (ref) v_u_282
	v_u_306.Size = UDim2.new(v_u_276.Size.X.Scale, v_u_276.Size.X.Offset, 0, v_u_43 and 95 or 60)
	v_u_306.Position = UDim2.new(v_u_276.Position.X.Scale, v_u_276.Position.X.Offset, v_u_282.Position.Y.Scale, v_u_282.Position.Y.Offset - v_u_306.Size.Y.Offset - 5)
	local v317 = v_u_306:GetChildren()
	local v318 = {}
	local v319 = 0
	for _, v320 in pairs(v317) do
		if v320:IsA("GuiObject") then
			table.insert(v318, v320)
		end
	end
	for v321 = 1, #v318 do
		if v318[v321]:IsA("GuiObject") then
			v318[v321].Size = UDim2.new(1, 0, 1, -5)
			v318[v321].Position = UDim2.new(0, 0, 0, 0)
			v319 = v319 + (v318[v321].HintText.Position.X.Offset + v318[v321].HintText.TextBounds.X)
		end
	end
	local v322 = (v_u_306.AbsoluteSize.X - v319) / (#v318 - 1)
	for v323 = 1, #v318 do
		v318[v323].Position = v323 == 1 and UDim2.new(0, 0, 0, 0) or UDim2.new(0, v318[v323 - 1].Position.X.Offset + v318[v323 - 1].Size.X.Offset + v322, 0, 0)
		v318[v323].Size = UDim2.new(0, v318[v323].HintText.Position.X.Offset + v318[v323].HintText.TextBounds.X, 1, -5)
	end
end
local v_u_325 = Instance.new("Frame")
v_u_325.Name = "Search"
v_u_325.BackgroundColor3 = v30
v_u_325.BackgroundTransparency = v_u_31
v_u_325.Size = UDim2.new(0, 190, 0, 30)
v_u_325.Position = UDim2.new(1, -v_u_325.Size.X.Offset - 5, 0, 5)
v_u_325.Parent = v_u_282
local v326 = Instance.new("UICorner")
v326.Name = "Corner"
v326.CornerRadius = v33
v326.Parent = v_u_325
local v327 = Instance.new("UIStroke")
v327.Name = "Border"
v327.Color = v32
v327.Thickness = 0.05
v327.Transparency = 0.8
v327.Parent = v_u_325
local v_u_328 = Instance.new("TextBox")
v_u_328.BackgroundTransparency = 1
v_u_328.Name = "TextBox"
v_u_328.Text = ""
v_u_328.TextColor3 = v_u_27
v_u_328.TextStrokeTransparency = v_u_28
v_u_328.TextStrokeColor3 = v_u_29
v_u_328.FontFace = Font.new(v_u_34.Family, Enum.FontWeight.Medium, Enum.FontStyle.Normal)
v_u_328.PlaceholderText = "Search"
v_u_328.TextColor3 = v_u_27
v_u_328.TextTransparency = v_u_28
v_u_328.TextStrokeColor3 = v_u_29
v_u_328.ClearTextOnFocus = false
v_u_328.TextTruncate = Enum.TextTruncate.AtEnd
v_u_328.TextSize = v_u_35
v_u_328.TextXAlignment = Enum.TextXAlignment.Left
v_u_328.TextYAlignment = Enum.TextYAlignment.Center
v_u_328.Size = UDim2.new(0, 154, 0, 14)
v_u_328.AnchorPoint = Vector2.new(0, 0.5)
v_u_328.Position = UDim2.new(0, 8, 0.5, 0)
v_u_328.ZIndex = 2
v_u_328.Parent = v_u_325
local v_u_329 = Instance.new("TextButton")
v_u_329.Name = "X"
v_u_329.Text = ""
v_u_329.Size = UDim2.fromOffset(30, 30)
v_u_329.Position = UDim2.new(1, -v_u_329.Size.X.Offset, 0.5, -v_u_329.Size.Y.Offset / 2)
v_u_329.ZIndex = 4
v_u_329.Visible = false
v_u_329.BackgroundTransparency = 1
v_u_329.Parent = v_u_325
local v330 = Instance.new("ImageButton")
v330.Name = "X"
v330.Image = "rbxasset://textures/ui/InspectMenu/x.png"
v330.BackgroundTransparency = 1
v330.Size = UDim2.new(0, v_u_325.Size.Y.Offset - 20, 0, v_u_325.Size.Y.Offset - 20)
v330.AnchorPoint = Vector2.new(0.5, 0.5)
v330.Position = UDim2.fromScale(0.5, 0.5)
v330.ZIndex = 1
v330.BorderSizePixel = 0
v330.Parent = v_u_329
local function v_u_346()
	-- upvalues: (copy) v_u_328, (copy) v_u_72, (copy) v_u_58, (ref) v_u_282, (ref) v_u_68, (ref) v_u_287, (ref) v_u_286, (ref) v_u_44, (copy) v_u_329
	local v331 = {}
	for v332 in v_u_328.Text:gmatch("%S+") do
		v331[v332:lower()] = true
	end
	local v333 = {}
	for v334 = v_u_72 + 1, #v_u_58 do
		local v335 = v_u_58[v334]
		local v336 = { v335, (v335:CheckTerms(v331)) }
		table.insert(v333, v336)
		v335.Frame.Visible = false
		v335.Frame.Parent = v_u_282
	end
	table.sort(v333, function(p337, p338)
		return p337[2] > p338[2]
	end)
	v_u_68 = true
	local v339 = 0
	for _, v340 in ipairs(v333) do
		local v341 = v340[1]
		if v340[2] > 0 then
			v341.Frame.Visible = true
			v341.Frame.Parent = v_u_287
			v341.Frame.LayoutOrder = v_u_72 + v339
			v339 = v339 + 1
		end
	end
	v_u_286.CanvasPosition = Vector2.new(0, 0)
	local v342 = v_u_286.AbsoluteSize.X / (v_u_44 + 5)
	local v343 = math.floor(v342)
	local v344 = (#v_u_287:GetChildren() - 1) / v343
	local v345 = math.ceil(v344) * (v_u_44 + 5) + 5
	v_u_286.CanvasSize = UDim2.fromOffset(0, v345)
	v_u_329.ZIndex = 3
end
local function v_u_353()
	-- upvalues: (copy) v_u_329, (ref) v_u_68, (copy) v_u_72, (copy) v_u_58, (ref) v_u_287, (ref) v_u_286, (ref) v_u_44
	if v_u_329.ZIndex > 0 then
		v_u_68 = false
		for v347 = v_u_72 + 1, #v_u_58 do
			local v348 = v_u_58[v347]
			v348.Frame.LayoutOrder = v348.Index
			v348.Frame.Parent = v_u_287
			v348.Frame.Visible = true
		end
		v_u_329.ZIndex = 0
	end
	local v349 = v_u_286.AbsoluteSize.X / (v_u_44 + 5)
	local v350 = math.floor(v349)
	local v351 = (#v_u_287:GetChildren() - 1) / v350
	local v352 = math.ceil(v351) * (v_u_44 + 5) + 5
	v_u_286.CanvasSize = UDim2.fromOffset(0, v352)
end
v_u_329.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_353, (copy) v_u_328
	v_u_353()
	v_u_328.Text = ""
end)
v_u_328.Changed:Connect(function(p354)
	-- upvalues: (copy) v_u_328, (copy) v_u_28, (copy) v_u_353, (copy) v_u_346, (copy) v_u_329
	if p354 == "Text" then
		local v355 = v_u_328.Text
		if v355 == "" then
			v_u_328.TextTransparency = v_u_28
			v_u_353()
		elseif v355 ~= "" then
			v_u_328.TextTransparency = 0
			v_u_346()
		end
		local v356 = v_u_329
		local v357
		if v355 == "" then
			v357 = false
		else
			v357 = v355 ~= ""
		end
		v356.Visible = v357
	end
end)
v_u_328.FocusLost:Connect(function(p358)
	-- upvalues: (copy) v_u_346
	if p358 then
		v_u_346()
	end
end)
v_u_10.StateChanged.Event:Connect(function(p359)
	-- upvalues: (copy) v_u_353, (copy) v_u_328
	if not p359 then
		v_u_353()
		v_u_328.Text = ""
	end
end)
v_u_61[Enum.KeyCode.Escape.Value] = function(p360)
	-- upvalues: (copy) v_u_353, (copy) v_u_328
	if p360 then
		v_u_353()
		v_u_328.Text = ""
	end
end
v_u_3.LastInputTypeChanged:Connect(function(p361)
	-- upvalues: (copy) v_u_3, (copy) v_u_325
	if p361 == Enum.UserInputType.Gamepad1 and not v_u_3.VREnabled then
		v_u_325.Visible = false
	else
		v_u_325.Visible = true
	end
end)
v_u_5.MenuOpened:Connect(function()
	-- upvalues: (copy) v_u_42, (copy) v_u_41
	v_u_42.Enabled = false
	v_u_41:setEnabled(false)
end)
v_u_5.MenuClosed:Connect(function()
	-- upvalues: (copy) v_u_42, (copy) v_u_41
	v_u_42.Enabled = true
	v_u_41:setEnabled(true)
end)
local function v_u_364(_, p362, _)
	-- upvalues: (copy) v_u_5, (copy) v_u_72, (copy) v_u_58
	if p362 == Enum.UserInputState.Begin then
		if v_u_5.SelectedObject then
			for v363 = 1, v_u_72 do
				if v_u_58[v363].Frame == v_u_5.SelectedObject and v_u_58[v363].Tool then
					v_u_58[v363]:MoveToInventory()
					return
				end
			end
		end
	else
		return
	end
end
local function v367()
	-- upvalues: (copy) v_u_62, (ref) v_u_282, (copy) v_u_82, (ref) v_u_276, (copy) v_u_72, (copy) v_u_58, (ref) v_u_70, (copy) v_u_39, (copy) v_u_3, (copy) v_u_324, (copy) v_u_306, (copy) v_u_1, (copy) v_u_364, (copy) v_u_10
	if not next(v_u_62) then
		v_u_282.Visible = not v_u_282.Visible
		local v365 = v_u_282.Visible
		v_u_82()
		v_u_276.Active = not v_u_276.Active
		for v366 = 1, v_u_72 do
			v_u_58[v366]:SetClickability(not v365)
		end
	end
	if v_u_282.Visible then
		if v_u_70 then
			if v_u_39[v_u_3:GetLastInputType()] then
				v_u_324()
				v_u_306.Visible = not v_u_3.VREnabled
			end
			enableGamepadInventoryControl()
		end
	else
		if v_u_70 then
			v_u_306.Visible = false
		end
		disableGamepadInventoryControl()
	end
	if v_u_282.Visible then
		v_u_1:BindAction("BackpackRemoveSlot", v_u_364, false, Enum.KeyCode.ButtonX)
	else
		v_u_1:UnbindAction("BackpackRemoveSlot")
	end
	v_u_10.IsOpen = v_u_282.Visible
	v_u_10.StateChanged:Fire(v_u_282.Visible)
end
v_u_4:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
v_u_10.OpenClose = v367
local v_u_368 = v_u_282
while not v_u_47 do
	task.wait()
	v_u_47 = v8.LocalPlayer
end
v_u_47.CharacterAdded:Connect(v226)
if v_u_47.Character then
	v226(v_u_47.Character)
end
v_u_3.InputBegan:Connect(v232)
v_u_3.TextBoxFocused:Connect(function()
	-- upvalues: (ref) v_u_67
	v_u_67 = true
end)
v_u_3.TextBoxFocusReleased:Connect(function()
	-- upvalues: (ref) v_u_67
	v_u_67 = false
end)
v_u_61[v_u_36] = function()
	-- upvalues: (ref) v_u_64, (copy) v_u_92, (ref) v_u_56, (copy) v_u_60
	if v_u_64 then
		if not v_u_92() then
			return
		end
		if v_u_56 then
			v_u_56:UnequipTools()
			if v_u_64 then
				v_u_64:ToggleSelect()
				v_u_60[v_u_64]:UpdateEquipView()
				v_u_64 = nil
			end
		end
	end
end
v_u_3.LastInputTypeChanged:Connect(v239)
v239()
if v_u_3:GetGamepadConnected(Enum.UserInputType.Gamepad1) then
	gamepadConnected()
end
v_u_3.GamepadConnected:Connect(function(p369)
	if p369 == Enum.UserInputType.Gamepad1 then
		gamepadConnected()
	end
end)
v_u_3.GamepadDisconnected:Connect(function(p370)
	if p370 == Enum.UserInputType.Gamepad1 then
		gamepadDisconnected()
	end
end)
function v_u_10.SetBackpackEnabled(_, p371)
	-- upvalues: (ref) v_u_40
	v_u_40 = p371
end
function v_u_10.IsOpened(_)
	-- upvalues: (copy) v_u_10
	return v_u_10.IsOpen
end
function v_u_10.GetBackpackEnabled(_)
	-- upvalues: (ref) v_u_40
	return v_u_40
end
function v_u_10.GetStateChangedEvent(_)
	-- upvalues: (copy) v_u_10
	return v_u_10.StateChanged
end
v6.Heartbeat:Connect(function()
	-- upvalues: (copy) v_u_266, (ref) v_u_40
	v_u_266(v_u_40)
end)
v_u_5:GetPropertyChangedSignal("PreferredTransparency"):Connect(function()
	-- upvalues: (copy) v_u_5, (ref) v_u_16, (copy) v_u_15, (ref) v_u_368, (ref) v_u_21, (copy) v_u_20, (copy) v_u_58, (ref) v_u_31, (copy) v_u_325
	local v372 = v_u_5.PreferredTransparency
	v_u_16 = v_u_15 * v372
	v_u_368.BackgroundTransparency = v_u_16
	v_u_21 = v_u_20 * v372
	for _, v373 in ipairs(v_u_58) do
		v373.Frame.BackgroundTransparency = v_u_21
	end
	v_u_31 = v372 * 0.2
	v_u_325.BackgroundTransparency = v_u_31
end)
return v_u_10