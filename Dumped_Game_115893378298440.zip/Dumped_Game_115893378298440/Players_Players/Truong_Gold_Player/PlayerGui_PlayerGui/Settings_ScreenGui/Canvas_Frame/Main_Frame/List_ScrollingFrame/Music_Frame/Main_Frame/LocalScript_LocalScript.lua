-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = script.Parent.Toggle
local _ = v_u_1.On
local _ = v_u_1.Off
local v_u_2 = true
local v3 = v_u_1.ActiveButton
function Active(p4)
	if p4 then
		for _, v5 in pairs(workspace.Music:GetChildren()) do
			if v5:IsA("Sound") then
				v5.Volume = 0.2
			end
		end
	else
		for _, v6 in pairs(workspace.Music:GetChildren()) do
			if v6:IsA("Sound") then
				v6.Volume = 0
			end
		end
	end
end
v3.Activated:Connect(function()
	-- upvalues: (ref) v_u_2, (copy) v_u_1
	v_u_2 = not v_u_2
	Active(v_u_2)
	if v_u_2 then
		v_u_1.On.Visible = true
		v_u_1.Off.Visible = false
	else
		v_u_1.On.Visible = false
		v_u_1.Off.Visible = true
	end
end)