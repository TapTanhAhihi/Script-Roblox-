-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return function(p1, p2, p3, p4, p5)
	debug.profilebegin("Spring Constraint")
	local v6 = p4.Settings
	local v7 = v6.Stiffness
	local v8 = v6.Elasticity
	local v9 = p4.Bones[p1.ParentIndex]
	if v9 then
		local v10 = p1.FreeLength
		if v7 > 0 or v8 > 0 then
			local v11 = p3 or (CFrame.new(v9.Position) * v9.TransformOffset.Rotation * CFrame.new(p1.LocalTransformOffset.Position)).Position
			p2 = p2 + (v11 - p2) * (v8 * p5)
			if v7 > 0 then
				local v12 = v11 - p2
				local v13 = v12.Magnitude
				local v14 = v10 * (1 - v7) * 2
				if v14 < v13 then
					p2 = p2 + v12 * ((v13 - v14) / v13)
				end
			end
		end
		local v15 = v9.Position - p2
		local v16 = v15.Magnitude
		if v16 > 0 then
			p2 = p2 + v15 * ((v16 - v10) / v16)
		end
	end
	debug.profileend()
	return p2
end