-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = false
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = 0
function v1.Update(p_u_6)
	-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_2, (ref) v_u_5
	local v7 = game:GetService("Players").LocalPlayer
	repeat
		task.wait()
	until v7:FindFirstChild("PlayerGui")
	local v_u_8 = v7.PlayerGui:WaitForChild("Rewards").Canvas.Main
	local v9 = v_u_8.List
	for _, v10 in pairs(v9:GetChildren()) do
		if v10:IsA("Frame") then
			v10:Destroy()
		end
	end
	if not v_u_3 then
		return
	end
	local v11, v12 = pcall(function()
		-- upvalues: (ref) v_u_3
		return v_u_3:InvokeServer("GetRewardData")
	end)
	if not (v11 and v12) then
		warn("Failed to get reward data")
		return
	end
	v_u_4 = v12
	local v13 = p_u_6.Data.RewardConfig
	for v14 = 1, #v13.Rewards do
		local v15 = v13.Rewards[v14]
		if v15 then
			local v16 = game.ReplicatedStorage.Assets.Templates.Rewards.Template:Clone()
			v16.Name = "Day" .. v14
			if v15.Display then
				v16.Main.Display.Image = v15.Display
			end
			v16.Main.TextLabel.Text = "Day " .. v14
			v16.Parent = v9
			local v17 = v16:FindFirstChild("DayText")
			if v17 then
				v17.Text = "Day " .. v14
			end
			local v18 = v16:FindFirstChild("ClaimedCheck")
			if v18 then
				local v19 = false
				for _, v20 in ipairs(v12.ClaimedDays or {}) do
					if v20 == v14 then
						v19 = true
						break
					end
				end
				v18.Visible = v19 or v14 < v12.NextDay
			end
			local v21 = v16:FindFirstChild("ClaimButton")
			if v21 then
				local v22 = v12.CanClaim
				if v22 then
					v22 = v14 == v12.NextDay
				end
				v21.Visible = v22
				v21.Active = v22
				if v22 then
					v21.Activated:Connect(function()
						-- upvalues: (ref) v_u_2, (ref) v_u_3, (copy) p_u_6
						if not v_u_2 then
							v_u_2 = true
							task.delay(0.5, function()
								-- upvalues: (ref) v_u_2
								v_u_2 = false
							end)
							local v23, v24 = pcall(function()
								-- upvalues: (ref) v_u_3
								return v_u_3:InvokeServer("ClaimReward")
							end)
							if v23 and v24 then
								task.wait(0.1)
								p_u_6:Update()
							end
						end
					end)
				end
			end
		end
	end
	local v25 = v_u_8:FindFirstChild("Button")
	if v25 then
		local v26 = v12.CanClaim
		v_u_5 = v_u_5 + 1
		local v_u_27 = v_u_5
		v25.Visible = true
		v25.Active = v26
		local v_u_28 = v25.Main:FindFirstChildWhichIsA("TextLabel")
		if v26 then
			if v_u_28 then
				v_u_28.Text = "Claim"
			end
			v25.Activated:Connect(function()
				-- upvalues: (ref) v_u_2, (ref) v_u_3, (copy) p_u_6
				if not v_u_2 then
					v_u_2 = true
					task.delay(0.5, function()
						-- upvalues: (ref) v_u_2
						v_u_2 = false
					end)
					local v29, v30 = pcall(function()
						-- upvalues: (ref) v_u_3
						return v_u_3:InvokeServer("ClaimReward")
					end)
					if v29 and v30 then
						task.wait(0.1)
						p_u_6:Update()
					end
				end
			end)
			return
		end
		print(v12.HoursUntilNextClaim)
		if v12.HoursUntilNextClaim and v_u_28 then
			local v31 = v12.HoursUntilNextClaim * 3600
			local v32 = math.floor(v31)
			local v_u_33 = math.max(0, v32)
			task.spawn(function()
				-- upvalues: (copy) v_u_27, (ref) v_u_5, (ref) v_u_33, (copy) v_u_28, (copy) v_u_8
				while v_u_27 == v_u_5 and v_u_33 >= 0 do
					local v34 = v_u_33 / 3600
					local v35 = math.floor(v34)
					local v36 = v_u_33 % 3600 / 60
					local v37 = math.floor(v36)
					local v38 = v_u_33 % 60
					local v39 = string.format("Next: %02dh %02dm %02ds", v35, v37, v38)
					if not (v_u_28 and v_u_28.Parent) then
						break
					end
					v_u_28.Text = v39
					local v40 = v_u_8:FindFirstChild("TimeText")
					if v40 then
						v40.Text = v39
					end
					if v_u_33 <= 0 then
						break
					end
					task.wait(1)
					v_u_33 = v_u_33 - 1
				end
			end)
		end
	end
end
function v1.Start(p41)
	-- upvalues: (ref) v_u_3
	v_u_3 = p41.Shared.Network
end
function v1.Active(p_u_42)
	-- upvalues: (ref) v_u_2
	local v43 = game:GetService("Players").LocalPlayer
	repeat
		task.wait()
	until v43:FindFirstChild("PlayerGui")
	local v44 = v43.PlayerGui:WaitForChild("Rewards")
	game:GetService("TweenService")
	if v_u_2 then
		return
	else
		local v45 = p_u_42.Shared.sprLib
		v_u_2 = true
		task.delay(0.5, function()
			-- upvalues: (ref) v_u_2
			v_u_2 = false
		end)
		v44.Enabled = not v44.Enabled
		v44.Canvas.Size = UDim2.new(0, 0, 1, 0)
		if v44.Enabled then
			task.spawn(function()
				-- upvalues: (copy) p_u_42
				p_u_42:Update()
			end)
			p_u_42.Controllers.HUD:CloseAllUI(v44)
			p_u_42.Controllers.HUD:Effect(true)
			v45.target(v44.Canvas, 1, 4, {
				["Size"] = UDim2.new(1, 0, 1, 0)
			})
		else
			p_u_42.Controllers.HUD:Effect(false)
		end
	end
end
return v1