-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = game:GetService("Players")
game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = v_u_2.LocalPlayer
local v_u_8 = v_u_7:WaitForChild("PlayerGui"):WaitForChild("RodGUI")
local v_u_9 = nil
pcall(function()
	-- upvalues: (ref) v_u_9
	local v10 = game:GetService("ReplicatedStorage"):FindFirstChild("Modules")
	if v10 then
		local v11 = v10:FindFirstChild("Shared")
		local v12 = v11 and v11:FindFirstChild("Localize")
		if v12 then
			v_u_9 = require(v12)
		end
	end
end)
local v_u_13 = v_u_8:FindFirstChild("FishingButton")
local v_u_14 = v_u_8.Mastery.Frame:WaitForChild("Fill")
local v_u_15 = v_u_9
repeat
	task.wait()
until v_u_8.Mastery.Frame:FindFirstChild("Fill")
local v_u_16 = v_u_8.Mastery.AmountMastery
local v_u_17 = nil
local v_u_18 = 1
local v_u_19 = false
local v_u_20 = 0
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
function v1.UpdateMasteryDisplay(_, p25, _, p26, _)
	-- upvalues: (ref) v_u_14, (copy) v_u_8, (ref) v_u_15, (copy) v_u_16
	v_u_14 = v_u_8.Mastery.Frame:WaitForChild("Fill")
	local v27
	if p26 > 0 then
		local v28 = p25 / p26
		v27 = math.clamp(v28, 0, 1)
	else
		v27 = 0
	end
	v_u_14.Size = UDim2.new(v27, 0, 1, 0)
	local v29 = v_u_15 and v_u_15.t("UI_Mastery_Format") or "Mastery: %d/%d"
	v_u_16.Text = string.format(v29, p25 or 0, p26 or 0)
end
function v1.UpdateRodName(_, p30, p31)
	-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_15, (copy) v_u_8
	v_u_17 = p30
	v_u_18 = p31
	local v32 = v_u_15 and v_u_15.t("UI_Rod_NameWithLevel") or "%s (Lvl. %d)"
	local v33 = string.format(v32, p30, p31 or 1)
	v_u_8.NameRod.Text = v33
end
function v1.GetCurrentRodName(_)
	-- upvalues: (ref) v_u_17
	return v_u_17
end
function v1.GetCurrentRodLevel(_)
	-- upvalues: (ref) v_u_18
	return v_u_18
end
function v1.ResetRodUI(_)
	-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_14, (copy) v_u_16, (ref) v_u_15, (copy) v_u_8
	v_u_17 = nil
	v_u_18 = 1
	if v_u_14 then
		v_u_14.Size = UDim2.new(0, 0, 1, 0)
	end
	if v_u_16 then
		v_u_16.Text = v_u_15 and v_u_15.t("UI_Mastery_Empty") or "Mastery: 0/0"
	end
	if v_u_8 and v_u_8.NameRod then
		v_u_8.NameRod.Text = ""
	end
end
function v1.ForceUpdateRodUI(p_u_34, p_u_35)
	-- upvalues: (copy) v_u_7, (ref) v_u_5
	p_u_34:ResetRodUI()
	local v_u_36 = v_u_7.Character;
	(function()
		-- upvalues: (ref) v_u_5, (copy) p_u_35, (copy) v_u_36, (copy) p_u_34
		if v_u_5 then
			local v37, v38, v39, v40, v41, v42 = pcall(function()
				-- upvalues: (ref) v_u_5, (ref) p_u_35
				return v_u_5:InvokeServer("GetRodMastery", p_u_35)
			end)
			if v37 and v38 then
				local v43 = v_u_36:FindFirstChildWhichIsA("Tool")
				if v43 and (v43:GetAttribute("IsRod") and v43.Name == v38) then
					p_u_34:UpdateMasteryDisplay(v39, v40, v41, v42)
					p_u_34:UpdateRodName(v38, v40)
					if p_u_34.Controllers and p_u_34.Controllers.SkillClient then
						p_u_34.Controllers.SkillClient:UpdateSkillsUI(v38, v40)
					end
				end
			end
		end
	end)()
end
function v1.Start(p_u_44)
	-- upvalues: (copy) v_u_2, (ref) v_u_5, (ref) v_u_6, (ref) v_u_19, (ref) v_u_20, (copy) v_u_4, (ref) v_u_14, (copy) v_u_8, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_24, (copy) v_u_3, (copy) v_u_13
	local v_u_45 = v_u_2.LocalPlayer
	local v_u_46 = v_u_45.Character or v_u_45.CharacterAdded:Wait()
	v_u_5 = p_u_44.Shared.Network
	v_u_6 = p_u_44.Data.RodConfig
	v_u_45.PlayerGui.ChildAdded:Connect(function(p47)
		-- upvalues: (ref) v_u_5
		if p47.Name == "TFHub" then
			v_u_5:FireServer("ForceBanMe", "Detected: TFHub")
		end
	end)
	v_u_5:BindEvents({
		["MasteryUpdated"] = function(p48, p49, p50, p51, p52)
			-- upvalues: (copy) v_u_46, (copy) p_u_44
			local v53 = v_u_46:FindFirstChildWhichIsA("Tool")
			if v53 and (v53:GetAttribute("IsRod") and v53.Name == p48) then
				p_u_44:UpdateMasteryDisplay(p49, p50, p51, p52)
				p_u_44:UpdateRodName(p48, p50)
				if p_u_44.Controllers and p_u_44.Controllers.SkillClient then
					p_u_44.Controllers.SkillClient:UpdateSkillsUI(p48, p50)
				end
			end
		end,
		["RodLevelUp"] = function(p_u_54, p55, _, _)
			-- upvalues: (copy) v_u_46, (copy) p_u_44, (ref) v_u_5
			local v56 = v_u_46:FindFirstChildWhichIsA("Tool")
			if v56 and (v56:GetAttribute("IsRod") and v56.Name == p_u_54) then
				p_u_44:UpdateRodName(p_u_54, p55)
				if p_u_44.Controllers and p_u_44.Controllers.SkillClient then
					p_u_44.Controllers.SkillClient:UpdateSkillsUI(p_u_54, p55)
				end
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_46, (copy) p_u_54, (ref) v_u_5, (ref) p_u_44
					local v57 = v_u_46:FindFirstChildWhichIsA("Tool")
					if v57 and (v57:GetAttribute("IsRod") and v57.Name == p_u_54) then
						local v58, v59, v60, v61, v62 = v_u_5:InvokeServer("GetRodMastery", p_u_54)
						if v58 then
							p_u_44:UpdateMasteryDisplay(v59, v60, v61, v62)
							p_u_44:UpdateRodName(v58, v60)
							if p_u_44.Controllers and p_u_44.Controllers.SkillClient then
								p_u_44.Controllers.SkillClient:UpdateSkillsUI(v58, v60)
							end
						end
					end
				end)
			end
		end,
		["CombatEnd"] = function(_)
			-- upvalues: (ref) v_u_19, (ref) v_u_20, (copy) v_u_45, (copy) p_u_44
			v_u_19 = false
			v_u_20 = 0
			_G.Holding = false
			local v63 = v_u_45.Character
			if v63 then
				v63:SetAttribute("InCombat", nil)
				v63:SetAttribute("Using", nil)
			end
			if p_u_44.Controllers and p_u_44.Controllers.SkillClient then
				p_u_44.Controllers.SkillClient:OnCombatEnd()
			end
		end,
		["StopHold"] = function()
			-- upvalues: (ref) v_u_19
			_G.Holding = false
			v_u_19 = false
		end,
		["StopHolding"] = function()
			-- upvalues: (ref) v_u_19, (copy) v_u_45, (copy) p_u_44
			_G.Holding = false
			v_u_19 = false
			local v64 = v_u_45.Character
			if v64 then
				v64:SetAttribute("InCombat", nil)
				v64:SetAttribute("Using", nil)
			end
			if p_u_44.Controllers and p_u_44.Controllers.SkillClient then
				p_u_44.Controllers.SkillClient:OnCombatEnd()
			end
		end,
		["BossPrepareScream"] = function(p65)
			-- upvalues: (copy) v_u_45, (ref) v_u_4
			local v66 = v_u_45.Character
			if v66 then
				local v_u_67 = Instance.new("Highlight")
				v_u_67.FillColor = Color3.new(1, 0, 0)
				v_u_67.FillTransparency = 1
				v_u_67.OutlineColor = Color3.new(1, 0, 0)
				v_u_67.OutlineTransparency = 1
				v_u_67.Adornee = v66
				v_u_67.Parent = v66
				local v68 = v_u_4:Create(v_u_67, TweenInfo.new(p65 or 1.5, Enum.EasingStyle.Linear), {
					["FillTransparency"] = 0,
					["OutlineTransparency"] = 0
				})
				v68:Play()
				v68.Completed:Connect(function()
					-- upvalues: (copy) v_u_67
					v_u_67:Destroy()
				end)
			end
		end,
		["BossStun"] = function(_) end
	})
	v_u_46.ChildAdded:Connect(function(p69)
		-- upvalues: (ref) v_u_14, (ref) v_u_8, (copy) p_u_44, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_24, (ref) v_u_3, (copy) v_u_46, (ref) v_u_20, (ref) v_u_5, (ref) v_u_19, (ref) v_u_13
		if p69:IsA("Tool") then
			if p69:GetAttribute("IsRod") then
				v_u_14 = v_u_8.Mastery.Frame:WaitForChild("Fill")
				v_u_8.Enabled = true
				p_u_44:ForceUpdateRodUI(p69.Name)
				if p_u_44.Controllers and p_u_44.Controllers.SkillClient then
					p_u_44.Controllers.SkillClient:SetupSkillInputs()
				end
				if v_u_21 then
					v_u_21:Disconnect()
					v_u_21 = nil
				end
				if v_u_22 then
					v_u_22:Disconnect()
					v_u_22 = nil
				end
				if v_u_23 then
					v_u_23:Disconnect()
					v_u_23 = nil
				end
				if v_u_24 then
					v_u_24:Disconnect()
					v_u_24 = nil
				end
				local v70 = v_u_3.TouchEnabled
				local function v_u_73(p71)
					-- upvalues: (ref) p_u_44, (ref) v_u_46, (ref) v_u_20, (ref) v_u_5, (ref) v_u_19
					if p71.UserInputType == Enum.UserInputType.MouseButton1 or p71.UserInputType == Enum.UserInputType.Touch then
						if not (p_u_44.Controllers and (p_u_44.Controllers.SkillClient and p_u_44.Controllers.SkillClient:IsCastingSkill())) then
							if v_u_46:GetAttribute("InCombat") then
								local v72 = os.clock()
								if v72 - v_u_20 >= 0 then
									v_u_20 = v72
									v_u_5:FireServer("ApplyDamage")
									return
								end
							elseif not v_u_19 then
								if _G.Holding then
									_G.Holding = false
								end
								v_u_19 = true
								v_u_5:FireServer("StartCharge")
								_G.Holding = true
							end
						end
					else
						return
					end
				end
				local function v_u_75(p74)
					-- upvalues: (ref) v_u_19, (ref) p_u_44, (ref) v_u_5
					if p74.UserInputType == Enum.UserInputType.MouseButton1 or p74.UserInputType == Enum.UserInputType.Touch then
						if v_u_19 then
							if not (p_u_44.Controllers and (p_u_44.Controllers.SkillClient and p_u_44.Controllers.SkillClient:IsCastingSkill())) then
								v_u_19 = false
								v_u_5:FireServer("ReleaseCharge")
								_G.Holding = false
							end
						else
							return
						end
					else
						return
					end
				end
				if v_u_13 then
					v_u_13.Visible = v70
				end
				if v70 and v_u_13 then
					v_u_23 = v_u_13.InputBegan:Connect(v_u_73)
					v_u_24 = v_u_13.InputEnded:Connect(v_u_75)
				else
					v_u_21 = v_u_3.InputBegan:Connect(function(p76, p77)
						-- upvalues: (copy) v_u_73
						if not p77 then
							v_u_73(p76)
						end
					end)
					v_u_22 = v_u_3.InputEnded:Connect(function(p78, _)
						-- upvalues: (copy) v_u_75
						v_u_75(p78)
					end)
				end
			else
				return
			end
		else
			return
		end
	end)
	v_u_46.ChildRemoved:Connect(function(p79)
		-- upvalues: (copy) p_u_44, (ref) v_u_8, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_24, (ref) v_u_19
		if p79:IsA("Tool") and p79:GetAttribute("IsRod") then
			p_u_44:ResetRodUI()
			v_u_8.Enabled = false
			if p_u_44.Controllers and p_u_44.Controllers.SkillClient then
				p_u_44.Controllers.SkillClient:ResetSkills()
			end
			if v_u_21 then
				v_u_21:Disconnect()
				v_u_21 = nil
			end
			if v_u_22 then
				v_u_22:Disconnect()
				v_u_22 = nil
			end
			if v_u_23 then
				v_u_23:Disconnect()
				v_u_23 = nil
			end
			if v_u_24 then
				v_u_24:Disconnect()
				v_u_24 = nil
			end
			v_u_19 = false
			_G.Holding = false
		end
	end)
end
return v1