-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = {}
v_u_1.__index = v_u_1
function v_u_1.Init(p2, p3, p4, p5, p6)
	-- upvalues: (copy) v_u_1
	local v7 = v_u_1
	local v8 = setmetatable({}, v7)
	v8.Ceive = p2
	v8.Propertys = p3
	v8.Request = p4
	v8.Release = p5
	v8.Retain = p6
	return v8
end
function v_u_1.Draw(p9, p_u_10, p11, p12)
	local v_u_13 = p9.Ceive
	if v_u_13.Enabled then
		local v14 = p12 * Vector3.new(1, 1, 0)
		local v15 = CFrame.lookAt(p_u_10, p_u_10 + p11)
		local v16 = v15.UpVector
		local v17 = v15.RightVector
		local v18 = v15.LookVector
		local v19 = v14 * 0.5
		(function(p20, p21, p22)
			-- upvalues: (copy) p_u_10, (copy) v_u_13
			local v23 = p_u_10 + (p20 - p21 + p22)
			local v24 = p_u_10 + (p20 + p21 + p22)
			local v25 = p_u_10 + (-p20 - p21 + p22)
			local v26 = p_u_10 + (-p20 + p21 + p22)
			v_u_13.Ray:Draw(v23, v24)
			v_u_13.Ray:Draw(v23, v25)
			v_u_13.Ray:Draw(v24, v26)
			v_u_13.Ray:Draw(v24, v25)
			v_u_13.Ray:Draw(v25, v26)
		end)(v16 * v19.Y, v17 * v19.X, v18 * v19.Z)
	end
end
function v_u_1.Create(p27, p28, p29, p30)
	local v31 = {
		["Position"] = p28,
		["Normal"] = p29,
		["Size"] = p30,
		["AlwaysOnTop"] = p27.Propertys.AlwaysOnTop,
		["Transparency"] = p27.Propertys.Transparency,
		["Color3"] = p27.Propertys.Color3,
		["Enabled"] = true,
		["Destroy"] = false
	}
	p27.Retain(p27, v31)
	return v31
end
function v_u_1.Update(p32, p33)
	local v34 = p32.Ceive
	v34.PushProperty("AlwaysOnTop", p33.AlwaysOnTop)
	v34.PushProperty("Transparency", p33.Transparency)
	v34.PushProperty("Color3", p33.Color3)
	p32:Draw(p33.Position, p33.Normal, p33.Size)
end
return v_u_1