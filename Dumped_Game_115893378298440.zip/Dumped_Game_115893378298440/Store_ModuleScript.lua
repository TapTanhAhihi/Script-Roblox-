-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = game:GetService("Players")
local v_u_3 = nil
local v_u_4 = {}
local v_u_5 = nil
local v_u_6 = {}
local v_u_7 = "Rod"
function v1.Update(p_u_8, p9)
	-- upvalues: (copy) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_6
	local v10 = p_u_8.Data.RodConfig
	local v11 = v_u_2.LocalPlayer:WaitForChild("PlayerGui").Store.Canvas.Main
	local v12 = v11.ListFrame
	local v13 = v11.ThingFrame
	if p9 == "Rod" then
		v13.Visible = false
		v12.Visible = true
		for _, v14 in pairs(v12:GetChildren()) do
			if v14:IsA("ImageLabel") then
				v14:Destroy()
			end
		end
		if v_u_3 then
			local v15, v16, _, _, v17 = pcall(function()
				-- upvalues: (ref) v_u_3
				return v_u_3:InvokeServer("GetInventory")
			end)
			if v15 and v16 then
				v_u_4 = {}
				for _, v19 in ipairs(v16.Rod or {}) do
					if type(v19) == "table" then
						local v19 = v19.Name or v19
					end
					v_u_4[v19] = true
				end
				if v17 then
					v_u_5 = v17
				end
			end
		end
		for v_u_20, v21 in pairs(v10) do
			if v_u_20 ~= "Bamboo Rod" and (v_u_20 ~= "Steel Rod" and v_u_20 ~= "Titanium Steel Rod") then
				local v22 = game.ReplicatedStorage.Assets.Templates.Store.Template:Clone()
				v22.Parent = v12
				v22.Name = v_u_20
				v22.LayoutOrder = v21.RarityOrder
				v22.Display.Image = v21.Display
				v22.NameRod.Text = v_u_20
				v22.Luuck.Text = "Luck: " .. v21.Luck
				v22.Damage.Text = "Damage: " .. v21.Damage
				local v23 = v22.ImageButton
				local v24 = v23:FindFirstChildOfClass("TextLabel")
				local v25 = v_u_4[v_u_20] == true
				local v26 = v_u_5 == v_u_20
				if v25 then
					if v26 then
						if v24 then
							v24.Text = "Equipped"
						end
						v23.BackgroundColor3 = Color3.fromRGB(100, 200, 100)
						v23.Active = false
					else
						if v24 then
							v24.Text = "Equip"
						end
						v23.BackgroundColor3 = Color3.fromRGB(100, 150, 255)
						v23.Active = true
						v23.MouseButton1Click:Connect(function()
							-- upvalues: (copy) p_u_8, (copy) v_u_20
							p_u_8:EquipRod(v_u_20)
						end)
					end
					v22.Price.Text = "Owned"
				else
					local v_u_27 = v21.Price or 0
					if v_u_27 > 0 then
						v22.Price.Text = "Price: " .. v_u_27
						if v24 then
							v24.Text = "Buy"
						end
						v23.BackgroundColor3 = Color3.fromRGB(255, 150, 50)
						v23.Active = true
						v23.MouseButton1Click:Connect(function()
							-- upvalues: (copy) p_u_8, (copy) v_u_20, (copy) v_u_27
							p_u_8:BuyRod(v_u_20, v_u_27)
						end)
					else
						v22.Price.Text = "Free"
						if v24 then
							v24.Text = "Get"
						end
						v23.BackgroundColor3 = Color3.fromRGB(100, 150, 255)
						v23.Active = true
						v23.MouseButton1Click:Connect(function()
							-- upvalues: (copy) p_u_8, (copy) v_u_20
							p_u_8:BuyRod(v_u_20, 0)
						end)
					end
				end
			end
		end
	else
		v12.Visible = false
		v13.Visible = true
		for _, v28 in pairs(v13:GetChildren()) do
			if v28:IsA("Frame") then
				v28:Destroy()
			end
		end
		local v29 = p_u_8.Data.BaitConfig
		local v30 = {}
		for v31, v32 in pairs(v29) do
			if v31 ~= "Normal Bait" then
				table.insert(v30, {
					["Name"] = v31,
					["Data"] = v32
				})
			end
		end
		table.sort(v30, function(p33, p34)
			local v35 = p33.Data.Price or 0
			local v36 = p34.Data.Price or 0
			if v35 == v36 then
				return p33.Name < p34.Name
			else
				return v35 < v36
			end
		end)
		for _, v37 in ipairs(v30) do
			local v_u_38 = v37.Name
			local v39 = v37.Data
			local v40 = game.ReplicatedStorage.Assets.Templates.Store.TemplateBait:Clone()
			v40.Parent = v13
			v40.Name = v_u_38
			v40.NameBait.Text = v_u_38
			v40.BaitLuck.Text = "+" .. (v39.Luck or 0) .. "% Luck"
			v40.Display.Image = v39.Display
			v40.PriceBait.Text = "Price: " .. (v39.Price or 0)
			local v41 = v_u_6[v_u_38] or 0
			v40.AmountBaitHave.Text = "Owned: " .. v41
			v40.BuyButton.Activated:Connect(function()
				-- upvalues: (ref) v_u_3, (copy) v_u_38
				if v_u_3 then
					v_u_3:FireServer("BuyBait", v_u_38, 1)
				end
			end)
		end
	end
end
function v1.BuyRod(p42, p_u_43, p44)
	-- upvalues: (ref) v_u_3, (copy) v_u_2, (ref) v_u_7
	if v_u_3 then
		if p44 > 0 then
			local v45 = v_u_2.LocalPlayer:FindFirstChild("leaderstats")
			if v45 then
				v45 = v45:FindFirstChild("Money")
			end
			if not v45 then
				warn("Money stat not found")
				return
			end
			if v45.Value < p44 then
				return
			end
		end
		local v46, v47, v48 = pcall(function()
			-- upvalues: (ref) v_u_3, (copy) p_u_43
			return v_u_3:InvokeServer("BuyRod", p_u_43)
		end)
		if v46 then
			if v47 == true or v48 == "Bought" then
				p42:Update(v_u_7)
				return
			end
		else
			warn("Failed to purchase rod:", v47)
		end
	end
end
function v1.EquipRod(p49, p_u_50)
	-- upvalues: (ref) v_u_3
	if v_u_3 then
		local v51, v52, v53 = pcall(function()
			-- upvalues: (ref) v_u_3, (copy) p_u_50
			return v_u_3:InvokeServer("EquipRodFromStore", p_u_50)
		end)
		if v51 then
			if v52 == true or v53 == "Equipped" then
				p49:Update()
				return
			end
		else
			warn("Failed to equip rod:", v52)
		end
	end
end
function v1.Start(p_u_54)
	-- upvalues: (ref) v_u_3, (copy) v_u_2, (ref) v_u_7, (ref) v_u_6
	local v_u_55 = workspace.NPCs
	v_u_3 = p_u_54.Shared.Network
	local v_u_56 = v_u_2.LocalPlayer:WaitForChild("PlayerGui").Store
	local _ = v_u_56.Canvas.Main
	v_u_56.Bait.Activated:Connect(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_3, (copy) p_u_54
		v_u_7 = "Bait"
		if v_u_3 then
			v_u_3:FireServer("GetBaitInfo")
		end
		p_u_54:Update("Bait")
	end)
	v_u_56.Rod.Activated:Connect(function()
		-- upvalues: (ref) v_u_7, (copy) p_u_54
		v_u_7 = "Rod"
		p_u_54:Update("Rod")
	end)
	task.delay(3, function()
		-- upvalues: (copy) v_u_55, (copy) v_u_56, (copy) p_u_54, (ref) v_u_7
		for _, v57 in pairs(v_u_55:GetChildren()) do
			if v57:IsA("Model") and v57.Name == "Noob" then
				v57.HumanoidRootPart.ProximityPrompt.Triggered:Connect(function()
					-- upvalues: (ref) v_u_56, (ref) p_u_54, (ref) v_u_7
					if not v_u_56.Enabled then
						p_u_54:OpenGUI()
						p_u_54:Update(v_u_7)
					end
				end)
			end
		end
	end)
	v_u_3:BindEvents({
		["UpdateStore"] = function()
			-- upvalues: (copy) p_u_54, (ref) v_u_7
			p_u_54:Update(v_u_7)
		end,
		["BaitInfo"] = function(p58, _, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) p_u_54
			v_u_6 = p58 or {}
			if v_u_7 == "Bait" then
				p_u_54:Update("Bait")
			end
		end,
		["BaitUpdated"] = function(p59, p60)
			-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) p_u_54
			v_u_6 = v_u_6 or {}
			if p60 <= 0 then
				v_u_6[p59] = nil
			else
				v_u_6[p59] = p60
			end
			if v_u_7 == "Bait" then
				p_u_54:Update("Bait")
			end
		end
	})
end
function v1.OpenGUI(p61)
	-- upvalues: (copy) v_u_2, (ref) v_u_7, (ref) v_u_3
	local v62 = v_u_2.LocalPlayer:WaitForChild("PlayerGui").Store
	local _ = v62.Canvas.Main
	local v63 = p61.Shared.sprLib
	v62.Enabled = true
	p61.Controllers.HUD:CloseAllUI(v62)
	v62.Canvas.Size = UDim2.new(0, 0, 1, 0)
	p61.Controllers.HUD:Effect(true)
	v63.target(v62.Canvas, 1, 4, {
		["Size"] = UDim2.new(1, 0, 1, 0)
	})
	if v_u_7 == "Bait" and v_u_3 then
		v_u_3:FireServer("GetBaitInfo")
	end
	p61:Update(v_u_7)
end
return v1