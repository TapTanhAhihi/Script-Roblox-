-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return {
	["Start"] = function(p_u_1)
		local v2 = game:GetService("ReplicatedStorage")
		local v3 = game:GetService("Players")
		local v_u_4 = game:GetService("RunService")
		local v5 = v3.LocalPlayer
		v5:WaitForChild("PlayerGui"):WaitForChild("CrateGUI")
		local v_u_6 = v2.Assets.Crate
		local v_u_7 = workspace.Crate
		local v8 = v2.Remotes.CrateAnimation
		for _, v_u_9 in pairs(v_u_7:GetChildren()) do
			local v10 = game.ReplicatedStorage.Assets.GUI.BasicCrate:Clone()
			v10.Parent = v5.PlayerGui
			v10.Name = v_u_9.Name
			v10.Adornee = v_u_9.PrimaryPart
			local v_u_11 = false
			v10.Canvas.Buttons.UnlockOne.Activated:Connect(function()
				-- upvalues: (copy) p_u_1, (copy) v_u_9
				p_u_1.Shared.Network:InvokeServer("OpenCrate", v_u_9.Name)
			end)
			v10.Canvas.Buttons.Auto.Activated:Connect(function()
				-- upvalues: (ref) v_u_11, (copy) p_u_1, (copy) v_u_9
				if not v_u_11 then
					v_u_11 = true
					task.delay(2, function()
						-- upvalues: (ref) v_u_11
						v_u_11 = false
					end)
					p_u_1.Shared.Network:InvokeServer("OpenCrateWithRobux", v_u_9.Name)
				end
			end)
		end
		v8.OnClientEvent:Connect(function(p12)
			-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_4
			local v_u_13 = v_u_6:FindFirstChild(p12):Clone()
			v_u_13.Parent = workspace.Debris
			if not v_u_13.PrimaryPart then
				v_u_13.PrimaryPart = v_u_13:FindFirstChildWhichIsA("BasePart")
			end
			v_u_13:ScaleTo(0.5)
			local v14 = v_u_7:FindFirstChild(p12)
			if v14 then
				local v15 = v14.PrimaryPart.CFrame
				local v_u_16 = v15 - v15.Position
				local v_u_17 = v15.Position
				local v18 = math.random(-15, 15)
				local v_u_19 = v_u_17 + Vector3.new(v18, -5, 20)
				local v20 = math.random(-15, 15)
				local v21 = math.random
				local v_u_22 = v_u_17 + Vector3.new(v20, 12, v21(5, 10))
				local v_u_23 = 0
				v_u_13:SetPrimaryPartCFrame(v15)
				local v_u_24 = nil
				task.delay(0.45, function()
					-- upvalues: (copy) v_u_13
					local v25 = v_u_13.AnimationController:LoadAnimation(game.ReplicatedStorage.Assets.Crate.Crate)
					v25:Play()
					v25.Stopped:Connect(function()
						-- upvalues: (ref) v_u_13
						v_u_13:Destroy()
					end)
				end)
				v_u_24 = v_u_4.RenderStepped:Connect(function(p26)
					-- upvalues: (ref) v_u_23, (copy) v_u_17, (copy) v_u_22, (copy) v_u_19, (copy) v_u_13, (copy) v_u_16, (ref) v_u_24
					v_u_23 = v_u_23 + p26 / 0.9
					if v_u_23 >= 1 then
						v_u_23 = 1
					end
					local v27 = v_u_22
					local v28 = v_u_19
					local v29 = v_u_23
					local v30 = v_u_17:Lerp(v27, v29):Lerp(v27:Lerp(v28, v29), v29)
					v_u_13:SetPrimaryPartCFrame(CFrame.new(v30) * v_u_16)
					if v_u_23 >= 1 then
						v_u_24:Disconnect()
					end
				end)
			end
		end)
	end
}