-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v1 = {}
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = {}
local _ = false
local v_u_10 = false
local v_u_11 = 0
local function v_u_36()
	-- upvalues: (ref) v_u_4, (ref) v_u_7
	if v_u_4 and v_u_7 then
		local v12, v13 = pcall(function()
			-- upvalues: (ref) v_u_4
			return v_u_4:InvokeServer("GetGachaInfo")
		end)
		if v12 and v13 then
			local v14 = v_u_7:FindFirstChild("PriceLabel", true)
			local v15 = v_u_7:FindFirstChild("CountdownLabel", true)
			if v14 then
				v14.Text = "Price: " .. (v13.Price or 0) .. " $"
			end
			if v15 then
				local v16 = "Reset in: "
				local v17 = v13.ResetInSeconds or 0
				local v18
				if v17 and v17 > 0 then
					local v19 = v17 / 3600
					local v20 = math.floor(v19)
					local v21 = v17 % 3600 / 60
					local v22 = math.floor(v21)
					local v23 = v17 % 60
					v18 = string.format("%02d:%02d:%02d", v20, v22, v23)
				else
					v18 = "Ready"
				end
				v15.Text = v16 .. v18
			end
			local v24 = v_u_7:FindFirstChild("Background")
			if v24 then
				local v25 = v24:FindFirstChild("TextLabel")
				if v25 and v25:IsA("TextLabel") then
					local v26 = "Price: "
					local v27 = v13.Price or 0
					local v28 = " $  |  Reset: "
					local v29 = v13.ResetInSeconds or 0
					local v30
					if v29 and v29 > 0 then
						local v31 = v29 / 3600
						local v32 = math.floor(v31)
						local v33 = v29 % 3600 / 60
						local v34 = math.floor(v33)
						local v35 = v29 % 60
						v30 = string.format("%02d:%02d:%02d", v32, v34, v35)
					else
						v30 = "Ready"
					end
					v25.Text = v26 .. v27 .. v28 .. v30
				end
			end
		end
	else
		return
	end
end
local function v_u_40()
	-- upvalues: (ref) v_u_4, (copy) v_u_2
	if not v_u_4 then
		return false
	end
	local v37, v38 = pcall(function()
		-- upvalues: (ref) v_u_4
		return v_u_4:InvokeServer("GetGachaInfo")
	end)
	if not (v37 and (v38 and v38.Price)) then
		return false
	end
	local v39 = v_u_2.LocalPlayer
	if v39 then
		v39 = v39:FindFirstChild("leaderstats")
	end
	if v39 then
		v39 = v39:FindFirstChild("Money")
	end
	return (v39 and v39.Value or 0) >= (v38.Price or 0)
end
TweenInfo.new(0.25, Enum.EasingStyle.Quad)
local v_u_41 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_42 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.In)
local v_u_43 = TweenInfo.new(0.4, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out)
local function v_u_48(p44, p45, p46)
	if p44 and p44:IsA("ImageLabel") then
		p44.Image = p46.Display
	else
		local v47 = p44 and p44:IsA("Frame") and (p44:FindFirstChild("ImageLabel") or p44:FindFirstChildOfClass("ImageLabel"))
		if v47 then
			v47.Image = p46.Display
		end
	end
	if p45 and (p45:IsA("TextLabel") and p46) then
		p45.Text = p46.Name or ""
	end
end
function v1.ShowSpinPopup(_)
	-- upvalues: (ref) v_u_4, (ref) v_u_6, (ref) v_u_5, (copy) v_u_2, (copy) v_u_40, (ref) v_u_9, (copy) v_u_3, (copy) v_u_41, (copy) v_u_48, (copy) v_u_43, (copy) v_u_42, (ref) v_u_11
	if v_u_4 then
		if not v_u_6 then
			v_u_5 = v_u_2.LocalPlayer
			v_u_6 = v_u_5:WaitForChild("PlayerGui")
		end
		if v_u_40() then
			local v_u_49 = v_u_6:FindFirstChild("GachaUI") or v_u_6:WaitForChild("GachaUI", 2)
			if v_u_49 then
				v_u_49.Enabled = true
				local v50 = v_u_49:FindFirstChild("Background")
				local v_u_51 = v_u_49:FindFirstChild("DisplayItem", true)
				local v_u_52 = v50 and v50:FindFirstChild("TextLabel") or v_u_49:FindFirstChild("TextLabel", true)
				if not v_u_51 then
					v_u_51 = v50
					if v_u_51 then
						v_u_51 = v50:FindFirstChild("DisplayItem")
					end
				end
				if v_u_51 then
					local v53 = v_u_9
					local v_u_54
					if #v53 == 0 then
						local v55
						v55, v_u_54 = pcall(function()
							-- upvalues: (ref) v_u_4
							return v_u_4:InvokeServer("GetGachaSkillList")
						end)
						if not v55 or (not v_u_54 or #v_u_54 <= 0) then
							v_u_54 = v53
						end
					else
						v_u_54 = v53
					end
					if #v_u_54 == 0 then
						if v_u_52 and v_u_52:IsA("TextLabel") then
							v_u_52.Text = "No skills available"
						end
						task.delay(1.5, function()
							-- upvalues: (copy) v_u_49
							v_u_49.Enabled = false
						end)
					else
						local v_u_56 = UDim2.new(0.209, 0, 0.344, 0)
						local _ = v_u_51.Position
						v_u_51.Size = UDim2.new(0, 0, 0, 0)
						v_u_51.Visible = true
						v_u_3:Create(v_u_51, v_u_41, {
							["Size"] = v_u_56
						}):Play()
						local v_u_57 = math.random(1, #v_u_54)
						v_u_48(v_u_51, v_u_52, v_u_54[v_u_57])
						if v_u_52 and v_u_52:IsA("TextLabel") then
							v_u_52.Text = "Spinning..."
						end
						local v_u_58 = 0
						local v_u_59 = 0
						local v_u_61 = game:GetService("RunService").Heartbeat:Connect(function(p60)
							-- upvalues: (ref) v_u_58, (ref) v_u_59, (ref) v_u_57, (ref) v_u_54, (ref) v_u_51, (ref) v_u_3, (ref) v_u_41, (copy) v_u_56, (ref) v_u_48, (copy) v_u_52
							v_u_58 = v_u_58 + p60
							if (v_u_58 < 2.2 and 0.07 or 0.12) <= v_u_58 - v_u_59 then
								v_u_59 = v_u_58
								v_u_57 = math.random(1, #v_u_54)
								v_u_51.Size = UDim2.new(0, 0, 0, 0)
								v_u_51.Visible = true
								v_u_3:Create(v_u_51, v_u_41, {
									["Size"] = v_u_56
								}):Play()
								v_u_48(v_u_51, v_u_52, v_u_54[v_u_57])
							end
						end)
						task.delay(2.45, function()
							-- upvalues: (ref) v_u_61, (ref) v_u_4, (ref) v_u_54, (ref) v_u_48, (ref) v_u_51, (copy) v_u_52, (ref) v_u_3, (ref) v_u_43, (copy) v_u_56, (ref) v_u_42, (copy) v_u_49, (ref) v_u_11
							if v_u_61 then
								v_u_61:Disconnect()
							end
							local v62, v63 = pcall(function()
								-- upvalues: (ref) v_u_4
								return { v_u_4:InvokeServer("GachaRoll") }
							end)
							if v62 then
								if v63 then
									v62 = v63[1]
								else
									v62 = v63
								end
							end
							local v64
							if v63 then
								v64 = v63[2]
							else
								v64 = v63
							end
							if v63 then
								v63 = v63[3]
							end
							if v62 and v64 then
								local v65 = nil
								for _, v66 in ipairs(v_u_54) do
									if v66.Name == v64 then
										v65 = v66
										break
									end
								end
								if v65 then
									v_u_48(v_u_51, v_u_52, v65)
								end
								if v_u_52 and v_u_52:IsA("TextLabel") then
									v_u_52.Text = "You got: " .. (v64 or "?")
								end
								local v67 = v_u_51:IsA("ImageLabel") and v_u_51 or v_u_51:FindFirstChildOfClass("ImageLabel")
								if v67 then
									v_u_3:Create(v67, v_u_43, {
										["Size"] = v_u_56
									}):Play()
								end
							elseif v_u_52 and v_u_52:IsA("TextLabel") then
								v_u_52.Text = v63 and tostring(v63) or "Failed"
							end
							task.delay(2, function()
								-- upvalues: (ref) v_u_3, (ref) v_u_51, (ref) v_u_42, (ref) v_u_56, (ref) v_u_49, (ref) v_u_11
								v_u_3:Create(v_u_51, v_u_42, {
									["Size"] = UDim2.new(0, 0, 0, 0)
								}):Play()
								task.delay(0.35, function()
									-- upvalues: (ref) v_u_51, (ref) v_u_56, (ref) v_u_49, (ref) v_u_11
									v_u_51.Size = v_u_56
									v_u_49.Enabled = false
									v_u_11 = tick()
								end)
							end)
						end)
					end
				else
					pcall(function()
						-- upvalues: (ref) v_u_4
						v_u_4:FireServer("RequestSendNotification", {
							["Text"] = "DisplayItem not found in GachaUI",
							["Type"] = "Error"
						})
					end)
					return
				end
			else
				pcall(function()
					-- upvalues: (ref) v_u_4
					v_u_4:FireServer("RequestSendNotification", {
						["Text"] = "GachaUI not found",
						["Type"] = "Error"
					})
				end)
				return
			end
		else
			pcall(function()
				-- upvalues: (ref) v_u_4
				v_u_4:FireServer("RequestSendNotification", {
					["Text"] = "Not enough money to spin",
					["Type"] = "Error"
				})
			end)
			return
		end
	else
		return
	end
end
function v1.Show(_)
	-- upvalues: (ref) v_u_5, (copy) v_u_2, (ref) v_u_6, (ref) v_u_7, (copy) v_u_36, (ref) v_u_4, (ref) v_u_9, (ref) v_u_8, (ref) v_u_10, (copy) v_u_3
	v_u_5 = v_u_2.LocalPlayer
	v_u_6 = v_u_5:WaitForChild("PlayerGui")
	v_u_7 = v_u_6:FindFirstChild("GachaUI") or v_u_6:WaitForChild("GachaUI", 2)
	v_u_7.Enabled = true
	v_u_36()
	if v_u_4 then
		local v68, v69 = pcall(function()
			-- upvalues: (ref) v_u_4
			return v_u_4:InvokeServer("GetGachaSkillList")
		end)
		if v68 and (v69 and #v69 > 0) then
			v_u_9 = v69
		end
	end
	if v_u_8 then
		v_u_8:Disconnect()
	end
	local v_u_70 = 0
	v_u_8 = game:GetService("RunService").Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_70, (ref) v_u_36
		if tick() - v_u_70 >= 1 then
			v_u_70 = tick()
			v_u_36()
		end
	end)
	v_u_10 = false
	task.defer(function()
		-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_9, (ref) v_u_3
		v_u_10 = true
		local v71 = v_u_7
		if v71 then
			v71 = v_u_7:FindFirstChild("DisplayItem", true)
		end
		if not (v71 and v71:IsA("GuiObject")) then
			return
		end
		local v72 = v71:IsA("ImageLabel") and v71 and v71 or (v71:FindFirstChildWhichIsA("ImageLabel") or v71:FindFirstChildWhichIsA("ImageButton"))
		local v73 = {}
		if v_u_9 and #v_u_9 > 0 then
			for _, v74 in ipairs(v_u_9) do
				v73[#v73 + 1] = v74 and v74.Book or (v74 and v74.Display or "rbxassetid://92345379725727")
			end
		end
		if #v73 == 0 then
			v73[1] = "rbxassetid://92345379725727"
		end
		local v75 = 0
		local v76
		if v72 then
			v75 = v75 + 1
			v75 = #v73 < v75 and 1 or v75
			v72.Image = v73[v75] or "rbxassetid://92345379725727"
			v76 = v75
		else
			v76 = v75
		end
		local v77 = UDim2.new(0.209, 0, 0.344, 0)
		local v78 = v71.Position
		local v79 = TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		local v80 = TweenInfo.new(0.4, Enum.EasingStyle.Quad)
		while v_u_10 and v71.Parent do
			v_u_3:Create(v71, v79, {
				["Size"] = UDim2.new(v77.X.Scale * 1.14, v77.X.Offset * 1.14, v77.Y.Scale * 1.14, v77.Y.Offset * 1.14),
				["Position"] = UDim2.new(v78.X.Scale, v78.X.Offset, v78.Y.Scale, v78.Y.Offset - 12)
			}):Play()
			task.wait(0.45)
			if not (v_u_10 and v71.Parent) then
				break
			end
			v_u_3:Create(v71, v80, {
				["Size"] = v77,
				["Position"] = v78
			}):Play()
			task.wait(0.45)
			if not (v_u_10 and v71.Parent) then
				break
			end
			if v72 then
				v75 = v76 + 1
				v75 = #v73 < v75 and 1 or v75
				v72.Image = v73[v75] or "rbxassetid://92345379725727"
				v76 = v75
			end
		end
	end)
end
function v1.Hide(_)
	-- upvalues: (ref) v_u_10, (ref) v_u_7, (ref) v_u_8
	v_u_10 = false
	if v_u_7 then
		v_u_7.Enabled = false
	end
	if v_u_8 then
		v_u_8:Disconnect()
		v_u_8 = nil
	end
end
function v1.Start(p_u_81)
	-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) v_u_36
	v_u_4 = p_u_81.Shared.Network
	v_u_4:BindEvents({
		["OpenGachaUI"] = function()
			-- upvalues: (copy) p_u_81
			p_u_81:Show()
		end,
		["OpenSpinPopup"] = function()
			-- upvalues: (copy) p_u_81
			p_u_81:ShowSpinPopup()
		end,
		["GachaResult"] = function(p82, _, p83)
			-- upvalues: (ref) v_u_7, (ref) v_u_36
			local v84 = v_u_7
			if v84 then
				v84 = v_u_7:FindFirstChild("ResultLabel", true)
			end
			if v84 then
				v84.Text = "You got: " .. (p82 or "?") .. "!\nNext roll: " .. (p83 or 0) .. " $"
			end
			v_u_36()
		end
	})
end
return v1