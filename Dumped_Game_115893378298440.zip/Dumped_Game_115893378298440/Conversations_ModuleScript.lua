-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
local v_u_1 = {}
local v2 = {}
for _, v3 in pairs(script:GetChildren()) do
	v_u_1[v3.Name] = require(v3)
end
function v2.GetConvo(p4)
	-- upvalues: (copy) v_u_1
	return v_u_1[p4]
end
return v2