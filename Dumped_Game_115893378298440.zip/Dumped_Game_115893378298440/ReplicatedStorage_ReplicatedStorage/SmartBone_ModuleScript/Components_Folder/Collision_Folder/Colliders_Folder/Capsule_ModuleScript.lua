-- [DUMPED USING XEN V1.0.0 | Normal Decompiler ( Executor)] --
return function(p1, p2, p3, p4)
	debug.profilebegin("Capsule Testing")
	local v5 = p2.Y
	local v6 = p2.Z
	local v7 = math.min(v5, v6) * 0.5
	local v8 = p2.X
	local v9 = p1 * CFrame.Angles(1.5707963267948966, -1.5707963267948966, 0)
	local v10 = v9.Position
	local v11 = v9.UpVector
	local v12 = v8 * 0.5
	local v13 = (p3 - v10):Dot(v11)
	local v14 = -v12
	local v15 = v10 + v11 * math.clamp(v13, v14, v12)
	local v16 = (v15 - p3).Magnitude
	local v17 = p3 - v15
	local v18 = v17.Magnitude == 0 and Vector3.new(0, 0, 0) or v17.Unit
	local v19 = v16 <= v7
	local v20 = v15 + v18 * v7
	if v19 then
		return v19, v20, v18
	end
	local v21 = (v20 - p3).Magnitude < p4
	debug.profileend()
	return v21, v20, v18
end